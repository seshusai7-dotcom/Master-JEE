import { chapter1Reference } from './chapter1Reference';
import { chaptersPart1 } from './chaptersPart1';
import { chaptersPart2 } from './chaptersPart2';
import type { ChapterData, FormulaEntry, FlashcardEntry } from '../types/physics';

export const ALL_CHAPTERS: ChapterData[] = [
  chapter1Reference,
  ...chaptersPart1,
  ...chaptersPart2,
].sort((a, b) => a.number - b.number);

export function getChapterById(chapterId: string): ChapterData {
  return ALL_CHAPTERS.find((c) => c.id === chapterId) ?? ALL_CHAPTERS[0];
}

export function getAllFormulas(): FormulaEntry[] {
  return ALL_CHAPTERS.flatMap((ch) => ch.formulas);
}

export function getAllFlashcards(): FlashcardEntry[] {
  return ALL_CHAPTERS.flatMap((ch) => ch.flashcards);
}
