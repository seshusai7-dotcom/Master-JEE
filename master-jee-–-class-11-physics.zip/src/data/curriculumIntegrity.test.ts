import test from 'node:test';
import assert from 'node:assert/strict';
import { ALL_CHAPTERS, getAllFormulas, getAllFlashcards } from './curriculumIndex';
import { QUESTION_BANK } from './questionBank';

test('all 14 Class 11 Physics chapters are populated with complete A-Q sections and labs', () => {
  assert.equal(ALL_CHAPTERS.length, 14);
  for (let i = 0; i < 14; i += 1) {
    const ch = ALL_CHAPTERS[i];
    assert.equal(ch.number, i + 1);
    assert.ok(ch.subtopics.length >= 1, `Chapter ${ch.number} missing subtopics`);
    assert.ok(ch.derivations.length >= 1, `Chapter ${ch.number} missing derivations`);
    assert.ok(ch.solvedProblems.length >= 1, `Chapter ${ch.number} missing solved problems`);
    assert.ok(ch.formulas.length >= 1, `Chapter ${ch.number} missing formulas`);
    assert.ok(ch.flashcards.length >= 1, `Chapter ${ch.number} missing flashcards`);
    assert.ok(ch.mindMapBranches.length >= 1, `Chapter ${ch.number} missing mind map branches`);
  }
});

test('Chapter 1 reference implementation has 4 subtopics and 6 solved problems', () => {
  const ch1 = ALL_CHAPTERS[0];
  assert.equal(ch1.id, 'ch1');
  assert.equal(ch1.subtopics.length, 4);
  assert.equal(ch1.solvedProblems.length, 6);
  assert.equal(ch1.derivations.length, 4);
});

test('question bank strictly separates Database A Verified PYQs from AI-generated questions', () => {
  const dbA = QUESTION_BANK.filter((q) => q.databaseCategory === 'A_VERIFIED_PYQ');
  const dbB = QUESTION_BANK.filter((q) => q.databaseCategory === 'B_AI_ORIGINAL');
  const dbC = QUESTION_BANK.filter((q) => q.databaseCategory === 'C_PYQ_INSPIRED');

  assert.ok(dbA.length >= 4);
  assert.ok(dbB.length >= 10);
  assert.ok(dbC.length >= 2);

  for (const q of dbA) {
    assert.equal(q.verified, true);
    assert.ok(!q.exam.includes('AI-Generated'), 'Database A cannot contain AI-generated label');
  }
  for (const q of dbB) {
    assert.ok(q.exam.includes('AI-Generated'), 'Database B must be labeled Original AI-Generated');
  }

  assert.ok(getAllFormulas().length >= 15);
  assert.ok(getAllFlashcards().length >= 15);
});
