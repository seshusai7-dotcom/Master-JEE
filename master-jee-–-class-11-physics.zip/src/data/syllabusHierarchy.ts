import type {
  AcademicLevel,
  CurriculumScope,
  SyllabusChapterNode,
  SyllabusSubtopicNode,
  SyllabusTopicNode,
} from '../types/physics';
import { ALL_CHAPTERS } from './curriculumIndex';

interface SubtopicSeed {
  code: string;
  title: string;
  ncertAligned: boolean;
  jeeMainAligned: boolean;
  jeeAdvancedAligned: boolean;
  enrichmentOnly?: boolean;
  keyConcepts: string[];
  linkedContentSubtopicId?: string;
}

interface TopicSeed {
  code: string;
  title: string;
  ncertSectionRef: string;
  curriculumScope: CurriculumScope;
  targetLevels: AcademicLevel[];
  linkedContentSubtopicId?: string;
  subtopics: SubtopicSeed[];
}

interface ChapterHierarchySeed {
  chapterId: string;
  ncertBookPart: 'Part I' | 'Part II';
  ncertChapterNumber: number;
  topics: TopicSeed[];
}

const CHAPTER_HIERARCHY_SEEDS: ChapterHierarchySeed[] = [
  {
    chapterId: 'ch1',
    ncertBookPart: 'Part I',
    ncertChapterNumber: 1,
    topics: [
      {
        code: '1.1',
        title: 'Physical Quantities & International System of Units (SI)',
        ncertSectionRef: 'NCERT 1.1–1.2',
        curriculumScope: 'NCERT Core',
        targetLevels: ['foundation', 'jee_main'],
        linkedContentSubtopicId: 'ch1-s1',
        subtopics: [
          {
            code: '1.1.1',
            title: 'Fundamental & Derived Quantities, SI Base Units (2019 Redefinition)',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: false,
            keyConcepts: ['SI 7 base units', 'Invariant physical constants', 'Unit conversion n₁u₁ = n₂u₂'],
            linkedContentSubtopicId: 'ch1-s1',
          },
          {
            code: '1.1.2',
            title: 'Supplementary Geometric Units & Astronomical Distance Scales',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Radian & steradian', 'Parallax method D = b/θ', 'Parsec, AU, light-year'],
            linkedContentSubtopicId: 'ch1-s1',
          },
        ],
      },
      {
        code: '1.2',
        title: 'Precision Metrology: Vernier Calipers & Screw Gauge',
        ncertSectionRef: 'NCERT Lab & JEE Practical',
        curriculumScope: 'JEE Main & Adv',
        targetLevels: ['foundation', 'jee_main', 'jee_advanced'],
        linkedContentSubtopicId: 'ch1-s2',
        subtopics: [
          {
            code: '1.2.1',
            title: 'Vernier Calipers: Least Count & Non-Standard Vernier Scales',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['LC = 1 MSD − 1 VSD', 'Over-long Vernier (n VSD = (n+1) MSD)', 'Positive & negative zero error'],
            linkedContentSubtopicId: 'ch1-s2',
          },
          {
            code: '1.2.2',
            title: 'Screw Gauge (Micrometer): Pitch, Circular Scale & Backlash Error',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Pitch = distance / rotations', 'Datum line zero error sign', 'Ratchet torque & backlash'],
            linkedContentSubtopicId: 'ch1-s2',
          },
        ],
      },
      {
        code: '1.3',
        title: 'Significant Figures & Propagation of Measurement Errors',
        ncertSectionRef: 'NCERT 1.3–1.4',
        curriculumScope: 'NCERT + JEE Main',
        targetLevels: ['foundation', 'jee_main', 'jee_advanced'],
        linkedContentSubtopicId: 'ch1-s3',
        subtopics: [
          {
            code: '1.3.1',
            title: 'Significant Figures, Rounding Off & Order of Magnitude',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: false,
            keyConcepts: ['Trailing zeroes rules', 'Addition vs multiplication rounding', 'Order of magnitude'],
            linkedContentSubtopicId: 'ch1-s3',
          },
          {
            code: '1.3.2',
            title: 'Systematic, Random & Differential Error Propagation',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Absolute & percentage error', 'Power law ΔZ/Z = Σ |nᵢ| ΔXᵢ/Xᵢ', 'Gaussian vs max-bound error'],
            linkedContentSubtopicId: 'ch1-s3',
          },
        ],
      },
      {
        code: '1.4',
        title: 'Dimensional Analysis, Homogeneity & Buckingham Pi Enrichment',
        ncertSectionRef: 'NCERT 1.5–1.6 + Enrichment',
        curriculumScope: 'Enrichment',
        targetLevels: ['foundation', 'jee_main', 'jee_advanced'],
        linkedContentSubtopicId: 'ch1-s4',
        subtopics: [
          {
            code: '1.4.1',
            title: 'Principle of Dimensional Homogeneity & Non-Standard Base Quantities',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Checking equation consistency', 'Custom basis {E, v, T} or {G, h, c}', 'Transcendental arguments'],
            linkedContentSubtopicId: 'ch1-s4',
          },
          {
            code: '1.4.2',
            title: 'Buckingham Pi Theorem & Dimensionless Scaling Groups',
            ncertAligned: false,
            jeeMainAligned: false,
            jeeAdvancedAligned: true,
            enrichmentOnly: true,
            keyConcepts: ['Π-groups from k variables', 'Reynolds & Mach scaling', 'Limitations of dimensional deduction'],
            linkedContentSubtopicId: 'ch1-s4',
          },
        ],
      },
    ],
  },
  {
    chapterId: 'ch2',
    ncertBookPart: 'Part I',
    ncertChapterNumber: 2,
    topics: [
      {
        code: '2.1',
        title: 'Position, Path Length, Displacement & Average Quantities',
        ncertSectionRef: 'NCERT 2.1–2.2',
        curriculumScope: 'NCERT Core',
        targetLevels: ['foundation', 'jee_main'],
        subtopics: [
          {
            code: '2.1.1',
            title: 'Frame of Reference, Distance vs Displacement Vector',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: false,
            keyConcepts: ['1D coordinate axis', '|Displacement| ≤ Distance', 'Average speed vs velocity'],
          },
          {
            code: '2.1.2',
            title: 'Instantaneous Velocity & Acceleration via Differential Calculus',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['v = dx/dt', 'a = dv/dt = v dv/dx', 'Deceleration vs negative acceleration'],
          },
        ],
      },
      {
        code: '2.2',
        title: 'Kinematics Graphs & Uniformly Accelerated Motion',
        ncertSectionRef: 'NCERT 2.3–2.4',
        curriculumScope: 'NCERT + JEE Main',
        targetLevels: ['foundation', 'jee_main', 'jee_advanced'],
        subtopics: [
          {
            code: '2.2.1',
            title: 'Interpretation & Conversion of x-t, v-t, a-t, and v²-x Graphs',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Slope & area interpretation', 'Turning points where v = 0', 'Distance from |v|-t area'],
          },
          {
            code: '2.2.2',
            title: 'Kinematic Equations, nth-Second Displacement & Free Fall',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['s = ut + ½at²', 'sₙ = u + a(n − ½)', 'Galileo odd-number ratio 1:3:5'],
          },
        ],
      },
      {
        code: '2.3',
        title: 'Relative Velocity in 1D & Non-Uniform Acceleration Calculus',
        ncertSectionRef: 'NCERT 2.5 + JEE',
        curriculumScope: 'JEE Main & Adv',
        targetLevels: ['jee_main', 'jee_advanced'],
        subtopics: [
          {
            code: '2.3.1',
            title: '1D Relative Motion: Overtaking, Separation & Reaction Time',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['v_AB = v_A − v_B', 'Minimum separation condition v_rel = 0', 'Stopping distance'],
          },
          {
            code: '2.3.2',
            title: 'Variable Acceleration Integration a(t), a(v), and a(x)',
            ncertAligned: false,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            enrichmentOnly: true,
            keyConcepts: ['Separation of variables', 'Integrating v dv = a(x) dx', 'Terminal speed under drag'],
          },
        ],
      },
    ],
  },
  {
    chapterId: 'ch3',
    ncertBookPart: 'Part I',
    ncertChapterNumber: 3,
    topics: [
      {
        code: '3.1',
        title: 'Scalars, Vectors & Vector Algebra in 2D/3D',
        ncertSectionRef: 'NCERT 3.1–3.5',
        curriculumScope: 'NCERT Core',
        targetLevels: ['foundation', 'jee_main'],
        subtopics: [
          {
            code: '3.1.1',
            title: 'Triangle & Parallelogram Laws of Vector Addition',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: false,
            keyConcepts: ['Resultant magnitude √(A²+B²+2AB cosθ)', 'Unit vectors î, ĵ, k̂', 'Polygon law'],
          },
          {
            code: '3.1.2',
            title: 'Rectangular Resolution, Dot Product & Cross Product Foundations',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Projection A·B̂', 'Orthogonality condition', 'Area of parallelogram |A×B|'],
          },
        ],
      },
      {
        code: '3.2',
        title: 'Projectile Motion on Horizontal & Inclined Planes',
        ncertSectionRef: 'NCERT 3.8 + JEE',
        curriculumScope: 'JEE Main & Adv',
        targetLevels: ['foundation', 'jee_main', 'jee_advanced'],
        subtopics: [
          {
            code: '3.2.1',
            title: 'Ground-to-Ground Projectile, Trajectory Equation & Complementary Angles',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['y = x tanθ − gx²/(2u²cos²θ)', 'Range R & Max Height H', 'Radius of curvature at apex'],
          },
          {
            code: '3.2.2',
            title: 'Projectile on an Inclined Plane & Envelope of Trajectories',
            ncertAligned: false,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            enrichmentOnly: true,
            keyConcepts: ['Tilted axes decomposition', 'Maximum range g/(1+sinβ)', 'Safety parabola envelope'],
          },
        ],
      },
      {
        code: '3.3',
        title: 'Relative Velocity in 2D & Uniform Circular Kinematics',
        ncertSectionRef: 'NCERT 3.7, 3.9',
        curriculumScope: 'NCERT + JEE Main',
        targetLevels: ['foundation', 'jee_main', 'jee_advanced'],
        subtopics: [
          {
            code: '3.3.1',
            title: 'River-Boat Crossing, Rain-Man Umbrella & Closest Approach',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Minimum time vs shortest path', 'v_AB perpendicular to line joining', 'Wind-airplane triangles'],
          },
          {
            code: '3.3.2',
            title: 'Angular Variables, Centripetal & Tangential Acceleration',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['a_c = v²/r = ω²r', 'a_t = dv/dt', 'Radius of curvature v²/a_⊥'],
          },
        ],
      },
    ],
  },
  {
    chapterId: 'ch4',
    ncertBookPart: 'Part I',
    ncertChapterNumber: 4,
    topics: [
      {
        code: '4.1',
        title: 'Newton’s Three Laws of Motion, Momentum & Impulse',
        ncertSectionRef: 'NCERT 4.1–4.6',
        curriculumScope: 'NCERT Core',
        targetLevels: ['foundation', 'jee_main'],
        subtopics: [
          {
            code: '4.1.1',
            title: 'Inertia, Force-Momentum Relation & Impulse-Momentum Theorem',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: false,
            keyConcepts: ['Inertial frames', 'F = dp/dt', 'Impulse J = ∫F dt = Δp'],
          },
          {
            code: '4.1.2',
            title: 'Conservation of Linear Momentum & Free-Body Diagrams (FBD)',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Normal reaction & tension', 'Spring force & instantaneous cutting', 'Lami’s equilibrium theorem'],
          },
        ],
      },
      {
        code: '4.2',
        title: 'Constrained Motion, Pulley-Block Systems & Friction',
        ncertSectionRef: 'NCERT 4.8–4.9 + JEE',
        curriculumScope: 'JEE Main & Adv',
        targetLevels: ['foundation', 'jee_main', 'jee_advanced'],
        subtopics: [
          {
            code: '4.2.1',
            title: 'String & Wedge Constraints (Virtual Work Method)',
            ncertAligned: false,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Σ T·a = 0 constraint', 'Atwood & movable pulleys', 'Wedge contact normal constraint'],
          },
          {
            code: '4.2.2',
            title: 'Static Friction, Kinetic Friction, Angle of Repose & Block-on-Block',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Self-adjusting f_s ≤ μ_s N', 'Minimum force to pull F_min', 'Two-block slip threshold'],
          },
        ],
      },
      {
        code: '4.3',
        title: 'Dynamics of Circular Motion & Non-Inertial Pseudo-Forces',
        ncertSectionRef: 'NCERT 4.10 + Enrichment',
        curriculumScope: 'Enrichment',
        targetLevels: ['jee_main', 'jee_advanced'],
        subtopics: [
          {
            code: '4.3.1',
            title: 'Level & Banked Roads with Friction, Conical Pendulum',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['v_safe = √(rg tanθ)', 'Banked curve speed band [v_min, v_max]', 'Conical pendulum T cosθ = mg'],
          },
          {
            code: '4.3.2',
            title: 'Accelerating Frames (Pseudo-Force) & Variable-Mass Rocket Equation',
            ncertAligned: false,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            enrichmentOnly: true,
            keyConcepts: ['F_pseudo = −m a_frame', 'Apparent weight in lift', 'Thrust v_rel (dm/dt)'],
          },
        ],
      },
    ],
  },
  {
    chapterId: 'ch5',
    ncertBookPart: 'Part I',
    ncertChapterNumber: 5,
    topics: [
      {
        code: '5.1',
        title: 'Work Done by Constant & Variable Forces, Kinetic Energy',
        ncertSectionRef: 'NCERT 5.1–5.5',
        curriculumScope: 'NCERT Core',
        targetLevels: ['foundation', 'jee_main'],
        subtopics: [
          {
            code: '5.1.1',
            title: 'Scalar Product Work W = ∫ F·dr & Work-Energy Theorem',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Area under F-x curve', 'W_all = ΔK in any frame', 'Spring work ½kx²'],
          },
          {
            code: '5.1.2',
            title: 'Instantaneous Power, Average Power & Machine Efficiency',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: false,
            keyConcepts: ['P = F·v = dK/dt', 'Constant power motion v ∝ t^(1/2)', 'Pump discharge power'],
          },
        ],
      },
      {
        code: '5.2',
        title: 'Conservative Forces, Potential Energy & Vertical Circular Motion',
        ncertSectionRef: 'NCERT 5.6–5.9 + JEE',
        curriculumScope: 'JEE Main & Adv',
        targetLevels: ['foundation', 'jee_main', 'jee_advanced'],
        subtopics: [
          {
            code: '5.2.1',
            title: 'Potential Energy Curves, Force F = −∇U & Equilibrium Stability',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Stable/unstable/neutral d²U/dx²', 'Mechanical energy conservation', 'Path independence'],
          },
          {
            code: '5.2.2',
            title: 'Vertical Circular Motion: Critical Loop-the-Loop Speeds & Slackening',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['√(5gR) string vs √(4gR) rod', 'Tension difference T_bottom − T_top = 6mg', 'Angle of slackening'],
          },
        ],
      },
      {
        code: '5.3',
        title: 'Elastic, Inelastic & Oblique Collisions in 1D and 2D',
        ncertSectionRef: 'NCERT 5.10 + JEE',
        curriculumScope: 'NCERT + JEE Main',
        targetLevels: ['foundation', 'jee_main', 'jee_advanced'],
        subtopics: [
          {
            code: '5.3.1',
            title: 'Coefficient of Restitution e & 1D Head-On Collisions',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['e = (v₂−v₁)/(u₁−u₂)', 'Kinetic energy loss ΔK', 'Velocity exchange when m₁ = m₂'],
          },
          {
            code: '5.3.2',
            title: '2D Oblique Collisions, Bouncing Ball & Centre-of-Mass Frame',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Line of impact impulse', 'Perpendicular separation for e=1 equal masses', 'Total distance Σ h e^(2n)'],
          },
        ],
      },
    ],
  },
  {
    chapterId: 'ch6',
    ncertBookPart: 'Part I',
    ncertChapterNumber: 6,
    topics: [
      {
        code: '6.1',
        title: 'Centre of Mass & Motion of System of Particles',
        ncertSectionRef: 'NCERT 6.1–6.4',
        curriculumScope: 'NCERT Core',
        targetLevels: ['foundation', 'jee_main', 'jee_advanced'],
        subtopics: [
          {
            code: '6.1.1',
            title: 'COM of Discrete Particles, Continuous Bodies & Cavity Subtraction',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['R_cm = ∫ r dm / M', 'Negative mass cavity method', 'Rod, disc, cone, hemisphere COM'],
          },
          {
            code: '6.1.2',
            title: 'COM Frame Dynamics & Zero External Force Invariance',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['M a_cm = F_ext', 'Internal forces & explosions', 'Man-plank displacement conservation'],
          },
        ],
      },
      {
        code: '6.2',
        title: 'Torque, Angular Momentum & Moment of Inertia',
        ncertSectionRef: 'NCERT 6.5–6.10',
        curriculumScope: 'NCERT + JEE Main',
        targetLevels: ['foundation', 'jee_main', 'jee_advanced'],
        subtopics: [
          {
            code: '6.2.1',
            title: 'Moment of Inertia, Parallel & Perpendicular Axis Theorems',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['I = I_cm + Md²', 'I_z = I_x + I_y (planar)', 'Radius of gyration'],
          },
          {
            code: '6.2.2',
            title: 'Torque τ = r×F, Angular Momentum Conservation & Toppling',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['L = Iω + M(r_cm × v_cm)', 'Conservation about hinge/impulse point', 'Tipping vs sliding criterion'],
          },
        ],
      },
      {
        code: '6.3',
        title: 'Combined Translation-Rotation & Pure Rolling Dynamics',
        ncertSectionRef: 'NCERT 6.11–6.12 + Enrichment',
        curriculumScope: 'Enrichment',
        targetLevels: ['jee_main', 'jee_advanced'],
        subtopics: [
          {
            code: '6.3.1',
            title: 'Pure Rolling on Flat & Inclined Planes, Kinetic Energy Partition',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['v_cm = ωR, a_cm = αR', 'K_total = ½Mv²(1 + k²/R²)', 'Rolling race acceleration'],
          },
          {
            code: '6.3.2',
            title: 'Instantaneous Axis of Rotation (IAOR) & Rolling with Slipping',
            ncertAligned: false,
            jeeMainAligned: false,
            jeeAdvancedAligned: true,
            enrichmentOnly: true,
            keyConcepts: ['Zero-velocity contact point', 'Angular impulse J·R = ΔL', 'Transition from sliding to pure rolling'],
          },
        ],
      },
    ],
  },
  {
    chapterId: 'ch7',
    ncertBookPart: 'Part I',
    ncertChapterNumber: 7,
    topics: [
      {
        code: '7.1',
        title: 'Kepler’s Laws & Newton’s Universal Law of Gravitation',
        ncertSectionRef: 'NCERT 7.1–7.4',
        curriculumScope: 'NCERT Core',
        targetLevels: ['foundation', 'jee_main'],
        subtopics: [
          {
            code: '7.1.1',
            title: 'Kepler’s Three Laws & Areal Velocity Conservation',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['dA/dt = L/(2m)', 'T² ∝ a³', 'Perihelion & aphelion r₁v₁ = r₂v₂'],
          },
          {
            code: '7.1.2',
            title: 'Gravitational Force, Shell Theorem & Variation of g',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Altitude & depth variation', 'Earth rotation g_eff = g − ω²R cos²λ', 'Uniform sphere interior field'],
          },
        ],
      },
      {
        code: '7.2',
        title: 'Gravitational Field, Potential & Self-Energy',
        ncertSectionRef: 'NCERT 7.5–7.7 + JEE',
        curriculumScope: 'JEE Main & Adv',
        targetLevels: ['foundation', 'jee_main', 'jee_advanced'],
        subtopics: [
          {
            code: '7.2.1',
            title: 'Potential V(r) of Ring, Disc, Shell & Solid Sphere',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['V_centre = (3/2) V_surface', 'E = −dV/dr', 'Tunnel SHM through Earth'],
          },
          {
            code: '7.2.2',
            title: 'Gravitational Self-Energy of Uniform Sphere & Binary Systems',
            ncertAligned: false,
            jeeMainAligned: false,
            jeeAdvancedAligned: true,
            enrichmentOnly: true,
            keyConcepts: ['U_self = −(3/5) GM²/R', 'Reduced mass binary orbit', 'Superposition with spherical cavity'],
          },
        ],
      },
      {
        code: '7.3',
        title: 'Escape Speed, Satellite Orbits & Orbital Transfers',
        ncertSectionRef: 'NCERT 7.8–7.10',
        curriculumScope: 'NCERT + JEE Main',
        targetLevels: ['foundation', 'jee_main', 'jee_advanced'],
        subtopics: [
          {
            code: '7.3.1',
            title: 'Escape Velocity, Orbital Speed & Satellite Energy Relations',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['v_e = √(2GM/R)', 'K = −E = −U/2', 'Geostationary & polar orbits'],
          },
          {
            code: '7.3.2',
            title: 'Elliptical Orbit Energy E = −GMm/(2a) & Launch Trajectories',
            ncertAligned: false,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Semi-major axis conservation', 'Bound vs hyperbolic escape', 'Weightlessness'],
          },
        ],
      },
    ],
  },
  {
    chapterId: 'ch8',
    ncertBookPart: 'Part II',
    ncertChapterNumber: 8,
    topics: [
      {
        code: '8.1',
        title: 'Stress, Strain & Hooke’s Law',
        ncertSectionRef: 'NCERT 8.1–8.4',
        curriculumScope: 'NCERT Core',
        targetLevels: ['foundation', 'jee_main'],
        subtopics: [
          {
            code: '8.1.1',
            title: 'Tensile, Shear & Volumetric Stress-Strain Curves',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: false,
            keyConcepts: ['Proportional & elastic limits', 'Yield strength & fracture point', 'Ductile vs brittle'],
          },
          {
            code: '8.1.2',
            title: 'Poisson’s Ratio σ & Thermal Stress in Constrained Rods',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Lateral vs longitudinal strain', 'Thermal stress YαΔT', 'Composite series/parallel rods'],
          },
        ],
      },
      {
        code: '8.2',
        title: 'Elastic Moduli & Elastic Potential Energy Density',
        ncertSectionRef: 'NCERT 8.5–8.6 + JEE',
        curriculumScope: 'NCERT + JEE Main',
        targetLevels: ['foundation', 'jee_main', 'jee_advanced'],
        subtopics: [
          {
            code: '8.2.1',
            title: 'Young’s Modulus Y, Bulk Modulus B & Shear Modulus G',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Compressibility κ = 1/B', 'Inter-moduli relations', 'Self-weight elongation MgL/(2AY)'],
          },
          {
            code: '8.2.2',
            title: 'Elastic Energy Density u = ½σε & Stretching of Rotating Rings',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['u = σ²/(2Y) = ½Yε²', 'Work vs heat loss in sudden loading', 'Rotating hoop tension'],
          },
        ],
      },
    ],
  },
  {
    chapterId: 'ch9',
    ncertBookPart: 'Part II',
    ncertChapterNumber: 9,
    topics: [
      {
        code: '9.1',
        title: 'Hydrostatics, Pascal’s Law & Buoyancy',
        ncertSectionRef: 'NCERT 9.1–9.2',
        curriculumScope: 'NCERT Core',
        targetLevels: ['foundation', 'jee_main', 'jee_advanced'],
        subtopics: [
          {
            code: '9.1.1',
            title: 'Pressure Variation with Depth & Accelerating Fluid Containers',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['P = P₀ + ρgh', 'Tilted free surface tanθ = a/g', 'Parabolic rotating meniscus'],
          },
          {
            code: '9.1.2',
            title: 'Archimedes’ Principle, Floating Equilibrium & Pascal’s Hydraulic Lift',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Buoyant force V_sub ρ_l g', 'Ice melting level problems', 'Hydraulic mechanical advantage'],
          },
        ],
      },
      {
        code: '9.2',
        title: 'Fluid Dynamics, Continuity & Bernoulli’s Principle',
        ncertSectionRef: 'NCERT 9.3–9.4',
        curriculumScope: 'NCERT + JEE Main',
        targetLevels: ['foundation', 'jee_main', 'jee_advanced'],
        subtopics: [
          {
            code: '9.2.1',
            title: 'Equation of Continuity & Bernoulli’s Energy Conservation',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['A₁v₁ = A₂v₂', 'P + ½ρv² + ρgh = const', 'Venturimeter & Pitot tube'],
          },
          {
            code: '9.2.2',
            title: 'Torricelli’s Efflux, Tank Emptying Time & Magnus Effect',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Efflux v = √(2gh)', 'Reaction thrust ρAv²', 'Aerodynamic lift'],
          },
        ],
      },
      {
        code: '9.3',
        title: 'Viscosity, Stokes’ Law & Surface Tension Phenomena',
        ncertSectionRef: 'NCERT 9.5–9.6 + Enrichment',
        curriculumScope: 'JEE Main & Adv',
        targetLevels: ['foundation', 'jee_main', 'jee_advanced'],
        subtopics: [
          {
            code: '9.3.1',
            title: 'Viscous Drag, Terminal Velocity & Reynolds Number',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['F = 6πηrv', 'v_T ∝ r²(ρ−σ)/η', 'Poiseuille laminar flow rate'],
          },
          {
            code: '9.3.2',
            title: 'Surface Energy, Excess Pressure & Capillary Rise (Jurin’s Law)',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Soap bubble 4T/R vs drop 2T/R', 'h = 2T cosθ/(rρg)', 'Insufficient capillary tube meniscus'],
          },
        ],
      },
    ],
  },
  {
    chapterId: 'ch10',
    ncertBookPart: 'Part II',
    ncertChapterNumber: 10,
    topics: [
      {
        code: '10.1',
        title: 'Thermometry, Thermal Expansion & Calorimetry',
        ncertSectionRef: 'NCERT 10.1–10.7',
        curriculumScope: 'NCERT Core',
        targetLevels: ['foundation', 'jee_main'],
        subtopics: [
          {
            code: '10.1.1',
            title: 'Linear, Areal & Volumetric Expansion (α : β : γ = 1 : 2 : 3)',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Anomalous expansion of water', 'Apparent liquid expansion', 'Pendulum clock error ½αΔT'],
          },
          {
            code: '10.1.2',
            title: 'Specific Heat, Latent Heat & Principle of Calorimetry',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: false,
            keyConcepts: ['Q = mcΔT + mL', 'Phase mixture equilibrium', 'Water equivalent'],
          },
        ],
      },
      {
        code: '10.2',
        title: 'Heat Transfer: Conduction, Convection & Blackbody Radiation',
        ncertSectionRef: 'NCERT 10.8–10.9',
        curriculumScope: 'NCERT + JEE Main',
        targetLevels: ['foundation', 'jee_main', 'jee_advanced'],
        subtopics: [
          {
            code: '10.2.1',
            title: 'Fourier’s Conduction Law, Thermal Resistance & Slab Networks',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['R_th = L/(KA)', 'Series & parallel slabs', 'Ice layer growth time t ∝ x²'],
          },
          {
            code: '10.2.2',
            title: 'Stefan-Boltzmann Law, Wien’s Displacement & Newton’s Cooling',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['P = eσAT⁴', 'λ_m T = b', 'dT/dt = −k(T − T₀)'],
          },
        ],
      },
    ],
  },
  {
    chapterId: 'ch11',
    ncertBookPart: 'Part II',
    ncertChapterNumber: 11,
    topics: [
      {
        code: '11.1',
        title: 'Zeroth & First Laws of Thermodynamics',
        ncertSectionRef: 'NCERT 11.1–11.6',
        curriculumScope: 'NCERT Core',
        targetLevels: ['foundation', 'jee_main'],
        subtopics: [
          {
            code: '11.1.1',
            title: 'Thermal Equilibrium, Internal Energy U & Sign Conventions',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: false,
            keyConcepts: ['State vs path functions', 'dQ = dU + dW', 'Mayer relation C_p − C_v = R'],
          },
          {
            code: '11.1.2',
            title: 'Work & Heat in Isobaric, Isochoric, Isothermal & Adiabatic Paths',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['PV^γ = const', 'Adiabatic slope = γ × Isothermal slope', 'Free expansion ΔU = 0'],
          },
        ],
      },
      {
        code: '11.2',
        title: 'Polytropic Processes, Heat Engines & Second Law',
        ncertSectionRef: 'NCERT 11.7–11.10 + Enrichment',
        curriculumScope: 'JEE Main & Adv',
        targetLevels: ['jee_main', 'jee_advanced'],
        subtopics: [
          {
            code: '11.2.1',
            title: 'Cyclic Work, Carnot Engine Efficiency & Refrigerators (COP)',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['η = 1 − T₂/T₁', 'COP = Q₂/W = T₂/(T₁−T₂)', 'Kelvin-Planck & Clausius statements'],
          },
          {
            code: '11.2.2',
            title: 'General Polytropic Process P V^x = const & Indicator Graph Conversions',
            ncertAligned: false,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            enrichmentOnly: true,
            keyConcepts: ['C = C_v + R/(1−x)', 'P-V ↔ P-T ↔ V-T transformations', 'Reversible entropy ΔS = ∫ dQ/T'],
          },
        ],
      },
    ],
  },
  {
    chapterId: 'ch12',
    ncertBookPart: 'Part II',
    ncertChapterNumber: 12,
    topics: [
      {
        code: '12.1',
        title: 'Kinetic Theory Pressure & Maxwell Molecular Speeds',
        ncertSectionRef: 'NCERT 12.1–12.4',
        curriculumScope: 'NCERT Core',
        targetLevels: ['foundation', 'jee_main'],
        subtopics: [
          {
            code: '12.1.1',
            title: 'Ideal Gas Assumptions & Pressure P = ⅓ ρ v_rms²',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Elastic wall collisions', 'Translational KE = (3/2)k_B T', 'Dalton partial pressures'],
          },
          {
            code: '12.1.2',
            title: 'Maxwell-Boltzmann Distribution: v_mp, v_avg, and v_rms',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Ratio √2 : √(8/π) : √3', 'Mass & temperature scaling', 'Atmospheric escape'],
          },
        ],
      },
      {
        code: '12.2',
        title: 'Degrees of Freedom, Equipartition & Mean Free Path',
        ncertSectionRef: 'NCERT 12.5–12.7',
        curriculumScope: 'NCERT + JEE Main',
        targetLevels: ['foundation', 'jee_main', 'jee_advanced'],
        subtopics: [
          {
            code: '12.2.1',
            title: 'Equipartition of Energy, Specific Heats & Non-Reacting Gas Mixtures',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['C_v = (f/2)R, γ = 1 + 2/f', 'Vibrational modes at high T', 'Mixture C_v,mix & γ_mix'],
          },
          {
            code: '12.2.2',
            title: 'Mean Free Path λ & Collision Frequency',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['λ = 1/(√2 π d² n_v)', 'Dependence on T and P', 'Real gas vs ideal limit'],
          },
        ],
      },
    ],
  },
  {
    chapterId: 'ch13',
    ncertBookPart: 'Part II',
    ncertChapterNumber: 13,
    topics: [
      {
        code: '13.1',
        title: 'Kinematics, Phasors & Energy of Simple Harmonic Motion',
        ncertSectionRef: 'NCERT 13.1–13.6',
        curriculumScope: 'NCERT Core',
        targetLevels: ['foundation', 'jee_main'],
        subtopics: [
          {
            code: '13.1.1',
            title: 'SHM Differential Equation a = −ω²x & Phasor Circle Geometry',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['x = A sin(ωt+φ)', 'v = ω√(A²−x²)', 'Phase time T/12 & T/8 shortcuts'],
          },
          {
            code: '13.1.2',
            title: 'Kinetic, Potential & Total Energy Partition in SHM',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['K = ½k(A²−x²)', 'Average KE = PE = ¼kA²', 'Energy frequency 2f'],
          },
        ],
      },
      {
        code: '13.2',
        title: 'Spring-Mass Systems, Pendulums & Physical Oscillators',
        ncertSectionRef: 'NCERT 13.7–13.8 + Enrichment',
        curriculumScope: 'JEE Main & Adv',
        targetLevels: ['foundation', 'jee_main', 'jee_advanced'],
        subtopics: [
          {
            code: '13.2.1',
            title: 'Series/Parallel Springs, Cut Springs & Two-Body Reduced Mass SHM',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['k_part = k/p', 'T = 2π√(μ/k)', 'Oscillating fluid U-tube & floating block'],
          },
          {
            code: '13.2.2',
            title: 'Simple Pendulum in Effective g, Physical Pendulum & Damped/Forced Overview',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            enrichmentOnly: false,
            keyConcepts: ['T = 2π√(L/g_eff)', 'Rigid body T = 2π√(I/(mgd))', 'Resonance condition'],
          },
        ],
      },
    ],
  },
  {
    chapterId: 'ch14',
    ncertBookPart: 'Part II',
    ncertChapterNumber: 14,
    topics: [
      {
        code: '14.1',
        title: 'Mechanical Wave Propagation & Speed on Stretched Strings',
        ncertSectionRef: 'NCERT 14.1–14.4',
        curriculumScope: 'NCERT Core',
        targetLevels: ['foundation', 'jee_main'],
        subtopics: [
          {
            code: '14.1.1',
            title: 'Travelling Harmonic Wave y(x, t), Wave Equation & Phase Velocity',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['v = ω/k', 'Particle velocity v_p = −v(∂y/∂x)', 'Wave intensity & energy density'],
          },
          {
            code: '14.1.2',
            title: 'Transverse Speed on String & Laplace-Corrected Sound Speed',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['v = √(T/μ)', 'v_sound = √(γRT/M)', 'Humidity, pressure & temperature effects'],
          },
        ],
      },
      {
        code: '14.2',
        title: 'Superposition, Standing Waves, Organ Pipes & Beats',
        ncertSectionRef: 'NCERT 14.5–14.7',
        curriculumScope: 'NCERT + JEE Main',
        targetLevels: ['foundation', 'jee_main', 'jee_advanced'],
        subtopics: [
          {
            code: '14.2.1',
            title: 'Reflection Phase Change, Standing Wave Nodes & Sonometer Harmonics',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Rigid vs free boundary reflection', 'Node spacing λ/2', 'f_n = nv/(2L)'],
          },
          {
            code: '14.2.2',
            title: 'Open & Closed Organ Pipes, End Correction, Resonance Tube & Beats',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['Closed pipe odd harmonics', 'End correction e ≈ 0.6r', 'Beat frequency |f₁ − f₂|'],
          },
        ],
      },
      {
        code: '14.3',
        title: 'Doppler Effect in Sound & Moving Medium Extensions',
        ncertSectionRef: 'NCERT 14.8 + JEE Adv',
        curriculumScope: 'JEE Main & Adv',
        targetLevels: ['jee_main', 'jee_advanced'],
        subtopics: [
          {
            code: '14.3.1',
            title: 'Line-of-Sight & Oblique Doppler Shift with Wall Reflection',
            ncertAligned: true,
            jeeMainAligned: true,
            jeeAdvancedAligned: true,
            keyConcepts: ['f′ = f(v±v_o)/(v∓v_s)', 'Cos θ radial velocity component', 'Beats from echo & source'],
          },
          {
            code: '14.3.2',
            title: 'Doppler Shift in Moving Medium (Wind) & Accelerated Sources',
            ncertAligned: false,
            jeeMainAligned: false,
            jeeAdvancedAligned: true,
            enrichmentOnly: true,
            keyConcepts: ['Effective sound speed v ± v_w', 'Retarded emission time t_emit', 'Shock cone'],
          },
        ],
      },
    ],
  },
];

export const SYLLABUS_HIERARCHY: SyllabusChapterNode[] = CHAPTER_HIERARCHY_SEEDS.map((seed) => {
  const chapter = ALL_CHAPTERS.find((c) => c.id === seed.chapterId);
  if (!chapter) {
    throw new Error(`Missing chapter definition for ${seed.chapterId}`);
  }

  const defaultContentSubtopicId = chapter.subtopics[0]?.id ?? `${chapter.id}-s1`;

  const topics: SyllabusTopicNode[] = seed.topics.map((t, tIdx) => {
    const topicId = `${chapter.id}-t${tIdx + 1}`;
    const linkedTopicSubtopic = t.linkedContentSubtopicId ?? defaultContentSubtopicId;

    const subtopics: SyllabusSubtopicNode[] = t.subtopics.map((st, sIdx) => ({
      subtopicId: `${topicId}-st${sIdx + 1}`,
      topicId,
      chapterId: chapter.id,
      order: sIdx + 1,
      code: st.code,
      title: st.title,
      ncertAligned: st.ncertAligned,
      jeeMainAligned: st.jeeMainAligned,
      jeeAdvancedAligned: st.jeeAdvancedAligned,
      enrichmentOnly: Boolean(st.enrichmentOnly),
      keyConcepts: st.keyConcepts,
      linkedContentSubtopicId: st.linkedContentSubtopicId ?? linkedTopicSubtopic,
    }));

    return {
      topicId,
      chapterId: chapter.id,
      order: tIdx + 1,
      code: t.code,
      title: t.title,
      ncertSectionRef: t.ncertSectionRef,
      curriculumScope: t.curriculumScope,
      isEnrichment: t.curriculumScope === 'Enrichment',
      targetLevels: t.targetLevels,
      linkedContentSubtopicId: linkedTopicSubtopic,
      subtopics,
    };
  });

  return {
    chapterId: chapter.id,
    chapterNumber: chapter.number,
    title: chapter.title,
    ncertBookPart: seed.ncertBookPart,
    ncertChapterNumber: seed.ncertChapterNumber,
    unitGroup: chapter.unitGroup,
    ncertWeightage: chapter.ncertWeightage,
    jeeWeightage: chapter.jeeWeightage,
    estimatedHours: chapter.estimatedHours,
    overview: chapter.overview,
    labId: chapter.labId,
    topics,
  };
});

export function getSyllabusStats(chapters: SyllabusChapterNode[]) {
  const chapterCount = chapters.length;
  const topicCount = chapters.reduce((acc, ch) => acc + ch.topics.length, 0);
  const subtopicCount = chapters.reduce(
    (acc, ch) => acc + ch.topics.reduce((tAcc, t) => tAcc + t.subtopics.length, 0),
    0
  );
  const enrichmentSubtopics = chapters.reduce(
    (acc, ch) =>
      acc +
      ch.topics.reduce(
        (tAcc, t) => tAcc + t.subtopics.filter((st) => st.enrichmentOnly).length,
        0
      ),
    0
  );
  return { chapterCount, topicCount, subtopicCount, enrichmentSubtopics };
}
