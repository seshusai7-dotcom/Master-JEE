import type { ChapterData } from '../types/physics';

export const chapter1Reference: ChapterData = {
  id: 'ch1',
  number: 1,
  title: 'Units and Measurements',
  unitGroup: 'Mechanics',
  ncertWeightage: '4–6%',
  jeeWeightage: '3.5% (1–2 Qs every paper)',
  estimatedHours: 8,
  overview:
    'The quantitative foundation of Physics. Covers the International System of Units (SI), precision metrology with Vernier Calipers and Screw Gauge, significant figures, systematic and random error propagation, and dimensional analysis.',
  labId: 'vector_addition',
  workflowStatus: 'PUBLISH',
  subtopics: [
    {
      id: 'ch1-s1',
      title: '1.1 Physical Quantities & The International System of Units (SI)',
      syllabusTag: 'NCERT + JEE',
      introductionAndObjectives: [
        'Physics relies on reproducible quantitative measurement rather than qualitative opinion.',
        'By the end of this section, you will classify physical quantities into fundamental and derived types, apply the seven SI base units, and use supplementary angular units (radian and steradian) accurately.',
      ],
      theoreticalExplanation: {
        foundation:
          'Every physical quantity Q is expressed as the product of a numerical magnitude n and a chosen standard unit u: Q = n u. If the unit is made larger, the numerical value becomes proportionally smaller so that n1 u1 = n2 u2 remains invariant. Seven independent base quantities (length, mass, time, electric current, thermodynamic temperature, amount of substance, luminous intensity) form the bedrock of the SI system.',
        jee_main:
          'In the 2019 SI redefinition, all seven base units are anchored to exact invariant physical constants ($c, h, e, k_B, N_A, \\Delta\\nu_{\\text{Cs}}, K_{\\text{cd}}$) rather than material artifacts like the platinum-iridium cylinder. Derived quantities are expressed algebraically in terms of base units. Plane angle (radian) and solid angle (steradian) are dimensionless supplementary quantities that still carry distinct geometric units.',
        jee_advanced:
          'Any set of linearly independent physical quantities whose dimensional determinant is non-zero can replace {M, L, T} as a valid basis of units (e.g., {G, h, c} in Planck units, or {E, v, F} in mechanics). Note that dimensionless quantities need not be unitless: plane angle in radians and angular velocity in rad/s share dimensions with pure numbers or frequency, yet carry geometric meaning.',
      },
      definitionsAndPrinciples: [
        {
          term: 'Physical Quantity',
          definition: 'Any property of a material or physical system that can be measured directly or indirectly and expressed as a number multiplied by a unit.',
        },
        {
          term: 'Principle of Unit Invariance',
          definition: 'The physical magnitude of a quantity is independent of the unit system chosen: Q = n₁u₁ = n₂u₂.',
        },
        {
          term: 'Radian (rad)',
          definition: 'The plane angle subtended at the centre of a circle by an arc equal in length to its radius (θ = s/r).',
        },
        {
          term: 'Steradian (sr)',
          definition: 'The solid angle subtended at the centre of a sphere by a surface patch of area r² (Ω = A/r²).',
        },
      ],
      physicalInterpretation:
        'A unit is a physical reference scale agreed upon globally. Changing from metres to millimetres does not stretch the object; it multiplies the numerical count by 1000 while shrinking the unit by 1000.',
      mathematicalFormulation: [
        {
          label: 'Unit Conversion Law',
          latex: 'n_1 u_1 = n_2 u_2 \\implies n_2 = n_1 \\left(\\frac{M_1}{M_2}\\right)^a \\left(\\frac{L_1}{L_2}\\right)^b \\left(\\frac{T_1}{T_2}\\right)^c',
          notes: 'Valid for all coherent unit systems with exponents a, b, c from the dimensional formula.',
        },
        {
          label: 'Parallax Distance Formula',
          latex: 'D = \\frac{b}{\\theta}',
          notes: 'θ must be in radians; b is the baseline (e.g., Earth orbital diameter 2 AU for stellar parallax).',
        },
      ],
      derivationIds: ['ch1-drv-1'],
      assumptionsAndLimitations: [
        'Parallax formula D = b/θ assumes the small-angle approximation sin θ ≈ θ (valid when b ≪ D).',
        'Coherent SI prefixes scale in powers of 10³, whereas non-SI units such as light-year, parsec, and amu require explicit conversion constants.',
      ],
      unitsAndDimensions: [
        { quantity: 'Length (l)', siUnit: 'metre (m)', dimensions: '[L]' },
        { quantity: 'Mass (m)', siUnit: 'kilogram (kg)', dimensions: '[M]' },
        { quantity: 'Time (t)', siUnit: 'second (s)', dimensions: '[T]' },
        { quantity: 'Electric Current (I)', siUnit: 'ampere (A)', dimensions: '[I]' },
        { quantity: 'Temperature (T)', siUnit: 'kelvin (K)', dimensions: '[K]' },
        { quantity: 'Plane Angle (θ)', siUnit: 'radian (rad)', dimensions: '[M⁰L⁰T⁰]' },
      ],
      diagramSpec: {
        title: 'Parallax Angle & Vernier Geometry Reference',
        caption: 'Small-angle baseline measurement D = b/θ and instrument scale division alignment.',
        svgType: 'vernier',
      },
      realLifeApplications: [
        'GPS satellite timing synchronization uses atomic cesium clocks ($\\Delta\\nu_{\\text{Cs}}$) accurate to nanoseconds because light travels 30 cm per nanosecond.',
        'Astronomical distance ladders measure nearby star distances up to ~100 parsecs using Gaia space observatory parallax.',
      ],
      importantExamConcepts: [
        '1 parsec = 3.08 × 10¹⁶ m ≈ 3.26 light-years; 1 AU = 1.496 × 10¹¹ m.',
        'Order of magnitude of a number N = a × 10^b (with 0.5 ≤ a < 5) has order of magnitude b; if 5 ≤ a < 10, order is b + 1.',
      ],
      commonMistakes: [
        {
          misconception: 'Assuming all dimensionless quantities are unitless.',
          correction: 'Angle (rad), solid angle (sr), and relative humidity (%) have zero dimensions [M⁰L⁰T⁰] yet possess well-defined units.',
        },
        {
          misconception: 'Inserting degrees directly into s = rθ or D = b/θ.',
          correction: 'Always convert degrees or arcseconds into radians (1″ = 4.848 × 10⁻⁶ rad) before using arc-length formulas.',
        },
      ],
      conceptualQuestions: [
        {
          question: 'Can a physical quantity have units without dimensions? Give two examples.',
          answer: 'Yes. Plane angle (radian) and solid angle (steradian) are ratios of lengths or areas, so their dimensions cancel to [M⁰L⁰T⁰], yet they carry units.',
        },
        {
          question: 'Why is platinum-iridium no longer the official definition of the kilogram?',
          answer: 'Physical artifacts drift by tens of micrograms over decades due to surface contamination and cleaning; tying the kg to Planck constant h makes it invariant.',
        },
      ],
      solvedProblemIds: ['ch1-p1', 'ch1-p2'],
      advancedTechniques: [
        'When asked to create a custom unit system (e.g., Force F, Velocity V, Time T as base), express M = F V⁻¹ T, L = V T, and substitute directly into any target formula.',
      ],
      summaryPoints: [
        'Q = n u connects numerical value inversely to unit size.',
        'SI defines 7 base units + 2 supplementary geometric units.',
      ],
      revisionNotes: [
        '1 fermi = 10⁻¹⁵ m, 1 Å = 10⁻¹⁰ m, 1 bar = 10⁵ Pa, 1 eV = 1.602 × 10⁻¹⁹ J.',
        'Parallax: 1 parsec is the distance where 1 AU subtends 1 arcsecond.',
      ],
    },
    {
      id: 'ch1-s2',
      title: '1.2 Precision Instruments: Vernier Calipers & Screw Gauge',
      syllabusTag: 'JEE Main & Adv',
      introductionAndObjectives: [
        'Ordinary metre scales resolve down to 1 mm; engineering and laboratory experiments require 0.1 mm or 0.01 mm precision.',
        'Master least count derivation, positive/negative zero error sign convention, and backlash error prevention.',
      ],
      theoreticalExplanation: {
        foundation:
          'A Vernier Caliper uses a sliding auxiliary Vernier scale alongside a fixed main scale. Because N Vernier Scale Divisions (VSD) match (N − 1) Main Scale Divisions (MSD), each Vernier division is slightly shorter than a main scale division. That small difference is the Least Count (LC).',
        jee_main:
          'For a standard Vernier caliper where n VSD = m MSD (usually m = n − 1, though JEE frequently alters m to n − 2 or n + 1!), LC = 1 MSD − 1 VSD = (1 − m/n) MSD. Total Reading = MSR + (VSR × LC) − Zero Error. Note that if n VSD > n MSD (over-long Vernier), reading rules reverse.',
        jee_advanced:
          'In a Screw Gauge (micrometer), Pitch = distance moved per full rotation of the circular head, and LC = Pitch / Number of Circular Scale Divisions. Zero error is positive if the zero of the circular scale lies below the reference datum line when jaws touch, and negative if above it. Always subtract signed zero error: True = Observed − (Signed Zero Error).',
      },
      definitionsAndPrinciples: [
        {
          term: 'Least Count (LC)',
          definition: 'The smallest measurement an instrument can resolve reliably without estimation.',
        },
        {
          term: 'Positive Zero Error',
          definition: 'Instrument reads a positive value when jaws are closed; must be subtracted from observed readings.',
        },
        {
          term: 'Backlash Error',
          definition: 'Play between screw threads and nut when rotation direction reverses; avoided by rotating the screw in one direction only.',
        },
      ],
      physicalInterpretation:
        'Vernier calipers amplify sub-millimetre gaps visually by noticing which pair of tick marks aligns collinearly, turning a tiny length gap into an easily counted integer index.',
      mathematicalFormulation: [
        {
          label: 'Vernier Least Count',
          latex: '\\text{LC} = 1\\text{ MSD} - 1\\text{ VSD} = \\left(1 - \\frac{m}{n}\\right)\\text{MSD}',
          notes: 'Applies when n VSD = m MSD with m < n.',
        },
        {
          label: 'True Reading with Zero Error',
          latex: 'R_{\\text{true}} = \\text{MSR} + (n_{\\text{coincide}} \\times \\text{LC}) - e_{\\text{zero}}',
          notes: 'Keep sign of e_zero (+ for positive zero error, − for negative zero error).',
        },
        {
          label: 'Screw Gauge Least Count',
          latex: '\\text{LC}_{\\text{sg}} = \\frac{\\text{Pitch}}{N_{\\text{circular}}}',
          notes: 'If screw advances p mm in k rotations, Pitch = p/k.',
        },
      ],
      derivationIds: ['ch1-drv-2'],
      assumptionsAndLimitations: [
        'Assumes uniform thread pitch and zero elastic deformation of jaws under normal ratchet torque.',
        'If m > n in a non-standard Vernier problem, divisions on the Vernier exceed 1 MSD and the backward-reading formula must be derived from alignment geometry.',
      ],
      unitsAndDimensions: [
        { quantity: 'Pitch', siUnit: 'm (commonly mm)', dimensions: '[L]' },
        { quantity: 'Least Count', siUnit: 'm (commonly mm)', dimensions: '[L]' },
      ],
      diagramSpec: {
        title: 'Vernier Caliper Main Scale & Vernier Alignment',
        caption: 'Illustration of MSR + VSR × LC and positive vs negative zero shift.',
        svgType: 'vernier',
      },
      realLifeApplications: [
        'Machining automotive engine pistons and ball bearings to ±0.01 mm tolerances using digital and mechanical micrometers.',
      ],
      importantExamConcepts: [
        'Negative zero error on a screw gauge with N divisions and k-th division above zero line has magnitude −(N − k) × LC.',
        'JEE Advanced often mixes non-standard Vernier scales where 10 VSD = 11 MSD.',
      ],
      commonMistakes: [
        {
          misconception: 'Adding positive zero error instead of subtracting it.',
          correction: 'Positive zero error means the instrument already shows a head-start reading when closed; subtract it: True = Observed − (+e).',
        },
        {
          misconception: 'Taking the circular division k directly as negative zero error.',
          correction: 'If the 96th mark on a 100-division drum aligns with the datum above zero, the error is −(100 − 96) × LC = −4 × LC, NOT −96 × LC.',
        },
      ],
      conceptualQuestions: [
        {
          question: 'Why does a screw gauge feature a ratchet clutch at the end of the thimble?',
          answer: 'To ensure constant, gentle clamping pressure on the specimen so soft wires are not compressed and threads are not strained.',
        },
      ],
      solvedProblemIds: ['ch1-p3', 'ch1-p4'],
      advancedTechniques: [
        'For any unusual Vernier scale where n VSD = m MSD, write the exact distance from main scale zero to the k-th coinciding mark: x + k·VSD = M·MSD.',
      ],
      summaryPoints: [
        'LC = 1 MSD − 1 VSD (Vernier) and Pitch / N (Screw Gauge).',
        'True Reading = Observed Reading − Signed Zero Error.',
      ],
      revisionNotes: [
        'Check zero error sign carefully before substituting into True = MSR + CSR − e.',
      ],
    },
    {
      id: 'ch1-s3',
      title: '1.3 Significant Figures & Error Analysis',
      syllabusTag: 'NCERT + JEE',
      introductionAndObjectives: [
        'No physical measurement is exact; every measurement carries an uncertainty interval.',
        'You will learn significant figure arithmetic rules, absolute/relative/percentage error propagation, and logarithmic differentiation for JEE problems.',
      ],
      theoreticalExplanation: {
        foundation:
          'Significant figures reflect the precision of a measuring device: all reliably known digits plus the first uncertain digit. When adding or subtracting quantities, round to the fewest decimal places. When multiplying or dividing, round to the fewest significant figures.',
        jee_main:
          'Measurements of a quantity x repeated n times yield mean x̄ = (1/n)∑x_i and mean absolute error Δx̄ = (1/n)∑|x_i − x̄|. Fractional error is Δx̄/x̄. For a derived quantity Z = A^p B^q / C^r, maximum fractional error adds constructively: ΔZ/Z = |p|(ΔA/A) + |q|(ΔB/B) + |r|(ΔC/C).',
        jee_advanced:
          'For general differentiable relations f(x, y) = c (like the lens formula 1/f = 1/v − 1/u or parallel resistance 1/R = 1/R₁ + 1/R₂), differentiate implicitly and replace differentials with maximum absolute errors: |Δf|/f² = |Δv|/v² + |Δu|/u². Notice you must NOT apply multiplicative percentage rules across sums or differences directly!',
      },
      definitionsAndPrinciples: [
        {
          term: 'Accuracy vs Precision',
          definition: 'Accuracy measures closeness to the true value; precision measures repeatability and resolution of the instrument.',
        },
        {
          term: 'Systematic Error',
          definition: 'Directional bias (instrumental, zero, or environmental) that can be calibrated out once identified.',
        },
        {
          term: 'Random Error',
          definition: 'Unpredictable fluctuations around the mean; reduced by taking N repeated readings (error scales as 1/√N).',
        },
      ],
      physicalInterpretation:
        'Errors never cancel in worst-case engineering design. Even when dividing two quantities A/B, an underestimate of B combined with an overestimate of A pushes the quotient upward—hence relative errors always add.',
      mathematicalFormulation: [
        {
          label: 'Power-Law Error Propagation',
          latex: 'Z = \\frac{A^p B^q}{C^r} \\implies \\frac{\\Delta Z}{Z} = p\\frac{\\Delta A}{A} + q\\frac{\\Delta B}{B} + r\\frac{\\Delta C}{C}',
          notes: 'Assumes independent small errors (ΔA ≪ A); valid up to ~5–10% fractional error.',
        },
        {
          label: 'Sum / Difference Error',
          latex: 'Z = A \\pm B \\implies \\Delta Z = \\Delta A + \\Delta B',
          notes: 'Absolute errors ALWAYS add even for subtraction A − B.',
        },
      ],
      derivationIds: ['ch1-drv-3'],
      assumptionsAndLimitations: [
        'Linear differential propagation (ΔZ/Z ≈ dZ/Z) breaks down for large percentage errors (>10%), where exact min/max bounds Z_max − Z_min must be evaluated.',
      ],
      unitsAndDimensions: [
        { quantity: 'Absolute Error (Δx)', siUnit: 'Same as x', dimensions: 'Same as x' },
        { quantity: 'Relative Error (Δx/x)', siUnit: 'Unitless', dimensions: '[M⁰L⁰T⁰]' },
      ],
      diagramSpec: {
        title: 'Error Propagation & Distribution Bounds',
        caption: 'Random scatter around true mean and worst-case error envelope.',
        svgType: 'error_bars',
      },
      realLifeApplications: [
        'Bridge and spacecraft structural safety factors combine worst-case tolerances in load, Young’s modulus, and beam cross-sections.',
      ],
      importantExamConcepts: [
        'Percentage error in kinetic energy K = p²/(2m): if momentum p changes by 100% (large change!), do NOT use ΔK/K = 2Δp/p; compute (p_new² − p²)/p² = 300%!',
        'Rounding off digit 5: if preceding digit is odd, round up; if even, leave unchanged.',
      ],
      commonMistakes: [
        {
          misconception: 'Using ΔK/K = 2(Δp/p) when momentum increases by 50% or 100%.',
          correction: 'Differential formulas apply only to small errors (<5%). For large changes, compute exact ratio (1.5² − 1) = 125%.',
        },
        {
          misconception: 'Subtracting errors in Z = A − B.',
          correction: 'In Z = A − B, worst-case error is ΔZ = ΔA + ΔB, which can produce a huge percentage error if A ≈ B.',
        },
      ],
      conceptualQuestions: [
        {
          question: 'Why are trailing zeros in 4.200 m significant while those in 4200 m (without decimal) are ambiguous?',
          answer: 'Trailing zeros after a decimal point explicitly show instrument resolution down to the millimetre, whereas integer trailing zeros may only hold place value.',
        },
      ],
      solvedProblemIds: ['ch1-p5'],
      advancedTechniques: [
        'For implicit relations such as 1/R = 1/R₁ + 1/R₂, compute dR/R² = dR₁/R₁² + dR₂/R₂², then multiply through by R to find ΔR/R.',
      ],
      summaryPoints: [
        'Absolute errors add for sums/differences; relative errors add (weighted by exponents) for products/quotients.',
        'Large percentage changes require exact algebraic evaluation, not differentials.',
      ],
      revisionNotes: [
        'Rule of 5 rounding: Even stays, Odd goes up.',
        'Power rule: Δ(xⁿ)/xⁿ = |n|(Δx/x).',
      ],
    },
    {
      id: 'ch1-s4',
      title: '1.4 Dimensional Analysis & Buckingham Pi Enrichment',
      syllabusTag: 'Enrichment',
      introductionAndObjectives: [
        'Dimensions reveal the structural DNA of every physical law.',
        'Learn the Principle of Dimensional Homogeneity, derive unknown power-law relations, convert units, and explore the Buckingham Pi Theorem (Enrichment).',
      ],
      theoreticalExplanation: {
        foundation:
          'Every physical quantity can be written as powers of fundamental dimensions [M^a L^b T^c ...]. Only quantities with identical dimensions can be added, subtracted, or equated—this is the Principle of Homogeneity.',
        jee_main:
          'Arguments of transcendental functions (sin θ, cos ωt, e^(-λt), ln(x/x₀)) MUST be completely dimensionless [M⁰L⁰T⁰]. This fact alone lets you deduce dimensions of arbitrary constants inside equations (e.g., α and β in F = α sin(βt)).',
        jee_advanced:
          'Buckingham Pi Theorem (Enrichment): If a physical phenomenon involves n dimensional variables built from k independent fundamental dimensions, the system reduces to (n − k) independent dimensionless Π-groups. This explains why dimensional analysis can find T ∝ √(l/g) uniquely (n=3, k=2 ⇒ 1 group) but cannot determine dimensionless constants like 2π or handle additive terms.',
      },
      definitionsAndPrinciples: [
        {
          term: 'Principle of Dimensional Homogeneity',
          definition: 'Every valid physical equation must have identical dimensional formulas on both sides and across every summed term.',
        },
        {
          term: 'Buckingham Pi Theorem (Enrichment)',
          definition: 'Any dimensionally homogeneous relation among n variables with k independent dimensions is equivalent to Φ(Π₁, Π₂, ..., Π_{n-k}) = 0.',
        },
      ],
      physicalInterpretation:
        'Dimensional homogeneity guarantees that physical laws remain true regardless of whether an observer measures in SI, CGS, or astronomical units.',
      mathematicalFormulation: [
        {
          label: 'Dimensional Equivalence',
          latex: '[Q] = [M^a L^b T^c]',
          notes: 'Equate exponents on LHS and RHS to solve up to 3 independent unknowns (4 with current/temperature).',
        },
        {
          label: 'Transcendental Argument Rule',
          latex: '[\\omega t] = [M^0 L^0 T^0] \\implies [\\omega] = [T^{-1}]',
          notes: 'Applies to all trigonometric, exponential, and logarithmic arguments.',
        },
      ],
      derivationIds: ['ch1-drv-4'],
      assumptionsAndLimitations: [
        'Cannot determine pure numerical constants (e.g., 1/2, 2π, 6π).',
        'Cannot distinguish between different quantities sharing identical dimensions (e.g., Work vs Torque, or Pressure vs Energy Density).',
        'Fails when a formula depends on more than 3 mechanical variables unless extra dimensions (K, A) or dimensionless groups are introduced.',
      ],
      unitsAndDimensions: [
        { quantity: 'Universal Gravitational Constant (G)', siUnit: 'N·m²/kg²', dimensions: '[M⁻¹L³T⁻²]' },
        { quantity: 'Planck Constant (h)', siUnit: 'J·s', dimensions: '[M¹L²T⁻¹]' },
        { quantity: 'Coefficient of Viscosity (η)', siUnit: 'Pa·s', dimensions: '[M¹L⁻¹T⁻¹]' },
        { quantity: 'Surface Tension (σ)', siUnit: 'N/m', dimensions: '[M¹L⁰T⁻²]' },
      ],
      diagramSpec: {
        title: 'Dimensional Basis Transformation Matrix',
        caption: 'Mapping fundamental dimensions {M, L, T} into arbitrary basis {E, v, T}.',
        svgType: 'error_bars',
      },
      realLifeApplications: [
        'Aerospace engineers test scale-model aircraft in wind tunnels by matching the dimensionless Reynolds number and Mach number.',
      ],
      importantExamConcepts: [
        'G, h, c combinations yield Planck Length l_P = √(ħG/c³), Planck Mass m_P = √(ħc/G), Planck Time t_P = √(ħG/c⁵).',
        'Van der Waals constants: [a] = [P V²] = [M L⁵ T⁻²], [b] = [V] = [L³].',
      ],
      commonMistakes: [
        {
          misconception: 'Assuming a dimensionally correct equation is physically true.',
          correction: 's = ut + at² is dimensionally consistent yet misses the factor 1/2. Dimensional correctness is necessary, not sufficient.',
        },
      ],
      conceptualQuestions: [
        {
          question: 'Why does dimensional analysis fail to derive s = ut + ½at² in one step?',
          answer: 'Because dimensional analysis produces only single multiplicative monomials, not sums of distinct terms.',
        },
      ],
      solvedProblemIds: ['ch1-p6'],
      advancedTechniques: [
        'Use exponent matrices and determinants to quickly check if three chosen quantities {X, Y, Z} can serve as a complete mechanical basis.',
      ],
      summaryPoints: [
        'Match powers of M, L, T across every term and inside transcendental functions.',
        'Dimensional analysis discovers scaling laws up to a dimensionless constant.',
      ],
      revisionNotes: [
        '[Energy] = [Torque] = [M L² T⁻²]; [Stress] = [Pressure] = [Energy density] = [M L⁻¹ T⁻²].',
        '[Planck constant h] = [Angular momentum] = [M L² T⁻¹].',
      ],
    },
  ],
  derivations: [
    {
      id: 'ch1-drv-1',
      chapterId: 'ch1',
      title: 'Unit Conversion Between Arbitrary Systems via Dimensional Formula',
      physicalPrinciple: 'Physical magnitude Q is invariant under change of unit size.',
      assumptions: ['Both unit systems are coherent and share the same fundamental dimension set {M, L, T}.'],
      symbols: [
        { symbol: 'n₁, n₂', meaning: 'Numerical values in systems 1 and 2', unit: 'dimensionless' },
        { symbol: 'M₁, L₁, T₁', meaning: 'Base units of mass, length, time in system 1', unit: 'base' },
        { symbol: 'a, b, c', meaning: 'Dimensional exponents of the physical quantity', unit: 'real' },
      ],
      steps: [
        {
          stepNumber: 1,
          equationLatex: 'Q = n_1 u_1 = n_2 u_2',
          transformationNote: 'State the invariance of physical magnitude.',
        },
        {
          stepNumber: 2,
          equationLatex: 'u_1 = M_1^a L_1^b T_1^c, \\quad u_2 = M_2^a L_2^b T_2^c',
          transformationNote: 'Express both units in terms of their fundamental base dimensions.',
        },
        {
          stepNumber: 3,
          equationLatex: 'n_2 = n_1 \\frac{u_1}{u_2} = n_1 \\left(\\frac{M_1}{M_2}\\right)^a \\left(\\frac{L_1}{L_2}\\right)^b \\left(\\frac{T_1}{T_2}\\right)^c',
          transformationNote: 'Isolate n₂ by dividing both sides by u₂ and grouping identical dimensional bases.',
        },
      ],
      finalResultLatex: 'n_2 = n_1 \\left(\\frac{M_1}{M_2}\\right)^a \\left(\\frac{L_1}{L_2}\\right)^b \\left(\\frac{T_1}{T_2}\\right)^c',
      physicalSignificance: 'Allows instant conversion from SI to CGS or custom experimental unit systems without memorizing separate conversion tables.',
      validityConditions: ['Applicable only to multiplicative coherent units (not offset scales like °C to K).'],
      workedExample: {
        statement: 'Convert 1 Newton (SI) into dynes (CGS).',
        solution: '[F] = [M¹ L¹ T⁻²] ⇒ a=1, b=1, c=-2. n₂ = 1 × (1 kg / 1 g)¹ × (1 m / 1 cm)¹ × (1 s / 1 s)⁻² = 10³ × 10² × 1 = 10⁵.',
        answer: '1 N = 10⁵ dyne',
      },
    },
    {
      id: 'ch1-drv-2',
      chapterId: 'ch1',
      title: 'Least Count of a Generalized Vernier Caliper',
      physicalPrinciple: 'Differential scale division mismatch amplifies sub-millimetre offsets.',
      assumptions: ['n Vernier scale divisions exactly coincide with m main scale divisions (m < n).'],
      symbols: [
        { symbol: '1 MSD', meaning: 'Length of one Main Scale Division', unit: 'mm' },
        { symbol: '1 VSD', meaning: 'Length of one Vernier Scale Division', unit: 'mm' },
        { symbol: 'LC', meaning: 'Least Count', unit: 'mm' },
      ],
      steps: [
        {
          stepNumber: 1,
          equationLatex: 'n \\,(1\\text{ VSD}) = m \\,(1\\text{ MSD})',
          transformationNote: 'Equate total lengths of coinciding scale spans.',
        },
        {
          stepNumber: 2,
          equationLatex: '1\\text{ VSD} = \\frac{m}{n}\\,(1\\text{ MSD})',
          transformationNote: 'Solve for the length of a single Vernier division.',
        },
        {
          stepNumber: 3,
          equationLatex: '\\text{LC} = 1\\text{ MSD} - 1\\text{ VSD} = \\left(1 - \\frac{m}{n}\\right)\\text{MSD} = \\frac{n - m}{n}\\text{MSD}',
          transformationNote: 'Take the difference between 1 MSD and 1 VSD.',
        },
      ],
      finalResultLatex: '\\text{LC} = \\left(\\frac{n - m}{n}\\right) \\text{MSD}',
      physicalSignificance: 'Shifting the Vernier jaw by 1 LC moves the 1st Vernier mark into alignment with the next Main Scale mark.',
      validityConditions: ['Valid when m < n (standard forward-reading Vernier).'],
      workedExample: {
        statement: 'If 20 VSD = 19 MSD and 1 MSD = 1 mm, find the Least Count.',
        solution: 'LC = ((20 - 19)/20) × 1 mm = 1/20 mm = 0.05 mm.',
        answer: '0.05 mm',
      },
    },
    {
      id: 'ch1-drv-3',
      chapterId: 'ch1',
      title: 'Maximum Fractional Error in a Power-Law Physical Quantity',
      physicalPrinciple: 'Logarithmic differentiation converts products and powers into linear sums of relative errors.',
      assumptions: ['Uncertainties Δa, Δb, Δc are small compared to mean values a, b, c and independent.'],
      symbols: [
        { symbol: 'Z', meaning: 'Derived quantity Z = a^p b^q / c^r', unit: 'varies' },
        { symbol: 'Δa, Δb, Δc', meaning: 'Absolute errors in measured quantities', unit: 'varies' },
      ],
      steps: [
        {
          stepNumber: 1,
          equationLatex: 'Z = \\frac{a^p b^q}{c^r} \\implies \\ln Z = p\\ln a + q\\ln b - r\\ln c',
          transformationNote: 'Take natural logarithm on both sides to separate multiplicative factors.',
        },
        {
          stepNumber: 2,
          equationLatex: '\\frac{dZ}{Z} = p\\frac{da}{a} + q\\frac{db}{b} - r\\frac{dc}{c}',
          transformationNote: 'Differentiate both sides using d(ln u) = du/u.',
        },
        {
          stepNumber: 3,
          equationLatex: '\\left(\\frac{\\Delta Z}{Z}\\right)_{\\max} = |p|\\frac{\\Delta a}{a} + |q|\\frac{\\Delta b}{b} + |r|\\frac{\\Delta c}{c}',
          transformationNote: 'Replace differentials with finite errors and take absolute signs for worst-case constructive combination.',
        },
      ],
      finalResultLatex: '\\frac{\\Delta Z}{Z} = |p|\\frac{\\Delta a}{a} + |q|\\frac{\\Delta b}{b} + |r|\\frac{\\Delta c}{c}',
      physicalSignificance: 'Shows that higher-exponent variables dominate uncertainty—precision should be invested first in measuring variables with the largest exponent.',
      validityConditions: ['Valid for fractional errors typically below 5%.'],
      workedExample: {
        statement: 'Find % error in kinetic energy K = ½mv² if mass error is 2% and speed error is 3%.',
        solution: 'ΔK/K = Δm/m + 2(Δv/v) = 2% + 2(3%) = 8%.',
        answer: '8%',
      },
    },
    {
      id: 'ch1-drv-4',
      chapterId: 'ch1',
      title: 'Dimensional Derivation of Simple Pendulum Time Period',
      physicalPrinciple: 'Principle of Dimensional Homogeneity applied to oscillatory mechanics.',
      assumptions: ['Time period T depends only on length l, mass m, and gravitational acceleration g for small oscillations.'],
      symbols: [
        { symbol: 'T', meaning: 'Time period of oscillation', unit: 's' },
        { symbol: 'l', meaning: 'Effective length of pendulum', unit: 'm' },
        { symbol: 'g', meaning: 'Acceleration due to gravity', unit: 'm/s²' },
        { symbol: 'k', meaning: 'Dimensionless proportionality constant', unit: '1' },
      ],
      steps: [
        {
          stepNumber: 1,
          equationLatex: 'T = k \\, l^a \\, g^b \\, m^c',
          transformationNote: 'Write trial power-law dependence with unknown exponents a, b, c.',
        },
        {
          stepNumber: 2,
          equationLatex: '[M^0 L^0 T^1] = [L]^a [L T^{-2}]^b [M]^c = [M^c L^{a+b} T^{-2b}]',
          transformationNote: 'Substitute dimensional formulas on both sides.',
        },
        {
          stepNumber: 3,
          equationLatex: 'c = 0, \\quad -2b = 1 \\implies b = -\\frac{1}{2}, \\quad a + b = 0 \\implies a = \\frac{1}{2}',
          transformationNote: 'Equate exponents of M, T, and L respectively.',
        },
      ],
      finalResultLatex: 'T = k\\sqrt{\\frac{l}{g}} \\quad (\\text{experimentally } k = 2\\pi)',
      physicalSignificance: 'Proves immediately that time period is independent of bob mass m and scales with the square root of length.',
      validityConditions: ['Amplitude θ₀ ≪ 1 rad; constant k = 2π requires differential equation solution.'],
      workedExample: {
        statement: 'If length of a pendulum is quadrupled, by what factor does T change?',
        solution: 'T_new / T = √(4l / l) = 2.',
        answer: 'Doubles (factor of 2)',
      },
    },
  ],
  solvedProblems: [
    {
      id: 'ch1-p1',
      chapterId: 'ch1',
      subtopicId: 'ch1-s1',
      category: 'Basic Conceptual',
      level: 'foundation',
      statement: 'If the unit of length is doubled and the unit of time is halved, what happens to the numerical value of an acceleration of 10 m/s²?',
      givenData: ['a₁ = 10 m/s²', 'L₂ = 2 L₁', 'T₂ = 0.5 T₁'],
      requiredQuantity: 'Numerical value n₂ in the new system',
      physicsConcept: 'Principle of unit invariance Q = n₁u₁ = n₂u₂',
      applicableEquationsLatex: ['n_2 = n_1 \\left(\\frac{L_1}{L_2}\\right)^1 \\left(\\frac{T_1}{T_2}\\right)^{-2}'],
      steps: [
        'Write dimensional formula of acceleration: [a] = [L¹ T⁻²].',
        'Substitute L₁/L₂ = 1/2 and T₁/T₂ = 2 into the conversion formula.',
        'n₂ = 10 × (1/2)¹ × (2)⁻² = 10 × (1/2) × (1/4) = 1.25.',
      ],
      finalAnswer: '1.25 new units',
      strategyExplanation: 'Always keep exponents attached to (old unit / new unit) ratios to avoid inverting factors by mistake.',
    },
    {
      id: 'ch1-p2',
      chapterId: 'ch1',
      subtopicId: 'ch1-s1',
      category: 'Foundation Numerical',
      level: 'foundation',
      statement: 'A distant planet subtends an angle of 40 arcseconds at an Earth telescope. If the distance to the planet is 6.0 × 10¹¹ m, calculate its diameter.',
      givenData: ['θ = 40″', 'D = 6.0 × 10¹¹ m', '1″ = 4.848 × 10⁻⁶ rad'],
      requiredQuantity: 'Diameter d of the planet',
      physicsConcept: 'Small-angle parallax geometry d = D θ',
      applicableEquationsLatex: ['d = D\\theta'],
      steps: [
        'Convert angular diameter to radians: θ = 40 × 4.848 × 10⁻⁶ = 1.939 × 10⁻⁴ rad.',
        'Compute d = (6.0 × 10¹¹ m) × (1.939 × 10⁻⁴ rad) = 1.163 × 10⁸ m.',
      ],
      finalAnswer: '1.16 × 10⁸ m',
      strategyExplanation: 'Never plug degrees or arcseconds directly into arc length formulas; convert to radians first.',
    },
    {
      id: 'ch1-p3',
      chapterId: 'ch1',
      subtopicId: 'ch1-s2',
      category: 'JEE Main',
      level: 'jee_main',
      statement: 'In a Vernier caliper, 1 MSD = 1 mm and 10 VSD coincide with 9 MSD. While measuring a cylinder diameter, MSR is 2.4 cm, the 6th VSD coincides, and the instrument has a positive zero error of +0.3 mm. Find the true diameter.',
      givenData: ['1 MSD = 1 mm', '10 VSD = 9 MSD', 'MSR = 24 mm', 'VSR = 6', 'e = +0.3 mm'],
      requiredQuantity: 'True diameter D',
      physicsConcept: 'Vernier least count and signed zero error correction',
      applicableEquationsLatex: ['\\text{LC} = 1\\text{ MSD} - 1\\text{ VSD}', 'D = \\text{MSR} + (\\text{VSR} \\times \\text{LC}) - e'],
      steps: [
        'Calculate Least Count: LC = 1 mm − (9/10) mm = 0.1 mm.',
        'Compute Observed Reading = 24 mm + (6 × 0.1 mm) = 24.6 mm.',
        'Subtract signed zero error: D = 24.6 mm − (+0.3 mm) = 24.3 mm = 2.43 cm.',
      ],
      finalAnswer: '2.43 cm (24.3 mm)',
      strategyExplanation: 'Convert MSR to mm before combining with LC in mm, then convert the final result to the requested unit.',
    },
    {
      id: 'ch1-p4',
      chapterId: 'ch1',
      subtopicId: 'ch1-s2',
      category: 'JEE Advanced',
      level: 'jee_advanced',
      statement: 'A screw gauge has a pitch of 0.5 mm and 50 divisions on its circular scale. When jaws touch, the zero of the circular scale is 4 divisions above the reference line. For a wire, the main scale reads 2.5 mm and the 32nd circular division aligns. Find the wire diameter.',
      givenData: ['Pitch = 0.5 mm', 'N = 50', '4 divisions above datum ⇒ negative zero error', 'MSR = 2.5 mm', 'CSR = 32'],
      requiredQuantity: 'True wire diameter d',
      physicsConcept: 'Screw gauge least count & negative zero error correction',
      applicableEquationsLatex: ['\\text{LC} = \\frac{0.5}{50}\\text{ mm} = 0.01\\text{ mm}', 'd = \\text{MSR} + (\\text{CSR}\\times\\text{LC}) - e'],
      steps: [
        'Find LC = 0.5 mm / 50 = 0.01 mm.',
        'Zero line is 4 divisions above datum, so zero error is negative: e = −4 × 0.01 mm = −0.04 mm.',
        'Observed reading = 2.5 mm + (32 × 0.01 mm) = 2.82 mm.',
        'True reading = 2.82 mm − (−0.04 mm) = 2.86 mm.',
      ],
      finalAnswer: '2.86 mm',
      strategyExplanation: 'Remember: circular zero above datum = negative zero error (subtracting a negative adds the magnitude).',
    },
    {
      id: 'ch1-p5',
      chapterId: 'ch1',
      subtopicId: 'ch1-s3',
      category: 'Multi-Concept',
      level: 'jee_main',
      statement: 'A physical quantity P is related to four observables a, b, c, d as P = (a³ b²) / (√c · d). The percentage errors in measuring a, b, c, d are 1%, 3%, 4%, and 2% respectively. Find the maximum percentage error in P.',
      givenData: ['Δa/a = 1%', 'Δb/b = 3%', 'Δc/c = 4%', 'Δd/d = 2%'],
      requiredQuantity: 'Maximum percentage error in P',
      physicsConcept: 'Power-law error propagation',
      applicableEquationsLatex: ['\\frac{\\Delta P}{P} = 3\\frac{\\Delta a}{a} + 2\\frac{\\Delta b}{b} + \\frac{1}{2}\\frac{\\Delta c}{c} + 1\\frac{\\Delta d}{d}'],
      steps: [
        'Write exponents constructively: 3 for a, 2 for b, 1/2 for √c, and 1 for d.',
        'Substitute percentages: 3(1%) + 2(3%) + 0.5(4%) + 1(2%) = 3% + 6% + 2% + 2% = 13%.',
      ],
      finalAnswer: '13%',
      strategyExplanation: 'Denominator variables still add positively to the maximum uncertainty.',
    },
    {
      id: 'ch1-p6',
      chapterId: 'ch1',
      subtopicId: 'ch1-s4',
      category: 'Challenging Mathematical',
      level: 'jee_advanced',
      statement: 'If Energy (E), Velocity (v), and Time (T) are chosen as fundamental physical quantities, find the dimensional formula of Surface Tension (σ).',
      givenData: ['Fundamental basis = {E, v, T}', 'Target = Surface Tension σ = Force / Length'],
      requiredQuantity: 'Dimensions of σ in terms of [E, v, T]',
      physicsConcept: 'Change of dimensional basis',
      applicableEquationsLatex: ['[\\sigma] = [E^x v^y T^z]'],
      steps: [
        'Express σ in {M, L, T}: [σ] = [F]/[L] = [M L T⁻²]/[L] = [M¹ L⁰ T⁻²].',
        'Express basis in {M, L, T}: [E] = [M L² T⁻²], [v] = [L T⁻¹], [T] = [T].',
        'Notice σ = Energy / Area = E / L², and since L = v T, we have σ = E / (v T)² = E v⁻² T⁻².',
        'Verify: [E¹ v⁻² T⁻²] = [M L² T⁻²][L⁻² T²][T⁻²] = [M¹ L⁰ T⁻²]. Exact match!',
      ],
      finalAnswer: '[E¹ v⁻² T⁻²]',
      strategyExplanation: 'Often physical identities (like σ = Energy/Area and L = vT) solve basis-change problems in 10 seconds instead of solving 3×3 linear systems.',
    },
  ],
  formulas: [
    {
      id: 'ch1-f1',
      chapterId: 'ch1',
      name: 'Unit Invariance Relation',
      latex: 'n_1 u_1 = n_2 u_2',
      symbols: [
        { symbol: 'n', meaning: 'Numerical magnitude' },
        { symbol: 'u', meaning: 'Unit size' },
      ],
      siUnit: 'Invariant',
      dimensions: 'Same as quantity',
      interpretation: 'Larger units yield proportionally smaller numerical values.',
      validity: 'Proportional coherent units without zero offset.',
      relatedDerivationId: 'ch1-drv-1',
      isImportant: true,
    },
    {
      id: 'ch1-f2',
      chapterId: 'ch1',
      name: 'Vernier Caliper Least Count',
      latex: '\\text{LC} = 1\\text{ MSD} - 1\\text{ VSD} = \\left(1 - \\frac{m}{n}\\right)\\text{MSD}',
      symbols: [
        { symbol: 'n', meaning: 'Vernier divisions' },
        { symbol: 'm', meaning: 'Coinciding main scale divisions' },
      ],
      siUnit: 'm (or mm)',
      dimensions: '[L]',
      interpretation: 'Smallest measurable length difference using scale alignment.',
      validity: 'When n VSD = m MSD with m < n.',
      relatedDerivationId: 'ch1-drv-2',
      isImportant: true,
    },
    {
      id: 'ch1-f3',
      chapterId: 'ch1',
      name: 'Screw Gauge Least Count',
      latex: '\\text{LC} = \\frac{\\text{Pitch}}{N_{\\text{circular}}}',
      symbols: [
        { symbol: 'Pitch', meaning: 'Linear advance per full rotation' },
        { symbol: 'N', meaning: 'Circular scale divisions' },
      ],
      siUnit: 'm (or mm)',
      dimensions: '[L]',
      interpretation: 'Linear axial advance per single circular division turn.',
      validity: 'Negligible backlash error.',
      isImportant: true,
    },
    {
      id: 'ch1-f4',
      chapterId: 'ch1',
      name: 'Power-Law Error Propagation',
      latex: '\\frac{\\Delta Z}{Z} = |p|\\frac{\\Delta A}{A} + |q|\\frac{\\Delta B}{B} + |r|\\frac{\\Delta C}{C}',
      symbols: [
        { symbol: 'Z', meaning: 'A^p B^q / C^r' },
        { symbol: 'ΔZ/Z', meaning: 'Maximum fractional error' },
      ],
      siUnit: 'Dimensionless',
      dimensions: '[M⁰L⁰T⁰]',
      interpretation: 'Fractional uncertainties scale by exponent magnitudes and add constructively.',
      validity: 'Small independent fractional errors (< 5%).',
      relatedDerivationId: 'ch1-drv-3',
      isImportant: true,
    },
    {
      id: 'ch1-f5',
      chapterId: 'ch1',
      name: 'Parallax Astronomical Distance',
      latex: 'D = \\frac{b}{\\theta}',
      symbols: [
        { symbol: 'b', meaning: 'Baseline length' },
        { symbol: 'θ', meaning: 'Parallax angle in radians' },
      ],
      siUnit: 'm',
      dimensions: '[L]',
      interpretation: 'Converts small angular shifts across a wide baseline into huge distances.',
      validity: 'Small-angle approximation b ≪ D, θ in radians.',
      isImportant: false,
    },
  ],
  flashcards: [
    {
      id: 'ch1-fc1',
      chapterId: 'ch1',
      category: 'Dimensional Formula',
      front: 'Dimensional formula of Universal Gravitational Constant G',
      back: '[M⁻¹ L³ T⁻²] — derived from F = G m₁ m₂ / r² ⇒ G = F r² / m².',
      latex: '[G] = [M^{-1} L^3 T^{-2}]',
    },
    {
      id: 'ch1-fc2',
      chapterId: 'ch1',
      category: 'Dimensional Formula',
      front: 'Dimensional formula of Planck Constant h',
      back: '[M¹ L² T⁻¹] — identical to Angular Momentum L = mvr.',
      latex: '[h] = [M L^2 T^{-1}]',
    },
    {
      id: 'ch1-fc3',
      chapterId: 'ch1',
      category: 'Common Mistake',
      front: 'When finding True Reading with positive zero error (+e), do you add or subtract e?',
      back: 'Always SUBTRACT the signed zero error: True Reading = Observed Reading − (+e).',
      latex: 'R_{\\text{true}} = R_{\\text{obs}} - e_{\\text{zero}}',
    },
    {
      id: 'ch1-fc4',
      chapterId: 'ch1',
      category: 'Constant',
      front: 'Value of 1 Parsec in metres and light-years',
      back: '1 parsec = 3.08 × 10¹⁶ m ≈ 3.26 light-years (distance where 1 AU subtends 1 arcsecond).',
    },
    {
      id: 'ch1-fc5',
      chapterId: 'ch1',
      category: 'JEE Concept',
      front: 'What must be the dimensions of the argument (kx − ωt) inside sin(kx − ωt)?',
      back: 'Completely dimensionless [M⁰ L⁰ T⁰]. Therefore [k] = [L⁻¹] and [ω] = [T⁻¹].',
      latex: '[kx - \\omega t] = [M^0 L^0 T^0]',
    },
  ],
  mindMapBranches: [
    {
      id: 'ch1-mm-1',
      title: 'SI Units & Measurement',
      category: 'Subtopic',
      summary: 'Seven base units anchored to universal constants plus supplementary angular units.',
      equations: ['n_1 u_1 = n_2 u_2', 'D = b/\\theta'],
      children: [
        { id: 'ch1-mm-1a', title: '7 Base Units', detail: 'kg, m, s, A, K, mol, cd' },
        { id: 'ch1-mm-1b', title: 'Supplementary Units', detail: 'rad (plane angle), sr (solid angle)' },
        { id: 'ch1-mm-1c', title: 'Parallax & Astronomy', detail: '1 AU = 1.496×10¹¹ m, 1 pc = 3.26 ly', latex: 'D = \\frac{b}{\\theta}' },
      ],
    },
    {
      id: 'ch1-mm-2',
      title: 'Vernier & Screw Gauge',
      category: 'Application',
      summary: 'Sub-millimetre metrology via differential division alignment and screw pitch.',
      equations: ['\\text{LC} = 1\\text{ MSD} - 1\\text{ VSD}', '\\text{LC}_{\\text{sg}} = \\text{Pitch}/N'],
      children: [
        { id: 'ch1-mm-2a', title: 'Vernier Caliper', detail: 'True = MSR + VSR×LC − e_zero', latex: '\\text{LC} = (1 - m/n)\\text{MSD}' },
        { id: 'ch1-mm-2b', title: 'Screw Gauge', detail: 'Watch positive vs negative zero error & backlash', latex: 'd = \\text{MSR} + \\text{CSR}\\times\\text{LC} - e' },
      ],
    },
    {
      id: 'ch1-mm-3',
      title: 'Errors & Significant Figures',
      category: 'Exam Concept',
      summary: 'Uncertainty propagation across arithmetic operations and rounding rules.',
      equations: ['\\Delta Z = \\Delta A + \\Delta B', '\\frac{\\Delta Z}{Z} = |p|\\frac{\\Delta A}{A} + |q|\\frac{\\Delta B}{B}'],
      children: [
        { id: 'ch1-mm-3a', title: 'Mean & Absolute Error', detail: 'Average deviations give random error bound' },
        { id: 'ch1-mm-3b', title: 'Power-Law Propagation', detail: 'Multiply fractional error by |exponent|' },
        { id: 'ch1-mm-3c', title: 'Large % Changes', detail: 'Use exact algebraic ratio, NOT differentials' },
      ],
    },
    {
      id: 'ch1-mm-4',
      title: 'Dimensional Analysis',
      category: 'Equation',
      summary: 'Homogeneity checks, unit conversions, basis change, and Buckingham Pi theorem.',
      equations: ['[\\text{LHS}] = [\\text{RHS}]', 'T = k\\sqrt{l/g}'],
      children: [
        { id: 'ch1-mm-4a', title: 'Homogeneity Principle', detail: 'Only like dimensions can add or equate' },
        { id: 'ch1-mm-4b', title: 'Transcendental Functions', detail: 'Arguments of sin, exp, ln are dimensionless' },
        { id: 'ch1-mm-4c', title: 'Buckingham Pi (Enrichment)', detail: '(n − k) dimensionless Π-groups' },
      ],
    },
  ],
};
