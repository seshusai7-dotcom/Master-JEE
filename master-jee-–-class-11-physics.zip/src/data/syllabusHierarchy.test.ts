import test from 'node:test';
import assert from 'node:assert/strict';
import { SYLLABUS_HIERARCHY, getSyllabusStats } from './syllabusHierarchy';
import { ALL_CHAPTERS } from './curriculumIndex';
import { buildFirestoreSyllabusPayloads } from '../lib/syllabusPayloads';

const VALID_ID = /^[a-zA-Z0-9_-]+$/;

test('syllabus hierarchy covers all 14 Class 11 Physics chapters in exact NCERT order', () => {
  assert.equal(SYLLABUS_HIERARCHY.length, 14);
  SYLLABUS_HIERARCHY.forEach((ch, idx) => {
    assert.equal(ch.chapterNumber, idx + 1);
    assert.equal(ch.chapterId, `ch${idx + 1}`);
    assert.ok(ch.topics.length >= 2, `Chapter ${ch.chapterId} should have >= 2 topics`);
  });

  const stats = getSyllabusStats(SYLLABUS_HIERARCHY);
  assert.ok(stats.topicCount >= 35, `Expected >= 35 topics across 14 chapters, got ${stats.topicCount}`);
  assert.ok(stats.subtopicCount >= 70, `Expected >= 70 subtopics across 14 chapters, got ${stats.subtopicCount}`);
  assert.ok(stats.enrichmentSubtopics >= 5, 'Enrichment subtopics must be explicitly identified');
});

test('every topic and subtopic links to a valid textbook module and obeys Firestore schema constraints', () => {
  for (const ch of SYLLABUS_HIERARCHY) {
    const chapterData = ALL_CHAPTERS.find((c) => c.id === ch.chapterId);
    assert.ok(chapterData, `Missing textbook chapter ${ch.chapterId}`);
    const validSubtopicIds = new Set(chapterData.subtopics.map((s) => s.id));

    const payloads = buildFirestoreSyllabusPayloads(ch, 'admin-uid-test');
    assert.equal(payloads.chapterDoc.topicCount, ch.topics.length);
    assert.ok(VALID_ID.test(payloads.chapterDoc.chapterId));
    assert.ok(payloads.chapterDoc.overview.length <= 1200);

    for (const topic of ch.topics) {
      assert.ok(VALID_ID.test(topic.topicId));
      assert.ok(
        validSubtopicIds.has(topic.linkedContentSubtopicId),
        `Topic ${topic.topicId} linked missing subtopic ${topic.linkedContentSubtopicId}`
      );
      assert.ok(topic.subtopics.length >= 2, `Topic ${topic.topicId} must have >= 2 subtopics`);

      for (const st of topic.subtopics) {
        assert.ok(VALID_ID.test(st.subtopicId));
        assert.ok(
          validSubtopicIds.has(st.linkedContentSubtopicId),
          `Subtopic ${st.subtopicId} linked missing subtopic ${st.linkedContentSubtopicId}`
        );
        assert.ok(st.keyConcepts.length >= 1 && st.keyConcepts.length <= 10);
        if (st.enrichmentOnly) {
          assert.equal(st.ncertAligned, false);
        }
      }
    }

    assert.equal(payloads.topicDocs.length, ch.topics.length);
    assert.equal(payloads.subtopicDocs.length, payloads.chapterDoc.subtopicCount);
  }
});
