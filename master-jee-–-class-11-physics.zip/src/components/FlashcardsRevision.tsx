import { useMemo, useState } from 'react';
import { RotateCw, Trash2, Plus, BookMarked } from 'lucide-react';
import { ALL_CHAPTERS, getAllFlashcards } from '../data/curriculumIndex';
import { useApp } from '../context/AppContext';
import { MathFormula, MathText } from './MathBlock';
import { computeNextFlashcardReview, type SpacedRating } from '../utils/physicsMath';

export function FlashcardsRevision() {
  const {
    flashcardProgress,
    updateFlashcardProgress,
    notes,
    saveNote,
    deleteNote,
    profile,
  } = useApp();

  const [tab, setTab] = useState<'flashcards' | 'notes' | 'mistakes'>('flashcards');
  const [chapterFilter, setChapterFilter] = useState<string>('all');
  const [cardIdx, setCardIdx] = useState(0);
  const [flipped, setFlipped] = useState(false);

  const [noteTitle, setNoteTitle] = useState('');
  const [noteBody, setNoteBody] = useState('');
  const [noteChapter, setNoteChapter] = useState('ch1');
  const [noteCategory, setNoteCategory] = useState<'note' | 'bookmark' | 'mistake'>('note');

  const allCards = useMemo(() => getAllFlashcards(), []);
  const deck = allCards.filter((c) => chapterFilter === 'all' || c.chapterId === chapterFilter);
  const currentCard = deck[cardIdx % Math.max(1, deck.length)];

  const handleRateCard = async (rating: SpacedRating) => {
    if (!currentCard) return;
    const prevBox = flashcardProgress[currentCard.id]?.box ?? 1;
    const next = computeNextFlashcardReview(prevBox, rating);
    await updateFlashcardProgress({
      cardId: currentCard.id,
      chapterId: currentCard.chapterId,
      box: next.box,
      nextReviewEpochMs: next.nextReviewEpochMs,
    });
    setFlipped(false);
    setCardIdx((i) => (i + 1) % Math.max(1, deck.length));
  };

  const handleAddNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteTitle.trim() || !noteBody.trim()) return;
    await saveNote({
      noteId: `note-${Date.now()}`,
      chapterId: noteChapter,
      category: noteCategory,
      title: noteTitle.trim(),
      body: noteBody.trim(),
    });
    setNoteTitle('');
    setNoteBody('');
  };

  const filteredNotes = notes.filter((n) =>
    tab === 'mistakes' ? n.category === 'mistake' : n.category !== 'mistake'
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#0B1F3A]">
            Flashcards &amp; Revision Centre
          </h1>
          <p className="mt-1 text-sm text-slate-600">
            Spaced-repetition active recall, personal notes, bookmarks, and your Mistake Notebook.
            Daily target: {profile.dailyTargetQuestions} questions.
          </p>
        </div>

        <div className="inline-flex p-1 bg-slate-100 rounded-xl w-fit">
          <button
            type="button"
            onClick={() => setTab('flashcards')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold ${
              tab === 'flashcards' ? 'bg-[#0B1F3A] text-white' : 'text-slate-600'
            }`}
          >
            Spaced Flashcards
          </button>
          <button
            type="button"
            onClick={() => setTab('notes')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold ${
              tab === 'notes' ? 'bg-[#0B1F3A] text-white' : 'text-slate-600'
            }`}
          >
            Notes &amp; Bookmarks ({notes.filter((n) => n.category !== 'mistake').length})
          </button>
          <button
            type="button"
            onClick={() => setTab('mistakes')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold ${
              tab === 'mistakes' ? 'bg-[#0B1F3A] text-white' : 'text-slate-600'
            }`}
          >
            Mistake Notebook ({notes.filter((n) => n.category === 'mistake').length})
          </button>
        </div>
      </div>

      {tab === 'flashcards' ? (
        <div className="space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <select
              aria-label="Filter flashcards by chapter"
              value={chapterFilter}
              onChange={(e) => {
                setChapterFilter(e.target.value);
                setCardIdx(0);
                setFlipped(false);
              }}
              className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
            >
              <option value="all">All 14 Chapters ({allCards.length} cards)</option>
              {ALL_CHAPTERS.map((c) => (
                <option key={c.id} value={c.id}>
                  Ch {c.number}: {c.title}
                </option>
              ))}
            </select>
            <span className="text-xs font-mono text-slate-500 tabular-nums">
              Card {(cardIdx % Math.max(1, deck.length)) + 1} of {deck.length}
            </span>
          </div>

          {currentCard && (
            <div className="rounded-2xl border border-slate-200 bg-white p-8 max-w-2xl mx-auto space-y-6">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span>{currentCard.category}</span>
                <span>Box {flashcardProgress[currentCard.id]?.box ?? 1} / 6</span>
              </div>

              <div className="min-h-40 flex flex-col items-center justify-center text-center space-y-4">
                <p className="text-lg font-bold text-[#0B1F3A]">{currentCard.front}</p>
                {flipped && (
                  <div className="w-full pt-4 border-t border-slate-100 space-y-2">
                    <p className="text-sm text-slate-700 leading-relaxed">
                      <MathText text={currentCard.back} />
                    </p>
                    {currentCard.latex && <MathFormula latex={currentCard.latex} display />}
                  </div>
                )}
              </div>

              <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
                {!flipped ? (
                  <button
                    type="button"
                    onClick={() => setFlipped(true)}
                    className="px-5 py-2.5 rounded-lg bg-[#0B1F3A] text-white text-sm font-semibold inline-flex items-center gap-2"
                  >
                    <RotateCw className="w-4 h-4" />
                    <span>Reveal Answer</span>
                  </button>
                ) : (
                  <>
                    {(
                      [
                        { id: 'again', label: 'Again (15m)', cls: 'border-red-300 bg-red-50 text-red-800' },
                        { id: 'hard', label: 'Hard (12h)', cls: 'border-amber-300 bg-amber-50 text-amber-900' },
                        { id: 'good', label: 'Good (1–3d)', cls: 'border-cyan-300 bg-cyan-50 text-cyan-900' },
                        { id: 'easy', label: 'Easy (7d+)', cls: 'border-emerald-300 bg-emerald-50 text-emerald-900' },
                      ] as const
                    ).map((r) => (
                      <button
                        key={r.id}
                        type="button"
                        onClick={() => handleRateCard(r.id)}
                        className={`px-3.5 py-2 rounded-lg border text-xs font-semibold ${r.cls}`}
                      >
                        {r.label}
                      </button>
                    ))}
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Add Note Form */}
          <form
            onSubmit={handleAddNote}
            className="lg:col-span-5 rounded-xl border border-slate-200 bg-white p-5 space-y-3 h-fit"
          >
            <h2 className="text-base font-bold text-[#0B1F3A] flex items-center gap-2">
              <BookMarked className="w-4 h-4 text-cyan-700" />
              <span>Add Revision Entry</span>
            </h2>
            <div>
              <label htmlFor="note-ch" className="block text-xs font-semibold text-slate-600 mb-1">
                Chapter
              </label>
              <select
                id="note-ch"
                value={noteChapter}
                onChange={(e) => setNoteChapter(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              >
                {ALL_CHAPTERS.map((c) => (
                  <option key={c.id} value={c.id}>
                    Ch {c.number}: {c.title}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="note-cat" className="block text-xs font-semibold text-slate-600 mb-1">
                Entry Type
              </label>
              <select
                id="note-cat"
                value={noteCategory}
                onChange={(e) => setNoteCategory(e.target.value as 'note' | 'bookmark' | 'mistake')}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              >
                <option value="note">Personal Study Note</option>
                <option value="bookmark">Formula / Concept Bookmark</option>
                <option value="mistake">Mistake Notebook Entry</option>
              </select>
            </div>
            <div>
              <label htmlFor="note-title" className="block text-xs font-semibold text-slate-600 mb-1">
                Title
              </label>
              <input
                id="note-title"
                type="text"
                required
                value={noteTitle}
                onChange={(e) => setNoteTitle(e.target.value)}
                placeholder="e.g., Parallel Axis Theorem Trap"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label htmlFor="note-body" className="block text-xs font-semibold text-slate-600 mb-1">
                Notes / Derivation Key
              </label>
              <textarea
                id="note-body"
                required
                rows={4}
                value={noteBody}
                onChange={(e) => setNoteBody(e.target.value)}
                placeholder="Write key equations, mistakes to avoid, or quick revision summary..."
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2.5 rounded-lg bg-[#0B1F3A] text-white text-xs font-semibold inline-flex items-center justify-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Save Entry</span>
            </button>
          </form>

          {/* Saved Entries */}
          <div className="lg:col-span-7 space-y-3">
            {filteredNotes.length === 0 ? (
              <div className="rounded-xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-500">
                No entries recorded in this section yet.
              </div>
            ) : (
              filteredNotes.map((n) => (
                <article key={n.noteId} className="rounded-xl border border-slate-200 bg-white p-4 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="text-xs text-slate-500 uppercase font-semibold">
                        {n.chapterId.toUpperCase()} · {n.category}
                      </p>
                      <h3 className="text-sm font-bold text-[#0B1F3A]">{n.title}</h3>
                    </div>
                    <button
                      type="button"
                      aria-label={`Delete ${n.title}`}
                      onClick={() => deleteNote(n.noteId)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <p className="text-sm text-slate-700 whitespace-pre-wrap leading-relaxed">
                    <MathText text={n.body} />
                  </p>
                </article>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
