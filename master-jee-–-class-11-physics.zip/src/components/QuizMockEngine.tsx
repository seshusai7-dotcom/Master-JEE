import { useEffect, useMemo, useState } from 'react';
import { Clock, Flag, CheckCircle2, RotateCcw, BookmarkPlus } from 'lucide-react';
import { ALL_CHAPTERS } from '../data/curriculumIndex';
import { useApp } from '../context/AppContext';
import { MathText } from './MathBlock';
import { evaluateQuizSubmission, type AnswerSubmission, type QuizEvaluationResult } from '../utils/physicsMath';
import type { QuestionEntry } from '../types/physics';

type ExamMode = 'topic_quiz' | 'chapter_test' | 'mock_main' | 'mock_advanced';

const RESUME_KEY = 'master_jee_saved_exam_v1';

export function QuizMockEngine() {
  const { allQuestions, activeChapterId, recordAttempt, saveNote } = useApp();

  const [mode, setMode] = useState<ExamMode>('chapter_test');
  const [selectedChapter, setSelectedChapter] = useState<string>(activeChapterId);
  const [negativeMarking, setNegativeMarking] = useState<number>(1);
  const [durationMinutes, setDurationMinutes] = useState<number>(15);

  const [examStarted, setExamStarted] = useState(false);
  const [examQuestions, setExamQuestions] = useState<QuestionEntry[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<string, AnswerSubmission>>({});
  const [markedForReview, setMarkedForReview] = useState<string[]>([]);
  const [secondsLeft, setSecondsLeft] = useState(900);
  const [result, setResult] = useState<QuizEvaluationResult | null>(null);
  const [hasSavedResume, setHasSavedResume] = useState(false);
  const [mistakeSavedBanner, setMistakeSavedBanner] = useState<string | null>(null);

  useEffect(() => {
    try {
      const saved = localStorage.getItem(RESUME_KEY);
      if (saved) setHasSavedResume(true);
    } catch {
      // ignore
    }
  }, []);

  const buildQuestionsForMode = (chosenMode: ExamMode, chapId: string): QuestionEntry[] => {
    let pool =
      chosenMode === 'mock_main' || chosenMode === 'mock_advanced'
        ? allQuestions
        : allQuestions.filter((q) => q.chapterId === chapId);

    if (pool.length === 0) {
      pool = allQuestions;
    }
    const shuffled = [...pool].sort(() => Math.random() - 0.5);
    const limitCount = chosenMode === 'topic_quiz' ? 4 : chosenMode === 'chapter_test' ? 5 : 10;
    return shuffled.slice(0, Math.min(limitCount, shuffled.length));
  };

  const startExam = () => {
    const qs = buildQuestionsForMode(mode, selectedChapter);
    setExamQuestions(qs);
    setCurrentIdx(0);
    setAnswers({});
    setMarkedForReview([]);
    setSecondsLeft(durationMinutes * 60);
    setResult(null);
    setMistakeSavedBanner(null);
    setExamStarted(true);
  };

  const saveAndPause = () => {
    try {
      localStorage.setItem(
        RESUME_KEY,
        JSON.stringify({
          mode,
          selectedChapter,
          negativeMarking,
          durationMinutes,
          examQuestions,
          currentIdx,
          answers,
          markedForReview,
          secondsLeft,
        })
      );
      setHasSavedResume(true);
      setExamStarted(false);
    } catch {
      // ignore
    }
  };

  const resumeSavedExam = () => {
    try {
      const raw = localStorage.getItem(RESUME_KEY);
      if (!raw) return;
      const data = JSON.parse(raw);
      setMode(data.mode);
      setSelectedChapter(data.selectedChapter);
      setNegativeMarking(data.negativeMarking);
      setDurationMinutes(data.durationMinutes);
      setExamQuestions(data.examQuestions);
      setCurrentIdx(data.currentIdx);
      setAnswers(data.answers);
      setMarkedForReview(data.markedForReview);
      setSecondsLeft(data.secondsLeft);
      setResult(null);
      setExamStarted(true);
    } catch {
      // ignore
    }
  };

  const submitExam = async () => {
    if (result) return;
    const evalResult = evaluateQuizSubmission(examQuestions, answers, {
      positiveMarks: 4,
      negativeMarks: negativeMarking,
    });
    setResult(evalResult);
    localStorage.removeItem(RESUME_KEY);
    setHasSavedResume(false);

    const chObj = ALL_CHAPTERS.find((c) => c.id === selectedChapter);
    await recordAttempt({
      attemptId: `att-${Date.now()}`,
      chapterId: mode.startsWith('mock') ? 'mixed' : selectedChapter,
      chapterTitle: mode.startsWith('mock')
        ? mode === 'mock_main'
          ? 'JEE Main Practice Mock'
          : 'JEE Advanced Practice Mock'
        : chObj?.title ?? 'Chapter Quiz',
      mode,
      score: evalResult.score,
      maxScore: evalResult.maxScore,
      accuracyPct: evalResult.accuracyPct,
      timeSpentSec: Math.max(1, durationMinutes * 60 - secondsLeft),
      totalQuestions: examQuestions.length,
      correctCount: evalResult.correctCount,
      wrongCount: evalResult.wrongCount,
      unattemptedCount: evalResult.unattemptedCount,
      weakTopics: evalResult.weakTopics,
      createdAtIso: new Date().toISOString(),
    });
  };

  // Countdown Timer
  useEffect(() => {
    if (!examStarted || result) return;
    const timer = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          submitExam();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [examStarted, result]);

  const currentQuestion = examQuestions[currentIdx];

  const saveMistakesToVault = async () => {
    if (!result) return;
    const wrongOnes = examQuestions.filter((q) => result.perQuestionCorrect[q.id] === false);
    for (const q of wrongOnes) {
      await saveNote({
        noteId: `mistake-${q.id}-${Date.now()}`,
        chapterId: q.chapterId,
        category: 'mistake',
        title: `Review: ${q.topicId.replace(/_/g, ' ')} (${q.exam})`,
        body: `${q.prompt}\n\nSolution: ${q.solution}`,
      });
    }
    setMistakeSavedBanner(`Saved ${wrongOnes.length} missed question(s) to Mistake Notebook.`);
  };

  const formattedClock = useMemo(() => {
    const m = Math.floor(secondsLeft / 60);
    const s = secondsLeft % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }, [secondsLeft]);

  if (!examStarted) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-[#0B1F3A]">
            Quiz &amp; JEE Mock Examination Center
          </h1>
          <p className="mt-1 text-sm text-slate-600">
            Simulated practice tests with NTA-style question palette, review marking, negative
            marking, and weak-topic diagnostics. (Practice simulations, not official historical exam
            papers.)
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label htmlFor="quiz-mode" className="block text-xs font-semibold text-slate-600 mb-1">
                Assessment Type
              </label>
              <select
                id="quiz-mode"
                value={mode}
                onChange={(e) => setMode(e.target.value as ExamMode)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
              >
                <option value="topic_quiz">Topic Quick Quiz</option>
                <option value="chapter_test">Chapter Test</option>
                <option value="mock_main">JEE Main-Style Mock Test</option>
                <option value="mock_advanced">JEE Advanced-Style Mock Test</option>
              </select>
            </div>

            <div>
              <label htmlFor="quiz-chapter" className="block text-xs font-semibold text-slate-600 mb-1">
                Target Chapter
              </label>
              <select
                id="quiz-chapter"
                value={selectedChapter}
                disabled={mode.startsWith('mock')}
                onChange={(e) => setSelectedChapter(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm disabled:opacity-50"
              >
                {ALL_CHAPTERS.map((c) => (
                  <option key={c.id} value={c.id}>
                    Ch {c.number}: {c.title}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="quiz-neg" className="block text-xs font-semibold text-slate-600 mb-1">
                Marking Scheme
              </label>
              <select
                id="quiz-neg"
                value={negativeMarking}
                onChange={(e) => setNegativeMarking(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
              >
                <option value={1}>Standard JEE (+4 / −1)</option>
                <option value={0}>Practice Mode (+4 / 0)</option>
              </select>
            </div>

            <div>
              <label htmlFor="quiz-time" className="block text-xs font-semibold text-slate-600 mb-1">
                Time Limit
              </label>
              <select
                id="quiz-time"
                value={durationMinutes}
                onChange={(e) => setDurationMinutes(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm tabular-nums"
              >
                <option value={10}>10 Minutes</option>
                <option value={15}>15 Minutes</option>
                <option value={30}>30 Minutes</option>
                <option value={60}>60 Minutes (Full Physics)</option>
              </select>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              type="button"
              onClick={startExam}
              className="px-5 py-2.5 rounded-lg bg-[#0B1F3A] hover:bg-[#132D52] text-white text-sm font-semibold whitespace-nowrap"
            >
              Start Practice Examination
            </button>
            {hasSavedResume && (
              <button
                type="button"
                onClick={resumeSavedExam}
                className="px-4 py-2.5 rounded-lg border border-cyan-600 text-cyan-800 hover:bg-cyan-50 text-sm font-semibold whitespace-nowrap"
              >
                Resume Saved Test
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (result) {
    return (
      <div className="space-y-6">
        <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="text-xs font-medium text-slate-500">
                Practice Examination Scorecard (Simulated Test)
              </p>
              <h1 className="text-2xl font-bold text-[#0B1F3A]">
                Score: {result.score} / {result.maxScore}
              </h1>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {result.wrongCount > 0 && (
                <button
                  type="button"
                  onClick={saveMistakesToVault}
                  className="px-4 py-2 rounded-lg border border-amber-300 bg-amber-50 text-amber-900 text-xs font-semibold inline-flex items-center gap-1.5"
                >
                  <BookmarkPlus className="w-4 h-4" />
                  <span>Add Missed to Mistake Notebook</span>
                </button>
              )}
              <button
                type="button"
                onClick={() => setExamStarted(false)}
                className="px-4 py-2 rounded-lg bg-[#0B1F3A] text-white text-xs font-semibold inline-flex items-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>New Test</span>
              </button>
            </div>
          </div>

          {mistakeSavedBanner && (
            <div className="rounded-lg bg-emerald-50 border border-emerald-200 px-4 py-2.5 text-xs font-semibold text-emerald-800">
              {mistakeSavedBanner}
            </div>
          )}

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
            <div className="rounded-lg bg-slate-50 p-3.5 border border-slate-200">
              <p className="text-xs text-slate-500">Accuracy</p>
              <p className="text-lg font-bold text-[#0B1F3A] tabular-nums">{result.accuracyPct}%</p>
            </div>
            <div className="rounded-lg bg-emerald-50 p-3.5 border border-emerald-200">
              <p className="text-xs text-emerald-700">Correct</p>
              <p className="text-lg font-bold text-emerald-800 tabular-nums">{result.correctCount}</p>
            </div>
            <div className="rounded-lg bg-red-50 p-3.5 border border-red-200">
              <p className="text-xs text-red-700">Incorrect</p>
              <p className="text-lg font-bold text-red-800 tabular-nums">{result.wrongCount}</p>
            </div>
            <div className="rounded-lg bg-slate-50 p-3.5 border border-slate-200">
              <p className="text-xs text-slate-500">Unattempted</p>
              <p className="text-lg font-bold text-slate-700 tabular-nums">{result.unattemptedCount}</p>
            </div>
          </div>

          {/* Solution Review */}
          <div className="space-y-3 pt-4 border-t border-slate-200">
            <h2 className="text-base font-bold text-[#0B1F3A]">Detailed Solution Review</h2>
            {examQuestions.map((q, idx) => {
              const status = result.perQuestionCorrect[q.id];
              return (
                <div key={q.id} className="rounded-lg border border-slate-200 p-4 space-y-2 text-sm">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-600">
                      Q{idx + 1} · {q.exam}
                    </span>
                    <span
                      className={`font-bold ${
                        status === true
                          ? 'text-emerald-700'
                          : status === false
                            ? 'text-red-700'
                            : 'text-slate-500'
                      }`}
                    >
                      {status === true ? 'Correct (+4)' : status === false ? `Wrong (−${negativeMarking})` : 'Unattempted (0)'}
                    </span>
                  </div>
                  <p className="font-medium text-[#0B1F3A]">
                    <MathText text={q.prompt} />
                  </p>
                  <p className="text-slate-700 bg-slate-50 p-3 rounded border border-slate-200/70">
                    <MathText text={q.solution} />
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  const isNumerical =
    currentQuestion?.format === 'numerical' || currentQuestion?.format === 'integer';
  const isMulti = currentQuestion?.format === 'multiple_mcq';
  const currentAns = answers[currentQuestion?.id ?? ''] ?? {};
  const isMarked = markedForReview.includes(currentQuestion?.id ?? '');

  const handleSelectOption = (optIdx: number) => {
    if (!currentQuestion) return;
    setAnswers((prev) => {
      const existing = prev[currentQuestion.id]?.selectedOptionIndices ?? [];
      const next = isMulti
        ? existing.includes(optIdx)
          ? existing.filter((x) => x !== optIdx)
          : [...existing, optIdx]
        : [optIdx];
      return { ...prev, [currentQuestion.id]: { selectedOptionIndices: next } };
    });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Main Question Panel */}
      <div className="lg:col-span-8 rounded-xl border border-slate-200 bg-white p-6 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="text-xs font-semibold text-slate-600">
            Question {currentIdx + 1} of {examQuestions.length} · Practice Test
          </div>
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1.5 font-mono text-sm font-bold text-[#0B1F3A] tabular-nums">
              <Clock className="w-4 h-4 text-cyan-700" />
              <span>{formattedClock}</span>
            </span>
            <button
              type="button"
              onClick={saveAndPause}
              className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-50"
            >
              Save &amp; Pause
            </button>
          </div>
        </div>

        {currentQuestion && (
          <div className="space-y-4">
            <p className="text-xs text-slate-500">
              {currentQuestion.exam} · {currentQuestion.format.replace('_', ' ')} ·{' '}
              {currentQuestion.difficulty.replace('_', ' ')}
            </p>
            <div className="text-base font-medium text-[#0B1F3A] leading-relaxed">
              <MathText text={currentQuestion.prompt} />
            </div>

            {isNumerical ? (
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  step="any"
                  value={currentAns.numericalInput ?? ''}
                  onChange={(e) =>
                    setAnswers((prev) => ({
                      ...prev,
                      [currentQuestion.id]: { numericalInput: e.target.value },
                    }))
                  }
                  placeholder="Enter numerical response"
                  className="rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm font-mono w-64"
                />
                {currentQuestion.unit && (
                  <span className="text-xs font-mono text-slate-500">{currentQuestion.unit}</span>
                )}
              </div>
            ) : (
              <div className="space-y-2.5">
                {(currentQuestion.options ?? []).map((opt, idx) => {
                  const active = (currentAns.selectedOptionIndices ?? []).includes(idx);
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleSelectOption(idx)}
                      className={`w-full text-left rounded-lg border px-4 py-3 text-sm transition-colors ${
                        active
                          ? 'border-cyan-600 bg-cyan-50 text-[#0B1F3A] font-semibold'
                          : 'border-slate-200 hover:bg-slate-50 text-slate-800'
                      }`}
                    >
                      <span className="font-mono text-xs text-slate-500 mr-2">
                        ({String.fromCharCode(65 + idx)})
                      </span>
                      <MathText text={opt} />
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        )}

        <div className="flex flex-wrap items-center justify-between gap-2 pt-4 border-t border-slate-100">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                if (!currentQuestion) return;
                setMarkedForReview((prev) =>
                  prev.includes(currentQuestion.id)
                    ? prev.filter((id) => id !== currentQuestion.id)
                    : [...prev, currentQuestion.id]
                );
              }}
              className={`px-3 py-2 rounded-lg text-xs font-semibold border inline-flex items-center gap-1.5 ${
                isMarked
                  ? 'bg-amber-50 border-amber-300 text-amber-800'
                  : 'border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Flag className="w-3.5 h-3.5" />
              <span>{isMarked ? 'Marked for Review' : 'Mark for Review'}</span>
            </button>
            <button
              type="button"
              onClick={() => {
                if (!currentQuestion) return;
                setAnswers((prev) => {
                  const copy = { ...prev };
                  delete copy[currentQuestion.id];
                  return copy;
                });
              }}
              className="px-3 py-2 rounded-lg border border-slate-200 text-xs font-medium text-slate-600 hover:bg-slate-50"
            >
              Clear
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={currentIdx === 0}
              onClick={() => setCurrentIdx((i) => Math.max(0, i - 1))}
              className="px-3.5 py-2 rounded-lg border border-slate-200 text-xs font-semibold disabled:opacity-40"
            >
              Previous
            </button>
            {currentIdx < examQuestions.length - 1 ? (
              <button
                type="button"
                onClick={() => setCurrentIdx((i) => Math.min(examQuestions.length - 1, i + 1))}
                className="px-4 py-2 rounded-lg bg-[#0B1F3A] text-white text-xs font-semibold"
              >
                Save &amp; Next
              </button>
            ) : (
              <button
                type="button"
                onClick={submitExam}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold inline-flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Submit Test</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Question Palette */}
      <aside className="lg:col-span-4 rounded-xl border border-slate-200 bg-white p-5 space-y-4 h-fit">
        <h2 className="text-sm font-bold text-[#0B1F3A]">Question Palette</h2>
        <div className="grid grid-cols-5 gap-2">
          {examQuestions.map((q, idx) => {
            const sub = answers[q.id];
            const answered = Boolean(
              (sub?.selectedOptionIndices && sub.selectedOptionIndices.length > 0) ||
                (sub?.numericalInput && sub.numericalInput.trim() !== '')
            );
            const marked = markedForReview.includes(q.id);
            const active = idx === currentIdx;

            return (
              <button
                key={q.id}
                type="button"
                onClick={() => setCurrentIdx(idx)}
                className={`h-10 rounded-lg text-xs font-bold tabular-nums border transition-colors ${
                  active ? 'ring-2 ring-cyan-600 ' : ''
                }${
                  marked
                    ? 'bg-amber-100 border-amber-400 text-amber-900'
                    : answered
                      ? 'bg-emerald-600 border-emerald-600 text-white'
                      : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                {idx + 1}
              </button>
            );
          })}
        </div>

        <div className="text-xs text-slate-600 space-y-1 pt-2 border-t border-slate-100">
          <p>Green: Answered · Amber: Marked for Review · Slate: Not Visited</p>
        </div>

        <button
          type="button"
          onClick={submitExam}
          className="w-full py-2.5 rounded-lg bg-[#0B1F3A] hover:bg-[#132D52] text-white text-xs font-semibold"
        >
          Finish &amp; Submit Examination
        </button>
      </aside>
    </div>
  );
}
