import React, { useMemo } from 'react';
import katex from 'katex';

export function MathFormula({
  latex,
  display = false,
  className = '',
}: {
  latex: string;
  display?: boolean;
  className?: string;
}) {
  const html = useMemo(() => {
    try {
      return katex.renderToString(latex, {
        displayMode: display,
        throwOnError: false,
        strict: false,
      });
    } catch {
      return latex;
    }
  }, [latex, display]);

  if (display) {
    return (
      <div
        className={`my-2 overflow-x-auto rounded-lg bg-slate-50 px-3 py-2 border border-slate-200 text-slate-900 ${className}`}
        dangerouslySetInnerHTML={{ __html: html }}
      />
    );
  }

  return (
    <span
      className={`inline-block align-middle ${className}`}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}

export function MathText({
  text,
  className = '',
}: {
  text: string;
  className?: string;
}) {
  const segments = useMemo(() => {
    if (!text) return [];
    const tokens: { type: 'text' | 'inline' | 'display'; value: string }[] = [];
    const regex = /(\$\$[\s\S]+?\$\$|\$[^$\n]+?\$)/g;
    let lastIdx = 0;
    let match: RegExpExecArray | null;

    while ((match = regex.exec(text)) !== null) {
      if (match.index > lastIdx) {
        tokens.push({ type: 'text', value: text.slice(lastIdx, match.index) });
      }
      const raw = match[0];
      if (raw.startsWith('$$') && raw.endsWith('$$')) {
        tokens.push({ type: 'display', value: raw.slice(2, -2).trim() });
      } else {
        tokens.push({ type: 'inline', value: raw.slice(1, -1).trim() });
      }
      lastIdx = regex.lastIndex;
    }
    if (lastIdx < text.length) {
      tokens.push({ type: 'text', value: text.slice(lastIdx) });
    }
    return tokens;
  }, [text]);

  return (
    <span className={className}>
      {segments.map((seg, i) => {
        if (seg.type === 'display') {
          return <MathFormula key={i} latex={seg.value} display />;
        }
        if (seg.type === 'inline') {
          return <MathFormula key={i} latex={seg.value} display={false} />;
        }
        return <React.Fragment key={i}>{seg.value}</React.Fragment>;
      })}
    </span>
  );
}
