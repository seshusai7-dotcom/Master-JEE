import { useMemo, useState } from 'react';
import {
  BookOpen,
  FlaskConical,
  Brain,
  ClipboardCheck,
  Network,
  Calculator,
  Flame,
  ArrowRight,
  Layers,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import { useApp } from '../context/AppContext';
import { ALL_CHAPTERS } from '../data/curriculumIndex';
import type { AcademicLevel } from '../types/physics';

const LEVEL_OPTIONS: { id: AcademicLevel; label: string; desc: string }[] = [
  { id: 'foundation', label: 'Level 1 · Foundation', desc: 'Core NCERT concepts & units' },
  { id: 'jee_main', label: 'Level 2 · JEE Main', desc: 'Standard derivations & numericals' },
  { id: 'jee_advanced', label: 'Level 3 · JEE Advanced', desc: 'Multi-concept & analytical rigor' },
];

export function StudentDashboard() {
  const {
    profile,
    academicLevel,
    setAcademicLevel,
    completedSubtopics,
    attempts,
    notes,
    setActiveScreen,
    setActiveChapterId,
  } = useApp();
  const [bannerError, setBannerError] = useState(false);

  const totalSubtopics = useMemo(
    () => ALL_CHAPTERS.reduce((acc, ch) => acc + ch.subtopics.length, 0),
    []
  );

  const completedChaptersCount = useMemo(
    () =>
      ALL_CHAPTERS.filter((ch) =>
        ch.subtopics.every((s) => completedSubtopics.includes(s.id))
      ).length,
    [completedSubtopics]
  );

  const avgAccuracy = useMemo(() => {
    if (attempts.length === 0) return 0;
    const sum = attempts.reduce((acc, a) => acc + a.accuracyPct, 0);
    return Math.round(sum / attempts.length);
  }, [attempts]);

  const totalAttemptedQuestions = useMemo(
    () => attempts.reduce((acc, a) => acc + a.totalQuestions, 0),
    [attempts]
  );

  const chartData = useMemo(() => {
    const ordered = [...attempts].reverse().slice(-8);
    return ordered.map((a, idx) => ({
      name: `Test ${idx + 1}`,
      accuracy: a.accuracyPct,
      scorePct: Math.round((a.score / Math.max(1, a.maxScore)) * 100),
    }));
  }, [attempts]);

  const weakTopicList = useMemo(() => {
    const labelMap: Record<string, string> = {
      vernier: 'Vernier Calipers & Zero Error',
      projectile: 'Projectile Range & Trajectory',
      dimensional_analysis: 'Dimensional Analysis',
      rotational_dynamics: 'Moment of Inertia & Rolling',
      thermodynamics: 'First Law & PV Work',
      shm: 'Simple Harmonic Oscillations',
    };
    const counts: Record<string, number> = {};
    for (const a of attempts) {
      for (const w of a.weakTopics) {
        counts[w] = (counts[w] || 0) + 1;
      }
    }
    const entries = Object.entries(counts).sort((a, b) => b[1] - a[1]);
    if (entries.length === 0) return ['Vernier Calipers & Zero Error', 'Projectile Range & Trajectory'];
    return entries.map(([k]) => labelMap[k.toLowerCase()] ?? k.replace(/_/g, ' '));
  }, [attempts]);

  return (
    <div className="space-y-8">
      {/* Hero Banner Split */}
      <section className="rounded-2xl bg-[#0B1F3A] text-white overflow-hidden border border-[#1E3A5F]">
        <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
          <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-between space-y-5">
            <div className="space-y-2">
              <p className="text-xs font-medium text-cyan-300">
                Dr. V. Sesha Sai Kumar · GRIET, Hyderabad
              </p>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-balance">
                Welcome back, {profile.displayName.split('(')[0].trim()}
              </h1>
              <p className="text-sm text-slate-300 max-w-xl leading-relaxed">
                Continue your Class 11 Physics mastery across all 14 syllabus chapters, interactive
                laboratories, and verified JEE question banks.
              </p>
            </div>

            {/* Academic Level Switcher */}
            <div className="space-y-2">
              <span className="text-xs font-medium text-slate-300 block">
                Active Academic Difficulty Tier
              </span>
              <div className="grid grid-cols-3 sm:inline-flex gap-1 p-1 rounded-xl bg-white/10 border border-white/10">
                {LEVEL_OPTIONS.map((opt) => {
                  const active = academicLevel === opt.id;
                  const shortLabel =
                    opt.id === 'foundation'
                      ? 'Foundation'
                      : opt.id === 'jee_main'
                        ? 'JEE Main'
                        : 'JEE Adv';
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setAcademicLevel(opt.id)}
                      className={`px-2 sm:px-3 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap text-center ${
                        active
                          ? 'bg-cyan-500 text-[#0B1F3A]'
                          : 'text-slate-200 hover:bg-white/10'
                      }`}
                    >
                      <span className="sm:hidden">{shortLabel}</span>
                      <span className="hidden sm:inline">{opt.label}</span>
                    </button>
                  );
                })}
              </div>
              <p className="text-xs text-cyan-200/80">
                {LEVEL_OPTIONS.find((o) => o.id === academicLevel)?.desc}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => {
                  setActiveChapterId('ch1');
                  setActiveScreen('reader');
                }}
                className="px-4 py-2.5 rounded-lg bg-white text-[#0B1F3A] hover:bg-slate-100 text-sm font-semibold inline-flex items-center gap-2 transition-colors whitespace-nowrap"
              >
                <BookOpen className="w-4 h-4" />
                <span>Open Chapter 1 Textbook</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setActiveScreen('lab')}
                className="px-4 py-2.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-sm font-medium inline-flex items-center gap-2 transition-colors whitespace-nowrap"
              >
                <FlaskConical className="w-4 h-4 text-cyan-300" />
                <span>Launch Virtual Lab</span>
              </button>
            </div>
          </div>

          <div className="lg:col-span-5 flex items-center justify-center bg-[#08172C] p-3 lg:p-4">
            {!bannerError ? (
              <div className="aspect-video w-full overflow-hidden rounded-xl border border-white/10 bg-[#08172C]">
                <img
                  src="/src/assets/images/hero_physics_blueprint_1794843531983.jpg"
                  alt="Physics mechanics and instrumentation schematic"
                  referrerPolicy="no-referrer"
                  onError={() => setBannerError(true)}
                  className="w-full h-full object-contain"
                />
              </div>
            ) : (
              <div className="w-full h-full flex items-center justify-center p-6 text-cyan-200 text-sm">
                Classical Mechanics &amp; Measurement Blueprint
              </div>
            )}
          </div>
        </div>
      </section>

      {/* 4-Column KPI Row Below Hero */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-xs text-slate-500 font-medium">Syllabus Mastery</p>
          <p className="mt-1 text-2xl font-bold text-[#0B1F3A] tabular-nums">
            {completedChaptersCount} / {ALL_CHAPTERS.length} Ch
          </p>
          <p className="mt-1 text-xs text-slate-500 tabular-nums">
            {completedSubtopics.length} of {totalSubtopics} topics completed
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-xs text-slate-500 font-medium">Assessment Accuracy</p>
          <p className="mt-1 text-2xl font-bold text-[#0B1F3A] tabular-nums">{avgAccuracy}%</p>
          <p className="mt-1 text-xs text-slate-500 tabular-nums">
            {totalAttemptedQuestions} questions evaluated
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-xs text-slate-500 font-medium">Study Streak</p>
          <p className="mt-1 text-2xl font-bold text-[#0B1F3A] tabular-nums flex items-center gap-1.5">
            <Flame className="w-5 h-5 text-amber-500" />
            <span>{profile.streakDays} Days</span>
          </p>
          <p className="mt-1 text-xs text-slate-500 tabular-nums">
            {Math.round(profile.totalStudyMinutes / 60)} hrs total focus time
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-xs text-slate-500 font-medium">Revision Vault</p>
          <p className="mt-1 text-2xl font-bold text-[#0B1F3A] tabular-nums">
            {notes.length} Entries
          </p>
          <p className="mt-1 text-xs text-slate-500">Notes, bookmarks &amp; mistakes</p>
        </div>
      </section>

      {/* Quick Modules Grid */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-[#0B1F3A]">Core Learning Modules</h2>
          <button
            type="button"
            onClick={() => setActiveScreen('chapters')}
            className="text-xs font-semibold text-cyan-700 hover:text-cyan-800 whitespace-nowrap"
          >
            View all 14 chapters →
          </button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            {
              title: '14-Chapter Textbook',
              meta: 'Sections A–Q · Derivations · Problems',
              screen: 'chapters' as const,
              icon: BookOpen,
            },
            {
              title: 'Interactive Mind Maps',
              meta: 'Zoomable concept graphs & equations',
              screen: 'mindmap' as const,
              icon: Network,
            },
            {
              title: 'Formula Library',
              meta: 'SI units · Dimensions · Bookmarks',
              screen: 'formulas' as const,
              icon: Calculator,
            },
            {
              title: 'AI Physics Tutor',
              meta: 'Hint-first derivations & problem help',
              screen: 'tutor' as const,
              icon: Brain,
            },
            {
              title: 'Mock Tests & Quizzes',
              meta: 'JEE palette · Negative marking',
              screen: 'quiz' as const,
              icon: ClipboardCheck,
            },
            {
              title: 'Virtual Physics Lab',
              meta: '13 live parameter simulations',
              screen: 'lab' as const,
              icon: FlaskConical,
            },
          ].map((card) => {
            const Icon = card.icon;
            return (
              <button
                key={card.title}
                type="button"
                onClick={() => setActiveScreen(card.screen)}
                className="text-left rounded-xl border border-slate-200 bg-white p-5 hover:border-cyan-500 transition-colors group"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="text-base font-semibold text-[#0B1F3A] group-hover:text-cyan-700 transition-colors">
                      {card.title}
                    </h3>
                    <p className="mt-1 text-xs text-slate-500">{card.meta}</p>
                  </div>
                  <Icon className="w-5 h-5 text-cyan-700 shrink-0" />
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Analytics + Revision Recommendations */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 rounded-xl border border-slate-200 bg-white p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-base font-bold text-[#0B1F3A]">Accuracy &amp; Score Trend</h2>
              <p className="text-xs text-slate-500">Recent quizzes and JEE mock examinations</p>
            </div>
            <button
              type="button"
              onClick={() => setActiveScreen('analytics')}
              className="text-xs font-semibold text-cyan-700 hover:underline whitespace-nowrap"
            >
              Detailed Analytics
            </button>
          </div>
          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis dataKey="name" tick={{ fontSize: 12, fill: '#475569' }} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 12, fill: '#475569' }} />
                <Tooltip />
                <Area
                  type="monotone"
                  dataKey="accuracy"
                  name="Accuracy (%)"
                  stroke="#0891B2"
                  fill="#CFFAFE"
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="lg:col-span-4 rounded-xl border border-slate-200 bg-white p-5 flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center gap-2 text-[#0B1F3A]">
              <Layers className="w-4 h-4 text-cyan-700" />
              <h2 className="text-base font-bold">Revision Recommendations</h2>
            </div>
            <p className="mt-1 text-xs text-slate-500">
              Targeted focus areas based on your recent test responses
            </p>
            <ul className="mt-4 space-y-2.5 text-sm">
              {weakTopicList.slice(0, 4).map((topic) => (
                <li
                  key={topic}
                  className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2 border border-slate-200/80"
                >
                  <span className="font-medium text-slate-800 capitalize">
                    {topic.replace(/_/g, ' ')}
                  </span>
                  <button
                    type="button"
                    onClick={() => setActiveScreen('flashcards')}
                    className="text-xs font-semibold text-cyan-700 hover:underline whitespace-nowrap"
                  >
                    Revise
                  </button>
                </li>
              ))}
            </ul>
          </div>
          <button
            type="button"
            onClick={() => setActiveScreen('pyqs')}
            className="w-full py-2.5 px-4 rounded-lg bg-[#0B1F3A] text-white text-xs font-semibold hover:bg-[#132D52] transition-colors"
          >
            Practice 40-Year PYQ Archive
          </button>
        </div>
      </section>
    </div>
  );
}
