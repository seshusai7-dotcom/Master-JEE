import { useState } from 'react';
import { BookOpen, ShieldCheck, FlaskConical, ArrowRight, Sparkles } from 'lucide-react';
import { useApp } from '../context/AppContext';

export function SplashAuthGate() {
  const { loginWithGoogle, enterDemoMode, authError } = useApp();
  const [heroImgError, setHeroImgError] = useState(false);
  const [avatarImgError, setAvatarImgError] = useState(false);

  return (
    <div className="min-h-screen bg-[#0B1F3A] text-white flex flex-col">
      {/* Top Bar */}
      <header className="mx-auto w-full max-w-6xl px-6 py-5 flex items-center justify-between gap-8 border-b border-white/10">
        <span className="text-lg font-bold tracking-tight whitespace-nowrap shrink-0">
          MASTER JEE – CLASS 11 PHYSICS
        </span>
        <span className="hidden md:inline text-sm text-cyan-200/80 whitespace-nowrap shrink-0">
          Understand Physics. Master Concepts. Crack IIT JEE.
        </span>
        <button
          type="button"
          onClick={() => enterDemoMode('student')}
          className="px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-[#0B1F3A] text-sm font-semibold transition-colors whitespace-nowrap shrink-0"
        >
          Enter Student Demo
        </button>
      </header>

      {/* Main Split Hero */}
      <main className="flex-1 mx-auto w-full max-w-6xl px-6 py-10 grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
        <div className="lg:col-span-7 flex flex-col justify-center space-y-6">
          <p className="text-sm font-medium text-cyan-300">
            14-Chapter NCERT &amp; IIT-JEE Complete Digital Platform
          </p>
          <h1 className="text-3xl sm:text-5xl font-bold tracking-tight leading-tight text-balance">
            Master Class 11 Physics from First Principles to JEE Advanced.
          </h1>
          <p className="text-slate-300 text-base leading-relaxed max-w-2xl">
            Complete AI-authored textbook modules, step-by-step mathematical derivations, interactive
            virtual physics laboratories, mind maps, formula sheets, and a source-verified 40-year
            JEE archive.
          </p>

          {/* Academic Director Attribution */}
          <div className="flex items-center gap-4 p-4 rounded-xl bg-white/5 border border-white/10 max-w-xl">
            {!avatarImgError ? (
              <img
                src="/src/assets/images/director_avatar_academic_1794843533216.jpg"
                alt="Dr. V. Sesha Sai Kumar, Academic Director"
                referrerPolicy="no-referrer"
                onError={() => setAvatarImgError(true)}
                className="w-16 h-16 rounded-lg object-cover shrink-0 border border-white/15"
              />
            ) : (
              <div className="w-16 h-16 rounded-lg bg-cyan-900/60 border border-cyan-400/30 flex items-center justify-center text-lg font-bold shrink-0">
                VS
              </div>
            )}
            <div className="min-w-0">
              <p className="text-xs text-cyan-300 font-medium">
                Created and Academically Directed by
              </p>
              <p className="text-base font-semibold text-white truncate">
                Dr. V. Sesha Sai Kumar
              </p>
              <p className="text-xs text-slate-300">
                Gokaraju Rangaraju Institute of Engineering and Technology (GRIET), Hyderabad
              </p>
            </div>
          </div>

          {authError && (
            <div role="alert" className="rounded-lg border border-red-400/40 bg-red-950/60 px-4 py-3 text-sm text-red-200">
              {authError}
            </div>
          )}

          {/* Action Controls */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              type="button"
              onClick={loginWithGoogle}
              className="px-5 py-3 rounded-lg bg-white text-[#0B1F3A] hover:bg-slate-100 font-semibold text-sm flex items-center gap-2 transition-colors whitespace-nowrap"
            >
              <span>Sign in with Google</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => enterDemoMode('student')}
              className="px-5 py-3 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-sm transition-colors whitespace-nowrap"
            >
              Student Demo Mode
            </button>
            <button
              type="button"
              onClick={() => enterDemoMode('admin')}
              className="px-5 py-3 rounded-lg border border-white/25 hover:bg-white/10 text-white font-medium text-sm flex items-center gap-2 transition-colors whitespace-nowrap"
            >
              <ShieldCheck className="w-4 h-4 text-cyan-300" />
              <span>Teacher / Admin Portal</span>
            </button>
          </div>

          <div className="grid grid-cols-3 gap-4 pt-4 border-t border-white/10 text-sm">
            <div>
              <p className="font-semibold text-white tabular-nums">14 Chapters</p>
              <p className="text-xs text-slate-400">Foundation to JEE Adv</p>
            </div>
            <div>
              <p className="font-semibold text-white tabular-nums">13 Virtual Labs</p>
              <p className="text-xs text-slate-400">Real-Time Simulators</p>
            </div>
            <div>
              <p className="font-semibold text-white tabular-nums">3 Question Banks</p>
              <p className="text-xs text-slate-400">Verified PYQ &amp; Practice</p>
            </div>
          </div>
        </div>

        {/* Visual Blueprint Artwork */}
        <div className="lg:col-span-5 flex flex-col justify-center">
          <div className="rounded-2xl overflow-hidden border border-white/15 bg-[#08172C] shadow-xl">
            {!heroImgError ? (
              <div className="aspect-video w-full bg-[#08172C]">
                <img
                  src="/src/assets/images/hero_physics_blueprint_1794843531983.jpg"
                  alt="Classical mechanics vectors, gravitational orbits, and vernier optics schematic"
                  referrerPolicy="no-referrer"
                  onError={() => setHeroImgError(true)}
                  className="w-full h-full object-contain"
                />
              </div>
            ) : (
              <div className="w-full h-64 lg:h-80 flex flex-col items-center justify-center bg-gradient-to-br from-[#0B1F3A] to-[#0891B2]/30 p-6 text-center">
                <FlaskConical className="w-10 h-10 text-cyan-300 mb-3" />
                <p className="font-semibold">Principles of Classical Mechanics</p>
              </div>
            )}
            <div className="p-5 space-y-3">
              <div className="flex items-center justify-between text-xs text-cyan-200">
                <span>Chapter 1 Reference Ready</span>
                <span>·</span>
                <span>KaTeX + Interactive Labs</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-slate-200">
                <div className="p-3 rounded-lg bg-white/5 border border-white/10">
                  <BookOpen className="w-4 h-4 text-cyan-300 mb-1" />
                  <p className="font-semibold">A–Q Textbook</p>
                  <p className="text-slate-400 mt-0.5">Full derivations</p>
                </div>
                <div className="p-3 rounded-lg bg-white/5 border border-white/10">
                  <FlaskConical className="w-4 h-4 text-cyan-300 mb-1" />
                  <p className="font-semibold">Virtual Lab</p>
                  <p className="text-slate-400 mt-0.5">Live parameters</p>
                </div>
                <div className="p-3 rounded-lg bg-white/5 border border-white/10">
                  <Sparkles className="w-4 h-4 text-cyan-300 mb-1" />
                  <p className="font-semibold">AI Tutor</p>
                  <p className="text-slate-400 mt-0.5">Hint-first help</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
