import { LogOut, ShieldCheck, User } from 'lucide-react';
import { useApp } from '../context/AppContext';
import type { AcademicLevel } from '../types/physics';

export function ProfileView() {
  const {
    profile,
    authMode,
    academicLevel,
    setAcademicLevel,
    enterDemoMode,
    logout,
    setActiveScreen,
  } = useApp();

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-2xl font-bold text-[#0B1F3A]">Student Profile &amp; Settings</h1>
        <p className="mt-1 text-sm text-slate-600">
          Manage your academic tier, authentication session, and role access.
        </p>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-[#0B1F3A] text-white flex items-center justify-center">
            <User className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-[#0B1F3A]">{profile.displayName}</h2>
            <p className="text-xs text-slate-500">
              {profile.email} · Role: {profile.role.toUpperCase()} · Session:{' '}
              {authMode === 'firebase' ? 'Cloud Firestore Synced' : 'Local Demonstration Mode'}
            </p>
          </div>
        </div>

        <div className="pt-4 border-t border-slate-100 space-y-2">
          <label htmlFor="profile-level" className="block text-xs font-semibold text-slate-600">
            Default Academic Difficulty Level
          </label>
          <select
            id="profile-level"
            value={academicLevel}
            onChange={(e) => setAcademicLevel(e.target.value as AcademicLevel)}
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-medium"
          >
            <option value="foundation">Level 1 – Foundation Physics</option>
            <option value="jee_main">Level 2 – JEE Main</option>
            <option value="jee_advanced">Level 3 – JEE Advanced</option>
          </select>
        </div>

        <div className="pt-4 border-t border-slate-100 flex flex-wrap gap-3">
          {profile.role === 'admin' ? (
            <button
              type="button"
              onClick={() => setActiveScreen('admin')}
              className="px-4 py-2 rounded-lg bg-[#0B1F3A] text-white text-xs font-semibold inline-flex items-center gap-1.5"
            >
              <ShieldCheck className="w-4 h-4 text-cyan-300" />
              <span>Open Teacher / Admin Dashboard</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => enterDemoMode('admin')}
              className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-semibold inline-flex items-center gap-1.5"
            >
              <ShieldCheck className="w-4 h-4 text-cyan-700" />
              <span>Switch to Academic Director Demo</span>
            </button>
          )}

          <button
            type="button"
            onClick={logout}
            className="px-4 py-2 rounded-lg border border-red-200 text-red-700 hover:bg-red-50 text-xs font-semibold inline-flex items-center gap-1.5"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out / Return to Splash</span>
          </button>
        </div>
      </div>
    </div>
  );
}
