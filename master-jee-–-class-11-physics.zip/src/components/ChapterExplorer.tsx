import { useState } from 'react';
import {
  BookOpen,
  Network,
  FlaskConical,
  CheckCircle2,
  Search,
  ChevronDown,
  ChevronRight,
  Database,
  ArrowUpRight,
  Download,
} from 'lucide-react';
import { ALL_CHAPTERS } from '../data/curriculumIndex';
import { getSyllabusStats } from '../data/syllabusHierarchy';
import { useApp } from '../context/AppContext';
import type { CurriculumScope } from '../types/physics';

const UNIT_GROUPS = [
  'All Units',
  'Mechanics',
  'Properties of Matter',
  'Thermal Physics',
  'Oscillations & Waves',
] as const;

const SCOPE_FILTERS: readonly ('All Scopes' | CurriculumScope)[] = [
  'All Scopes',
  'NCERT Core',
  'NCERT + JEE Main',
  'JEE Main & Adv',
  'Enrichment',
];

export function ChapterExplorer() {
  const {
    activeChapterId,
    setActiveChapterId,
    setActiveSubtopicId,
    setActiveScreen,
    completedSubtopics,
    syllabusHierarchy,
    syllabusSyncStatus,
  } = useApp();

  const [unitFilter, setUnitFilter] = useState<(typeof UNIT_GROUPS)[number]>('All Units');
  const [scopeFilter, setScopeFilter] = useState<'All Scopes' | CurriculumScope>('All Scopes');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedTopicIds, setExpandedTopicIds] = useState<Record<string, boolean>>({
    'ch1-t1': true,
    'ch1-t2': true,
  });

  const stats = getSyllabusStats(syllabusHierarchy);
  const q = searchQuery.trim().toLowerCase();

  const toggleTopic = (topicId: string) => {
    setExpandedTopicIds((prev) => ({ ...prev, [topicId]: !prev[topicId] }));
  };

  const openModule = (chapterId: string, linkedSubtopicId: string) => {
    setActiveChapterId(chapterId);
    setActiveSubtopicId(linkedSubtopicId);
    setActiveScreen('reader');
  };

  const filteredChapters = syllabusHierarchy
    .map((ch) => {
      const matchesUnit = unitFilter === 'All Units' || ch.unitGroup === unitFilter;
      if (!matchesUnit) return null;

      const chapterLevelMatch =
        !q ||
        ch.title.toLowerCase().includes(q) ||
        ch.overview.toLowerCase().includes(q) ||
        `chapter ${ch.chapterNumber}`.includes(q);

      const matchingTopics = ch.topics.filter((topic) => {
        const matchesScope =
          scopeFilter === 'All Scopes' ||
          topic.curriculumScope === scopeFilter ||
          (scopeFilter === 'Enrichment' &&
            (topic.isEnrichment || topic.subtopics.some((st) => st.enrichmentOnly)));

        if (!matchesScope) return false;
        if (!q || (chapterLevelMatch && scopeFilter === 'All Scopes')) return true;
        if (chapterLevelMatch && matchesScope) return true;

        return (
          topic.title.toLowerCase().includes(q) ||
          topic.code.toLowerCase().includes(q) ||
          topic.ncertSectionRef.toLowerCase().includes(q) ||
          topic.subtopics.some(
            (st) =>
              st.title.toLowerCase().includes(q) ||
              st.code.toLowerCase().includes(q) ||
              st.keyConcepts.some((kc) => kc.toLowerCase().includes(q))
          )
        );
      });

      if (matchingTopics.length === 0) return null;
      return { chapter: ch, visibleTopics: matchingTopics };
    })
    .filter((item): item is NonNullable<typeof item> => item !== null);

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-2xl font-bold text-[#0B1F3A]">
            Class 11 Physics · 14-Chapter NCERT &amp; JEE Hierarchy
          </h1>
          <p className="text-sm text-slate-600">
            Structured Chapter → Topic → Subtopic curriculum aligned to NCERT Part I &amp; II, JEE Main, JEE Advanced, and Enrichment modules.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div
            className={`px-3 py-1.5 rounded-lg border text-xs font-semibold inline-flex items-center gap-1.5 ${
              syllabusSyncStatus === 'firestore_synced'
                ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
                : 'border-slate-200 bg-white text-slate-700'
            }`}
          >
            <Database className="w-3.5 h-3.5 text-cyan-700" />
            <span>
              {syllabusSyncStatus === 'firestore_synced'
                ? 'Firestore Synced'
                : 'Curriculum Model Ready'}
            </span>
          </div>

          <a
            href="/MASTER-JEE-Class-11-Physics.html"
            download="MASTER-JEE-Class-11-Physics.html"
            className="px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-[#0B1F3A] inline-flex items-center gap-1.5 whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5 text-cyan-700" />
            <span>Export HTML</span>
          </a>

          <div className="relative w-full sm:w-68">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search chapters or concepts..."
              aria-label="Search chapters, topics, or concepts"
              className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-300 bg-white text-sm focus:outline-none focus:border-cyan-600"
            />
          </div>
        </div>
      </div>

      {/* Structural Telemetry Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="rounded-xl border border-slate-200 bg-white px-4 py-3">
          <p className="text-xs text-slate-500">NCERT &amp; JEE Chapters</p>
          <p className="text-lg font-bold text-[#0B1F3A] tabular-nums">{stats.chapterCount}</p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white px-4 py-3">
          <p className="text-xs text-slate-500">Core Topics</p>
          <p className="text-lg font-bold text-[#0B1F3A] tabular-nums">{stats.topicCount}</p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white px-4 py-3">
          <p className="text-xs text-slate-500">Granular Subtopics</p>
          <p className="text-lg font-bold text-[#0B1F3A] tabular-nums">{stats.subtopicCount}</p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white px-4 py-3">
          <p className="text-xs text-slate-500">Enrichment Subtopics</p>
          <p className="text-lg font-bold text-cyan-800 tabular-nums">{stats.enrichmentSubtopics}</p>
        </div>
      </div>

      {/* Filters Row */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-2.5">
        <div className="flex flex-wrap gap-1.5 p-1 bg-slate-100 rounded-xl w-fit">
          {UNIT_GROUPS.map((unit) => (
            <button
              key={unit}
              type="button"
              onClick={() => setUnitFilter(unit)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                unitFilter === unit
                  ? 'bg-white text-[#0B1F3A] shadow-sm'
                  : 'text-slate-600 hover:text-[#0B1F3A]'
              }`}
            >
              {unit}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap gap-1.5 p-1 bg-slate-100 rounded-xl w-fit">
          {SCOPE_FILTERS.map((scope) => (
            <button
              key={scope}
              type="button"
              onClick={() => setScopeFilter(scope)}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                scopeFilter === scope
                  ? 'bg-[#0B1F3A] text-white'
                  : 'text-slate-600 hover:text-[#0B1F3A]'
              }`}
            >
              {scope}
            </button>
          ))}
        </div>
      </div>

      {filteredChapters.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-600">
          No syllabus chapters or subtopics match your current filter. Clear the search or select All Scopes.
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {filteredChapters.map(({ chapter: ch, visibleTopics }) => {
            const chapterContent = ALL_CHAPTERS.find((c) => c.id === ch.chapterId);
            const totalModules = chapterContent?.subtopics.length ?? 0;
            const doneCount =
              chapterContent?.subtopics.filter((s) => completedSubtopics.includes(s.id)).length ?? 0;
            const isSelected = ch.chapterId === activeChapterId;

            return (
              <article
                key={ch.chapterId}
                className={`rounded-xl border bg-white p-5 transition-colors flex flex-col justify-between space-y-4 ${
                  isSelected ? 'border-cyan-600' : 'border-slate-200'
                }`}
              >
                <div className="space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
                    <span>
                      Ch {String(ch.chapterNumber).padStart(2, '0')} · NCERT {ch.ncertBookPart} (Ch{' '}
                      {ch.ncertChapterNumber}) · {ch.unitGroup}
                    </span>
                    <span className="tabular-nums font-semibold text-cyan-800">
                      {doneCount}/{totalModules} modules done · JEE {ch.jeeWeightage}
                    </span>
                  </div>

                  <div>
                    <h2 className="text-lg font-bold text-[#0B1F3A]">
                      {ch.chapterNumber}. {ch.title}
                    </h2>
                    <p className="mt-1 text-sm text-slate-600 leading-relaxed">{ch.overview}</p>
                  </div>

                  {/* Topic -> Subtopic Hierarchy Tree */}
                  <div className="pt-2 space-y-2 border-t border-slate-100">
                    {visibleTopics.map((topic) => {
                      const forceExpand = Boolean(q) || scopeFilter !== 'All Scopes';
                      const isExpanded = forceExpand || Boolean(expandedTopicIds[topic.topicId]);
                      const isTopicDone = completedSubtopics.includes(topic.linkedContentSubtopicId);

                      const visibleSubtopics =
                        scopeFilter === 'Enrichment'
                          ? topic.subtopics.filter((st) => st.enrichmentOnly || topic.isEnrichment)
                          : topic.subtopics;

                      return (
                        <div
                          key={topic.topicId}
                          className="rounded-lg border border-slate-200 bg-slate-50/50 overflow-hidden"
                        >
                          <div className="px-3 py-2.5 flex items-center justify-between gap-2">
                            <button
                              type="button"
                              onClick={() => toggleTopic(topic.topicId)}
                              aria-expanded={isExpanded}
                              className="flex items-center gap-2 text-left min-w-0 flex-1"
                            >
                              {isExpanded ? (
                                <ChevronDown className="w-4 h-4 text-slate-500 shrink-0" />
                              ) : (
                                <ChevronRight className="w-4 h-4 text-slate-500 shrink-0" />
                              )}
                              <CheckCircle2
                                className={`w-3.5 h-3.5 shrink-0 ${
                                  isTopicDone ? 'text-emerald-600' : 'text-slate-300'
                                }`}
                              />
                              <span className="text-xs font-bold text-[#0B1F3A] truncate">
                                {topic.code} {topic.title}
                              </span>
                            </button>

                            <div className="flex items-center gap-1.5 shrink-0">
                              <span
                                className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                                  topic.isEnrichment
                                    ? 'bg-amber-100 text-amber-900 border border-amber-200'
                                    : 'bg-white text-slate-700 border border-slate-200'
                                }`}
                              >
                                {topic.curriculumScope}
                              </span>
                              <button
                                type="button"
                                onClick={() =>
                                  openModule(ch.chapterId, topic.linkedContentSubtopicId)
                                }
                                title={`Open ${topic.title} in Reader`}
                                className="px-2 py-0.5 rounded bg-cyan-600 hover:bg-cyan-500 text-white text-[11px] font-semibold inline-flex items-center gap-0.5"
                              >
                                <span>Study</span>
                                <ArrowUpRight className="w-3 h-3" />
                              </button>
                            </div>
                          </div>

                          {isExpanded && (
                            <div className="px-3 pb-3 pt-1.5 border-t border-slate-200/70 bg-white space-y-2">
                              <p className="text-[11px] font-medium text-slate-500">
                                Reference: {topic.ncertSectionRef} · {visibleSubtopics.length} subtopics
                              </p>
                              <ul className="space-y-2">
                                {visibleSubtopics.map((st) => (
                                  <li
                                    key={st.subtopicId}
                                    className="rounded-md border border-slate-200/80 p-2.5 hover:border-cyan-400 transition-colors"
                                  >
                                    <div className="flex flex-wrap items-start justify-between gap-2">
                                      <button
                                        type="button"
                                        onClick={() =>
                                          openModule(ch.chapterId, st.linkedContentSubtopicId)
                                        }
                                        className="text-left text-xs font-semibold text-[#0B1F3A] hover:text-cyan-700"
                                      >
                                        <span className="font-mono text-cyan-800 mr-1.5">
                                          {st.code}
                                        </span>
                                        {st.title}
                                      </button>
                                      <div className="flex flex-wrap gap-1 shrink-0">
                                        {st.ncertAligned && (
                                          <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px] font-semibold">
                                            NCERT
                                          </span>
                                        )}
                                        {st.jeeMainAligned && (
                                          <span className="px-1.5 py-0.5 rounded bg-cyan-50 text-cyan-800 border border-cyan-200 text-[10px] font-semibold">
                                            JEE Main
                                          </span>
                                        )}
                                        {st.jeeAdvancedAligned && (
                                          <span className="px-1.5 py-0.5 rounded bg-[#0B1F3A] text-white text-[10px] font-semibold">
                                            JEE Adv
                                          </span>
                                        )}
                                        {st.enrichmentOnly && (
                                          <span className="px-1.5 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-200 text-[10px] font-semibold">
                                            Enrichment Only
                                          </span>
                                        )}
                                      </div>
                                    </div>
                                    <p className="mt-1 text-[11px] text-slate-500">
                                      Key concepts: {st.keyConcepts.join(' · ')}
                                    </p>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 pt-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => {
                      setActiveChapterId(ch.chapterId);
                      setActiveSubtopicId(null);
                      setActiveScreen('reader');
                    }}
                    className="px-3.5 py-2 rounded-lg bg-[#0B1F3A] text-white hover:bg-[#132D52] text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap"
                  >
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>Study Chapter</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveChapterId(ch.chapterId);
                      setActiveScreen('mindmap');
                    }}
                    className="px-3 py-2 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-medium inline-flex items-center gap-1.5 whitespace-nowrap"
                  >
                    <Network className="w-3.5 h-3.5 text-cyan-700" />
                    <span>Mind Map</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveChapterId(ch.chapterId);
                      setActiveScreen('lab');
                    }}
                    className="px-3 py-2 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-medium inline-flex items-center gap-1.5 whitespace-nowrap"
                  >
                    <FlaskConical className="w-3.5 h-3.5 text-cyan-700" />
                    <span>Lab</span>
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
