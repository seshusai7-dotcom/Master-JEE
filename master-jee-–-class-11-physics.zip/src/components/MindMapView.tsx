import { useMemo, useState } from 'react';
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  type Node,
  type Edge,
} from '@xyflow/react';
import { BookOpen, ClipboardCheck, Layers } from 'lucide-react';
import { ALL_CHAPTERS, getChapterById } from '../data/curriculumIndex';
import { useApp } from '../context/AppContext';
import { MathFormula } from './MathBlock';

interface SelectedNodeDetail {
  id: string;
  title: string;
  category: string;
  summary: string;
  equations: string[];
}

export function MindMapView() {
  const { activeChapterId, setActiveChapterId, setActiveScreen } = useApp();
  const chapter = getChapterById(activeChapterId);

  const [collapsedBranchIds, setCollapsedBranchIds] = useState<string[]>([]);
  const [selectedDetail, setSelectedDetail] = useState<SelectedNodeDetail>({
    id: chapter.id,
    title: chapter.title,
    category: 'Central Chapter Concept',
    summary: chapter.overview,
    equations: chapter.formulas.slice(0, 2).map((f) => f.latex),
  });

  const toggleBranch = (branchId: string) => {
    setCollapsedBranchIds((prev) =>
      prev.includes(branchId) ? prev.filter((id) => id !== branchId) : [...prev, branchId]
    );
  };

  const { nodes, edges } = useMemo(() => {
    const builtNodes: Node[] = [];
    const builtEdges: Edge[] = [];

    builtNodes.push({
      id: 'root',
      position: { x: 40, y: 200 },
      data: { label: `Ch ${chapter.number}: ${chapter.title}` },
      style: {
        background: '#0B1F3A',
        color: '#FFFFFF',
        border: '2px solid #06B6D4',
        borderRadius: 12,
        padding: 12,
        fontWeight: 700,
        width: 220,
      },
    });

    chapter.mindMapBranches.forEach((branch, bIdx) => {
      const branchY = 40 + bIdx * 135;
      const isCollapsed = collapsedBranchIds.includes(branch.id);

      builtNodes.push({
        id: branch.id,
        position: { x: 330, y: branchY },
        data: {
          label: `${branch.title} (${isCollapsed ? `+${branch.children.length}` : '−'})`,
        },
        style: {
          background: '#FFFFFF',
          color: '#0B1F3A',
          border: '1.5px solid #0891B2',
          borderRadius: 10,
          padding: 10,
          fontWeight: 600,
          width: 210,
        },
      });

      builtEdges.push({
        id: `e-root-${branch.id}`,
        source: 'root',
        target: branch.id,
        style: { stroke: '#0891B2', strokeWidth: 2 },
      });

      if (!isCollapsed) {
        branch.children.forEach((child, cIdx) => {
          const childY = branchY - 22 + cIdx * 54;
          builtNodes.push({
            id: child.id,
            position: { x: 620, y: childY },
            data: { label: child.title },
            style: {
              background: '#F8FAFC',
              color: '#0F172A',
              border: '1px solid #CBD5E1',
              borderRadius: 8,
              padding: 8,
              fontSize: 12,
              width: 195,
            },
          });

          builtEdges.push({
            id: `e-${branch.id}-${child.id}`,
            source: branch.id,
            target: child.id,
            style: { stroke: '#64748B', strokeWidth: 1.4 },
          });
        });
      }
    });

    return { nodes: builtNodes, edges: builtEdges };
  }, [chapter, collapsedBranchIds]);

  const handleNodeClick = (_: unknown, node: Node) => {
    if (node.id === 'root') {
      setSelectedDetail({
        id: chapter.id,
        title: chapter.title,
        category: 'Central Chapter Concept',
        summary: chapter.overview,
        equations: chapter.formulas.slice(0, 3).map((f) => f.latex),
      });
      return;
    }

    const branch = chapter.mindMapBranches.find((b) => b.id === node.id);
    if (branch) {
      toggleBranch(branch.id);
      setSelectedDetail({
        id: branch.id,
        title: branch.title,
        category: branch.category,
        summary: branch.summary,
        equations: branch.equations,
      });
      return;
    }

    for (const b of chapter.mindMapBranches) {
      const child = b.children.find((c) => c.id === node.id);
      if (child) {
        setSelectedDetail({
          id: child.id,
          title: child.title,
          category: `${b.title} · Sub-node`,
          summary: child.detail,
          equations: child.latex ? [child.latex] : b.equations,
        });
        return;
      }
    }
  };

  return (
    <div className="space-y-5">
      <div className="rounded-xl border border-slate-200 bg-white p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-[#0B1F3A]">Interactive Physics Mind Map</h1>
          <p className="text-xs text-slate-500">
            Click any branch to expand/collapse subtopics and inspect equations.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <select
            aria-label="Select chapter for mind map"
            value={chapter.id}
            onChange={(e) => {
              const nextCh = getChapterById(e.target.value);
              setActiveChapterId(nextCh.id);
              setCollapsedBranchIds([]);
              setSelectedDetail({
                id: nextCh.id,
                title: nextCh.title,
                category: 'Central Chapter Concept',
                summary: nextCh.overview,
                equations: nextCh.formulas.slice(0, 2).map((f) => f.latex),
              });
            }}
            className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-sm font-semibold text-[#0B1F3A]"
          >
            {ALL_CHAPTERS.map((c) => (
              <option key={c.id} value={c.id}>
                Ch {c.number}: {c.title}
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={() => setCollapsedBranchIds([])}
            className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-50"
          >
            Expand All
          </button>
          <button
            type="button"
            onClick={() => setCollapsedBranchIds(chapter.mindMapBranches.map((b) => b.id))}
            className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-50"
          >
            Collapse All
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* React Flow Canvas */}
        <div
          data-testid="mindmap-canvas"
          className="lg:col-span-8 h-[460px] rounded-xl border border-slate-200 bg-white overflow-hidden"
        >
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodeClick={handleNodeClick}
            fitView
            attributionPosition="bottom-left"
          >
            <Background color="#CBD5E1" gap={18} />
            <Controls />
            <MiniMap nodeColor="#0B1F3A" maskColor="rgba(241, 245, 249, 0.7)" />
          </ReactFlow>
        </div>

        {/* Node Explanation Drawer */}
        <aside className="lg:col-span-4 rounded-xl border border-slate-200 bg-white p-5 flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-cyan-800">
              <Layers className="w-4 h-4" />
              <span>{selectedDetail.category}</span>
            </div>
            <h2 className="text-lg font-bold text-[#0B1F3A]">{selectedDetail.title}</h2>
            <p className="text-sm text-slate-700 leading-relaxed">{selectedDetail.summary}</p>

            {selectedDetail.equations.length > 0 && (
              <div className="pt-2 space-y-2">
                <p className="text-xs font-bold text-slate-600">Associated Equations</p>
                {selectedDetail.equations.map((eq, i) => (
                  <MathFormula key={i} latex={eq} display />
                ))}
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-slate-100 flex flex-col gap-2">
            <button
              type="button"
              onClick={() => setActiveScreen('reader')}
              className="w-full py-2 px-3 rounded-lg bg-[#0B1F3A] text-white text-xs font-semibold inline-flex items-center justify-center gap-1.5 hover:bg-[#132D52]"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Open Textbook &amp; Solved Examples</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveScreen('pyqs')}
              className="w-full py-2 px-3 rounded-lg border border-slate-200 text-slate-700 text-xs font-semibold inline-flex items-center justify-center gap-1.5 hover:bg-slate-50"
            >
              <ClipboardCheck className="w-3.5 h-3.5 text-cyan-700" />
              <span>View Related Question Bank</span>
            </button>
          </div>
        </aside>
      </div>
    </div>
  );
}
