import { useMemo } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';
import { useApp } from '../context/AppContext';
import { ALL_CHAPTERS } from '../data/curriculumIndex';

export function AnalyticsView() {
  const { attempts, completedSubtopics, setActiveScreen } = useApp();

  const chapterPerformance = useMemo(() => {
    const map: Record<string, { sum: number; count: number }> = {};
    for (const a of attempts) {
      if (!map[a.chapterId]) map[a.chapterId] = { sum: 0, count: 0 };
      map[a.chapterId].sum += a.accuracyPct;
      map[a.chapterId].count += 1;
    }
    return ALL_CHAPTERS.slice(0, 8).map((c) => ({
      chapter: `Ch ${c.number}`,
      accuracy: map[c.id] ? Math.round(map[c.id].sum / map[c.id].count) : 0,
    }));
  }, [attempts]);

  const totalTimeMin = Math.round(
    attempts.reduce((acc, a) => acc + a.timeSpentSec, 0) / 60
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#0B1F3A]">Performance Analytics</h1>
          <p className="mt-1 text-sm text-slate-600">
            Quantitative breakdown of accuracy, test timing, and chapter-level proficiency.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setActiveScreen('quiz')}
          className="px-4 py-2 rounded-lg bg-[#0B1F3A] text-white text-xs font-semibold"
        >
          Take Diagnostic Test
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-xs text-slate-500">Total Assessments</p>
          <p className="mt-1 text-2xl font-bold text-[#0B1F3A] tabular-nums">{attempts.length}</p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-xs text-slate-500">Timed Exam Focus</p>
          <p className="mt-1 text-2xl font-bold text-[#0B1F3A] tabular-nums">{totalTimeMin} min</p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-xs text-slate-500">Topics Mastered</p>
          <p className="mt-1 text-2xl font-bold text-[#0B1F3A] tabular-nums">
            {completedSubtopics.length}
          </p>
        </div>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <h2 className="text-base font-bold text-[#0B1F3A] mb-4">Chapter Accuracy (%)</h2>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chapterPerformance}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
              <XAxis dataKey="chapter" tick={{ fontSize: 12, fill: '#475569' }} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 12, fill: '#475569' }} />
              <Tooltip />
              <Bar dataKey="accuracy" name="Accuracy (%)" fill="#0891B2" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Attempt Log Table */}
      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200">
          <h2 className="text-base font-bold text-[#0B1F3A]">Recent Assessment Log</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs tabular-nums">
            <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Module</th>
                <th className="py-3 px-4">Mode</th>
                <th className="py-3 px-4">Score</th>
                <th className="py-3 px-4">Accuracy</th>
                <th className="py-3 px-4">Time</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {attempts.map((a) => (
                <tr key={a.attemptId}>
                  <td className="py-3 px-4 font-semibold text-[#0B1F3A]">{a.chapterTitle}</td>
                  <td className="py-3 px-4 text-slate-600">{a.mode.replace('_', ' ')}</td>
                  <td className="py-3 px-4 font-mono">
                    {a.score} / {a.maxScore}
                  </td>
                  <td className="py-3 px-4 font-mono font-semibold text-cyan-800">
                    {a.accuracyPct}%
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-600">{a.timeSpentSec}s</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
