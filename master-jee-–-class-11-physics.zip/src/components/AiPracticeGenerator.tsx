import { useState } from 'react';
import { Sparkles, CheckCircle2, AlertTriangle } from 'lucide-react';
import { ALL_CHAPTERS, getChapterById } from '../data/curriculumIndex';
import { useApp } from '../context/AppContext';
import { MathText } from './MathBlock';
import type { AcademicLevel, QuestionEntry, QuestionFormat } from '../types/physics';

const QUESTION_COUNTS = [10, 20, 30, 50, 100] as const;

export function AiPracticeGenerator() {
  const { activeChapterId, addQuestionEntry } = useApp();
  const [chapterId, setChapterId] = useState(activeChapterId);
  const chapter = getChapterById(chapterId);

  const [subtopicTitle, setSubtopicTitle] = useState('All Subtopics');
  const [difficulty, setDifficulty] = useState<AcademicLevel>('jee_main');
  const [format, setFormat] = useState<QuestionFormat>('single_mcq');
  const [count, setCount] = useState<number>(10);

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [generatedSet, setGeneratedSet] = useState<QuestionEntry[]>([]);
  const [revealedIds, setRevealedIds] = useState<string[]>([]);

  const handleGenerate = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/questions/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chapterId: chapter.id,
          chapterTitle: chapter.title,
          subtopicTitle,
          difficulty,
          format,
          count,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to generate custom practice set.');
      }
      const list = (data.questions ?? []) as QuestionEntry[];
      setGeneratedSet(list);
      for (const q of list.slice(0, 10)) {
        await addQuestionEntry(q);
      }
    } catch (err) {
      setErrorMsg(
        err instanceof Error
          ? err.message
          : 'Unable to connect to the AI Question Generator service.'
      );
    } finally {
      setLoading(false);
    }
  };

  const toggleReveal = (id: string) => {
    setRevealedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-[#0B1F3A]">AI Practice Question Generator</h1>
        <p className="mt-1 text-sm text-slate-600">
          Generate custom 10–100 question sets labeled strictly as{' '}
          <span className="font-semibold text-[#0B1F3A]">Original AI-Generated Practice</span> (never
          misrepresented as authentic PYQs).
        </p>
      </div>

      {/* Configuration Form */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <div>
            <label htmlFor="gen-chapter" className="block text-xs font-semibold text-slate-600 mb-1">
              Chapter
            </label>
            <select
              id="gen-chapter"
              value={chapterId}
              onChange={(e) => {
                setChapterId(e.target.value);
                setSubtopicTitle('All Subtopics');
              }}
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
            >
              {ALL_CHAPTERS.map((c) => (
                <option key={c.id} value={c.id}>
                  Ch {c.number}: {c.title}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="gen-subtopic" className="block text-xs font-semibold text-slate-600 mb-1">
              Subtopic
            </label>
            <select
              id="gen-subtopic"
              value={subtopicTitle}
              onChange={(e) => setSubtopicTitle(e.target.value)}
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
            >
              <option value="All Subtopics">All Subtopics</option>
              {chapter.subtopics.map((s) => (
                <option key={s.id} value={s.title}>
                  {s.title}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="gen-level" className="block text-xs font-semibold text-slate-600 mb-1">
              Academic Level
            </label>
            <select
              id="gen-level"
              value={difficulty}
              onChange={(e) => setDifficulty(e.target.value as AcademicLevel)}
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
            >
              <option value="foundation">Foundation Level</option>
              <option value="jee_main">JEE Main Level</option>
              <option value="jee_advanced">JEE Advanced Level</option>
            </select>
          </div>

          <div>
            <label htmlFor="gen-format" className="block text-xs font-semibold text-slate-600 mb-1">
              Question Format
            </label>
            <select
              id="gen-format"
              value={format}
              onChange={(e) => setFormat(e.target.value as QuestionFormat)}
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
            >
              <option value="single_mcq">Single-Correct MCQ</option>
              <option value="multiple_mcq">Multiple-Correct MCQ</option>
              <option value="numerical">Numerical Answer</option>
              <option value="integer">Integer Type</option>
              <option value="assertion_reason">Assertion-Reason</option>
            </select>
          </div>

          <div>
            <label htmlFor="gen-count" className="block text-xs font-semibold text-slate-600 mb-1">
              Set Size
            </label>
            <select
              id="gen-count"
              value={count}
              onChange={(e) => setCount(Number(e.target.value))}
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm tabular-nums"
            >
              {QUESTION_COUNTS.map((n) => (
                <option key={n} value={n}>
                  {n} Questions
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          <p className="text-xs text-slate-500">
            Includes automated dimensional consistency and SI unit verification instructions.
          </p>
          <button
            type="button"
            onClick={handleGenerate}
            disabled={loading}
            className="px-5 py-2.5 rounded-lg bg-[#0B1F3A] hover:bg-[#132D52] disabled:opacity-50 text-white text-sm font-semibold inline-flex items-center gap-2 whitespace-nowrap"
          >
            <Sparkles className="w-4 h-4 text-cyan-300" />
            <span>{loading ? `Generating ${count} Questions...` : `Generate ${count}-Question Set`}</span>
          </button>
        </div>

        {errorMsg && (
          <div role="alert" className="rounded-lg border border-amber-300 bg-amber-50 p-3 text-xs text-amber-900 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}
      </div>

      {/* Generated Results */}
      {generatedSet.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-[#0B1F3A] flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Generated {generatedSet.length} Original AI-Generated Practice Questions</span>
            </h2>
          </div>

          {generatedSet.map((q, idx) => {
            const isOpen = revealedIds.includes(q.id);
            return (
              <article key={q.id} className="rounded-xl border border-slate-200 bg-white p-5 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
                  <span>
                    Q{idx + 1} · {q.exam} · {q.difficulty.replace('_', ' ')} · {q.topicId}
                  </span>
                  <span className="font-semibold text-cyan-800">Original AI-Generated Practice</span>
                </div>
                <div className="text-sm sm:text-base font-medium text-[#0B1F3A]">
                  <MathText text={q.prompt} />
                </div>
                {q.options && q.options.length > 0 && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
                    {q.options.map((opt, oi) => (
                      <div key={oi} className="rounded-lg border border-slate-200 px-3 py-2 bg-slate-50/50">
                        <span className="font-mono text-xs text-slate-500 mr-2">
                          ({String.fromCharCode(65 + oi)})
                        </span>
                        <MathText text={opt} />
                      </div>
                    ))}
                  </div>
                )}
                <button
                  type="button"
                  onClick={() => toggleReveal(q.id)}
                  className="text-xs font-semibold text-cyan-700 hover:underline"
                >
                  {isOpen ? 'Hide Solution' : 'Reveal Answer & Step-by-Step Solution'}
                </button>
                {isOpen && (
                  <div className="rounded-lg bg-slate-50 border border-slate-200 p-3.5 text-sm space-y-1">
                    <p className="font-bold text-emerald-700">
                      Answer:{' '}
                      {q.numericalAnswer !== undefined
                        ? `${q.numericalAnswer} ${q.unit ?? ''}`
                        : (q.correctOptionIndices ?? [])
                            .map((i) => String.fromCharCode(65 + i))
                            .join(', ')}
                    </p>
                    <p className="text-slate-700 leading-relaxed">
                      <MathText text={q.solution} />
                    </p>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
