import { useState } from 'react';
import { ShieldCheck, Sparkles, Upload, Smartphone, CheckCircle2, Database } from 'lucide-react';
import { ALL_CHAPTERS } from '../data/curriculumIndex';
import { getSyllabusStats } from '../data/syllabusHierarchy';
import { useApp } from '../context/AppContext';
import type {
  AcademicLevel,
  QuestionFormat,
  WorkflowStatus,
} from '../types/physics';
import { MathText } from './MathBlock';

const WORKFLOW_STAGES: WorkflowStatus[] = [
  'GENERATE',
  'VALIDATE',
  'TEACHER_REVIEW',
  'APPROVE',
  'PUBLISH',
];

export function AdminDashboard() {
  const {
    profile,
    managedContent,
    addManagedContent,
    advanceWorkflowStatus,
    addQuestionEntry,
    attempts,
    allQuestions,
    syllabusHierarchy,
    syllabusSyncStatus,
    syllabusSyncMessage,
    syncSyllabusHierarchy,
  } = useApp();

  const syllabusStats = getSyllabusStats(syllabusHierarchy);
  const [adminTab, setAdminTab] = useState<'workflow' | 'syllabus' | 'pyq_import' | 'android'>('workflow');
  const [genChapterId, setGenChapterId] = useState('ch1');
  const [genSubtopic, setGenSubtopic] = useState('Dimensional Analysis & Applications');
  const [genLevel, setGenLevel] = useState<AcademicLevel>('jee_main');
  const [genLoading, setGenLoading] = useState(false);
  const [genStatus, setGenStatus] = useState<string | null>(null);

  // PYQ Import Form State
  const [pyqChapterId, setPyqChapterId] = useState('ch1');
  const [pyqExam, setPyqExam] = useState('JEE Main');
  const [pyqYear, setPyqYear] = useState(2024);
  const [pyqFormat, setPyqFormat] = useState<QuestionFormat>('single_mcq');
  const [pyqPrompt, setPyqPrompt] = useState('');
  const [pyqAnswerIdx, setPyqAnswerIdx] = useState(0);
  const [pyqSolution, setPyqSolution] = useState('');
  const [pyqSource, setPyqSource] = useState('Official NTA Examination Paper');
  const [pyqMessage, setPyqMessage] = useState<string | null>(null);

  if (profile.role !== 'admin') {
    return (
      <div className="rounded-xl border border-amber-200 bg-amber-50 p-6 text-sm text-amber-900">
        Access Restricted: Teacher &amp; Administrator controls require Academic Director
        authorization (Dr. V. Sesha Sai Kumar, GRIET, Hyderabad).
      </div>
    );
  }

  const handleGenerateModule = async (e: React.FormEvent) => {
    e.preventDefault();
    setGenLoading(true);
    setGenStatus(null);
    const ch = ALL_CHAPTERS.find((c) => c.id === genChapterId) ?? ALL_CHAPTERS[0];
    try {
      const res = await fetch('/api/content/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chapterTitle: ch.title,
          subtopicTitle: genSubtopic,
          targetLevel: genLevel,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Content generation failed.');
      await addManagedContent({
        contentId: `mc-${Date.now()}`,
        chapterId: ch.id,
        subtopicId: ch.subtopics[0]?.id ?? `${ch.id}-s1`,
        title: data.title,
        summary: data.summary,
        workflowStatus: 'GENERATE',
        sourceLabel: 'Original AI-Generated',
      });
      setGenStatus('Draft module created at GENERATE stage. Ready for validation & review.');
    } catch (err) {
      setGenStatus(err instanceof Error ? err.message : 'Unable to generate module.');
    } finally {
      setGenLoading(false);
    }
  };

  const handleImportPyq = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pyqPrompt.trim() || !pyqSolution.trim()) return;
    await addQuestionEntry({
      id: `pyq-admin-${Date.now()}`,
      databaseCategory: 'A_VERIFIED_PYQ',
      chapterId: pyqChapterId,
      topicId: 'imported_verified',
      exam: pyqExam,
      year: Number(pyqYear),
      format: pyqFormat,
      difficulty: 'jee_main',
      prompt: pyqPrompt.trim(),
      options: ['Option A', 'Option B', 'Option C', 'Option D'],
      correctOptionIndices: [pyqAnswerIdx],
      solution: pyqSolution.trim(),
      sourceCitation: pyqSource.trim(),
      verified: true,
      copyrightNote: 'Verified Academic Director Import.',
    });
    setPyqPrompt('');
    setPyqSolution('');
    setPyqMessage('Verified PYQ added to Database A.');
  };

  return (
    <div className="space-y-6">
      <div className="rounded-xl bg-[#0B1F3A] text-white p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <p className="text-xs font-semibold text-cyan-300 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4" />
            <span>Academic Director Administration Console</span>
          </p>
          <h1 className="text-2xl font-bold">
            Dr. V. Sesha Sai Kumar · GRIET, Hyderabad
          </h1>
          <p className="text-xs text-slate-300">
            Content Pipeline: GENERATE → VALIDATE → TEACHER REVIEW → APPROVE → PUBLISH
          </p>
        </div>
        <div className="grid grid-cols-3 gap-3 text-center text-xs">
          <div className="rounded-lg bg-white/10 px-3 py-2">
            <p className="font-bold text-base tabular-nums">{ALL_CHAPTERS.length}</p>
            <p className="text-slate-300">Chapters</p>
          </div>
          <div className="rounded-lg bg-white/10 px-3 py-2">
            <p className="font-bold text-base tabular-nums">{allQuestions.length}</p>
            <p className="text-slate-300">Questions</p>
          </div>
          <div className="rounded-lg bg-white/10 px-3 py-2">
            <p className="font-bold text-base tabular-nums">{attempts.length}</p>
            <p className="text-slate-300">Attempts</p>
          </div>
        </div>
      </div>

      {/* Admin Tabs */}
      <div className="inline-flex flex-wrap p-1 bg-slate-100 rounded-xl gap-1">
        <button
          type="button"
          onClick={() => setAdminTab('workflow')}
          className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold ${
            adminTab === 'workflow' ? 'bg-[#0B1F3A] text-white' : 'text-slate-600'
          }`}
        >
          Content Approval Pipeline
        </button>
        <button
          type="button"
          onClick={() => setAdminTab('syllabus')}
          className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold ${
            adminTab === 'syllabus' ? 'bg-[#0B1F3A] text-white' : 'text-slate-600'
          }`}
        >
          Syllabus Hierarchy (Firestore)
        </button>
        <button
          type="button"
          onClick={() => setAdminTab('pyq_import')}
          className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold ${
            adminTab === 'pyq_import' ? 'bg-[#0B1F3A] text-white' : 'text-slate-600'
          }`}
        >
          Verified PYQ Importer
        </button>
        <button
          type="button"
          onClick={() => setAdminTab('android')}
          className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold ${
            adminTab === 'android' ? 'bg-[#0B1F3A] text-white' : 'text-slate-600'
          }`}
        >
          Android APK &amp; Play Store Guide
        </button>
      </div>

      {adminTab === 'workflow' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <form
            onSubmit={handleGenerateModule}
            className="lg:col-span-5 rounded-xl border border-slate-200 bg-white p-5 space-y-4 h-fit"
          >
            <h2 className="text-base font-bold text-[#0B1F3A] flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-700" />
              <span>Generate Supplementary Module</span>
            </h2>
            <div>
              <label htmlFor="adm-ch" className="block text-xs font-semibold text-slate-600 mb-1">
                Chapter
              </label>
              <select
                id="adm-ch"
                value={genChapterId}
                onChange={(e) => setGenChapterId(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              >
                {ALL_CHAPTERS.map((c) => (
                  <option key={c.id} value={c.id}>
                    Ch {c.number}: {c.title}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="adm-sub" className="block text-xs font-semibold text-slate-600 mb-1">
                Subtopic Focus
              </label>
              <input
                id="adm-sub"
                type="text"
                required
                value={genSubtopic}
                onChange={(e) => setGenSubtopic(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label htmlFor="adm-lvl" className="block text-xs font-semibold text-slate-600 mb-1">
                Target Level
              </label>
              <select
                id="adm-lvl"
                value={genLevel}
                onChange={(e) => setGenLevel(e.target.value as AcademicLevel)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              >
                <option value="foundation">Foundation</option>
                <option value="jee_main">JEE Main</option>
                <option value="jee_advanced">JEE Advanced</option>
              </select>
            </div>
            <button
              type="submit"
              disabled={genLoading}
              className="w-full py-2.5 rounded-lg bg-[#0B1F3A] text-white text-xs font-semibold disabled:opacity-50"
            >
              {genLoading ? 'Generating via Gemini...' : 'Generate Draft Module'}
            </button>
            {genStatus && (
              <p className="text-xs text-cyan-800 bg-cyan-50 border border-cyan-200 rounded-lg p-3">
                {genStatus}
              </p>
            )}
          </form>

          <div className="lg:col-span-7 space-y-3">
            <h2 className="text-base font-bold text-[#0B1F3A]">
              Approval Queue ({managedContent.length} items)
            </h2>
            {managedContent.map((item) => {
              const curIdx = WORKFLOW_STAGES.indexOf(item.workflowStatus);
              const nextStage =
                curIdx >= 0 && curIdx < WORKFLOW_STAGES.length - 1
                  ? WORKFLOW_STAGES[curIdx + 1]
                  : null;

              return (
                <article key={item.contentId} className="rounded-xl border border-slate-200 bg-white p-4 space-y-2.5">
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                    <span className="font-medium text-slate-500">
                      {item.chapterId.toUpperCase()} · {item.sourceLabel}
                    </span>
                    <span className="font-bold text-cyan-800">
                      Stage: {item.workflowStatus.replace('_', ' ')}
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-[#0B1F3A]">{item.title}</h3>
                  <p className="text-xs text-slate-700 leading-relaxed">
                    <MathText text={item.summary} />
                  </p>
                  <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100">
                    {nextStage ? (
                      <button
                        type="button"
                        onClick={() => advanceWorkflowStatus(item.contentId, nextStage)}
                        className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold"
                      >
                        Advance to {nextStage.replace('_', ' ')}
                      </button>
                    ) : (
                      <span className="text-xs font-semibold text-emerald-700 inline-flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Live for Students</span>
                      </span>
                    )}
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      )}

      {adminTab === 'syllabus' && (
        <div className="space-y-5">
          <div className="rounded-xl border border-slate-200 bg-white p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div className="space-y-1">
              <h2 className="text-base font-bold text-[#0B1F3A] flex items-center gap-2">
                <Database className="w-4 h-4 text-cyan-700" />
                <span>Normalized 14-Chapter Syllabus Data Model (Firestore)</span>
              </h2>
              <p className="text-xs text-slate-600">
                Collection schema:{' '}
                <code className="font-mono bg-slate-100 px-1.5 py-0.5 rounded">
                  /syllabus/{'{chapterId}'}/topics/{'{topicId}'}/subtopics/{'{subtopicId}'}
                </code>
              </p>
              <p className="text-xs text-slate-500">
                Structure: {syllabusStats.chapterCount} chapters · {syllabusStats.topicCount} topics ·{' '}
                {syllabusStats.subtopicCount} subtopics ({syllabusStats.enrichmentSubtopics} enrichment-only)
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <span
                className={`px-3 py-1.5 rounded-lg border text-xs font-semibold ${
                  syllabusSyncStatus === 'firestore_synced'
                    ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
                    : 'border-slate-200 bg-slate-50 text-slate-700'
                }`}
              >
                Status:{' '}
                {syllabusSyncStatus === 'firestore_synced'
                  ? 'Synced with Firestore'
                  : syllabusSyncStatus === 'syncing'
                    ? 'Syncing Batch...'
                    : 'Bundled Local Model'}
              </span>
              <button
                type="button"
                onClick={() => syncSyllabusHierarchy()}
                disabled={syllabusSyncStatus === 'syncing'}
                className="px-4 py-2 rounded-lg bg-[#0B1F3A] hover:bg-[#132D52] text-white text-xs font-semibold disabled:opacity-50"
              >
                {syllabusSyncStatus === 'syncing'
                  ? 'Syncing to Firestore...'
                  : 'Sync 14-Chapter Hierarchy to Firestore'}
              </button>
            </div>
          </div>

          {syllabusSyncMessage && (
            <div className="rounded-xl border border-cyan-200 bg-cyan-50/70 px-4 py-3 text-xs font-medium text-cyan-900">
              {syllabusSyncMessage}
            </div>
          )}

          <div className="rounded-xl border border-slate-200 bg-white overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4 font-semibold">Ch</th>
                  <th className="py-3 px-4 font-semibold">NCERT Ref</th>
                  <th className="py-3 px-4 font-semibold">Chapter Title</th>
                  <th className="py-3 px-4 font-semibold">Topics</th>
                  <th className="py-3 px-4 font-semibold">Subtopics</th>
                  <th className="py-3 px-4 font-semibold">Curriculum Scopes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {syllabusHierarchy.map((ch) => {
                  const subCount = ch.topics.reduce((acc, t) => acc + t.subtopics.length, 0);
                  return (
                    <tr key={ch.chapterId} className="hover:bg-slate-50/60">
                      <td className="py-2.5 px-4 font-mono font-semibold text-[#0B1F3A] tabular-nums">
                        {String(ch.chapterNumber).padStart(2, '0')}
                      </td>
                      <td className="py-2.5 px-4 text-slate-600 whitespace-nowrap">
                        {ch.ncertBookPart} · Ch {ch.ncertChapterNumber}
                      </td>
                      <td className="py-2.5 px-4 font-semibold text-[#0B1F3A]">{ch.title}</td>
                      <td className="py-2.5 px-4 tabular-nums text-slate-700">{ch.topics.length}</td>
                      <td className="py-2.5 px-4 tabular-nums text-slate-700">{subCount}</td>
                      <td className="py-2.5 px-4 text-slate-600">
                        {ch.topics.map((t) => `${t.code} (${t.curriculumScope})`).join(' · ')}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {adminTab === 'pyq_import' && (
        <form
          onSubmit={handleImportPyq}
          className="rounded-xl border border-slate-200 bg-white p-6 max-w-2xl space-y-4"
        >
          <h2 className="text-base font-bold text-[#0B1F3A] flex items-center gap-2">
            <Upload className="w-4 h-4 text-cyan-700" />
            <span>Import Verified Historical PYQ (Database A)</span>
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <select
              value={pyqChapterId}
              onChange={(e) => setPyqChapterId(e.target.value)}
              className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
            >
              {ALL_CHAPTERS.map((c) => (
                <option key={c.id} value={c.id}>
                  Ch {c.number}: {c.title}
                </option>
              ))}
            </select>
            <input
              type="text"
              value={pyqExam}
              onChange={(e) => setPyqExam(e.target.value)}
              placeholder="Exam (e.g., JEE Main)"
              className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
            <input
              type="number"
              min={1978}
              max={2026}
              value={pyqYear}
              onChange={(e) => setPyqYear(Number(e.target.value))}
              className="rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <select
              value={pyqFormat}
              onChange={(e) => setPyqFormat(e.target.value as QuestionFormat)}
              className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
            >
              <option value="single_mcq">Single-Correct MCQ</option>
              <option value="multiple_mcq">Multiple-Correct MCQ</option>
              <option value="numerical">Numerical</option>
            </select>
            <input
              type="text"
              required
              value={pyqSource}
              onChange={(e) => setPyqSource(e.target.value)}
              placeholder="Verified source citation"
              className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>
          <textarea
            required
            rows={3}
            value={pyqPrompt}
            onChange={(e) => setPyqPrompt(e.target.value)}
            placeholder="Exact verified question statement (supports $...$ LaTeX)..."
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
          />
          <select
            value={pyqAnswerIdx}
            onChange={(e) => setPyqAnswerIdx(Number(e.target.value))}
            className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
          >
            <option value={0}>Correct Option: A</option>
            <option value={1}>Correct Option: B</option>
            <option value={2}>Correct Option: C</option>
            <option value={3}>Correct Option: D</option>
          </select>
          <textarea
            required
            rows={3}
            value={pyqSolution}
            onChange={(e) => setPyqSolution(e.target.value)}
            placeholder="Verified step-by-step solution..."
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
          />
          <button
            type="submit"
            className="px-5 py-2.5 rounded-lg bg-[#0B1F3A] text-white text-xs font-semibold"
          >
            Verify &amp; Publish to Database A
          </button>
          {pyqMessage && <p className="text-xs font-semibold text-emerald-700">{pyqMessage}</p>}
        </form>
      )}

      {adminTab === 'android' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-4 text-sm text-slate-700">
          <h2 className="text-lg font-bold text-[#0B1F3A] flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-cyan-700" />
            <span>Android APK Build &amp; Google Play Store Deployment Guide</span>
          </h2>
          <p>
            This application includes <code className="font-mono text-xs bg-slate-100 px-1.5 py-0.5 rounded">capacitor.config.ts</code> configured for Android package <code className="font-mono text-xs bg-slate-100 px-1.5 py-0.5 rounded">in.ac.griet.masterjee.physics11</code>.
          </p>
          <ol className="list-decimal pl-5 space-y-2 leading-relaxed">
            <li>Install Capacitor Android tooling: <code className="font-mono text-xs bg-slate-100 px-1.5 py-0.5 rounded">npm install @capacitor/core @capacitor/cli @capacitor/android</code></li>
            <li>Build the production bundle: <code className="font-mono text-xs bg-slate-100 px-1.5 py-0.5 rounded">npm run build</code></li>
            <li>Initialize and sync Android platform: <code className="font-mono text-xs bg-slate-100 px-1.5 py-0.5 rounded">npx cap add android &amp;&amp; npx cap sync android</code></li>
            <li>Open Android Studio (<code className="font-mono text-xs bg-slate-100 px-1.5 py-0.5 rounded">npx cap open android</code>), configure your release keystore, and build a debug/release APK or signed Android App Bundle (<code className="font-mono text-xs bg-slate-100 px-1.5 py-0.5 rounded">.aab</code>).</li>
            <li>Upload the signed <code className="font-mono text-xs bg-slate-100 px-1.5 py-0.5 rounded">.aab</code> in Google Play Console along with privacy policy, educational data safety declarations, and screenshots.</li>
          </ol>
        </div>
      )}
    </div>
  );
}
