import type { SubtopicContent } from '../types/physics';

export function PhysicsDiagramSvg({
  svgType,
  title,
  caption,
}: {
  svgType: SubtopicContent['diagramSpec']['svgType'];
  title: string;
  caption: string;
}) {
  return (
    <figure className="rounded-xl border border-slate-200 bg-white p-4">
      <figcaption className="mb-3 flex flex-wrap items-baseline justify-between gap-2">
        <span className="text-sm font-semibold text-[#0B1F3A]">{title}</span>
        <span className="text-xs text-slate-500">Technical Schematic</span>
      </figcaption>
      <div className="overflow-hidden rounded-lg bg-[#0B1F3A] p-3">
        <svg
          viewBox="0 0 560 200"
          className="h-auto w-full max-h-56"
          role="img"
          aria-label={title}
        >
          <defs>
            <pattern id="grid-blueprint" width="20" height="20" patternUnits="userSpaceOnUse">
              <path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(148,163,184,0.14)" strokeWidth="0.7" />
            </pattern>
          </defs>
          <rect width="560" height="200" fill="url(#grid-blueprint)" />

          {svgType === 'vernier' && (
            <g stroke="#E2E8F0" strokeWidth="1.5" fill="none">
              <rect x="40" y="38" width="460" height="44" fill="#132D52" stroke="#38BDF8" />
              {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((i) => (
                <g key={i}>
                  <line x1={60 + i * 38} y1="82" x2={60 + i * 38} y2={i % 5 === 0 ? 58 : 68} stroke="#F8FAFC" />
                  <text x={56 + i * 38} y="52" fill="#94A3B8" fontSize="11" stroke="none">{i}</text>
                </g>
              ))}
              <rect x="136" y="84" width="210" height="44" fill="#0F294A" stroke="#06B6D4" />
              {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((i) => (
                <g key={i}>
                  <line x1={150 + i * 17.1} y1="84" x2={150 + i * 17.1} y2="104" stroke="#22D3EE" />
                </g>
              ))}
              <line x1="252.6" y1="35" x2="252.6" y2="136" stroke="#F59E0B" strokeDasharray="4 3" />
              <text x="260" y="152" fill="#FBBF24" fontSize="12" stroke="none">6th VSD Coincides (LC = 1 MSD − 1 VSD)</text>
              <text x="40" y="176" fill="#CBD5E1" fontSize="11" stroke="none">Observed Reading = MSR + (VSR × LC)  |  True Reading = Observed − Zero Error</text>
            </g>
          )}

          {svgType === 'error_bars' && (
            <g stroke="#38BDF8" strokeWidth="1.5" fill="none">
              <line x1="60" y1="160" x2="500" y2="160" stroke="#94A3B8" />
              <line x1="60" y1="25" x2="60" y2="160" stroke="#94A3B8" />
              <path d="M 80 155 Q 190 150, 280 42 Q 370 150, 480 155" stroke="#22D3EE" strokeWidth="2.4" />
              <line x1="280" y1="35" x2="280" y2="160" stroke="#F59E0B" strokeDasharray="4 3" />
              <line x1="220" y1="100" x2="340" y2="100" stroke="#34D399" strokeWidth="2" />
              <circle cx="280" cy="100" r="4" fill="#34D399" />
              <text x="290" y="54" fill="#FBBF24" fontSize="11" stroke="none">Mean Value x̄</text>
              <text x="195" y="118" fill="#6EE7B7" fontSize="11" stroke="none">± Δx Uncertainty Interval</text>
            </g>
          )}

          {svgType === 'kinematics_vt' && (
            <g stroke="#38BDF8" strokeWidth="1.8" fill="none">
              <line x1="60" y1="165" x2="500" y2="165" stroke="#94A3B8" />
              <line x1="60" y1="25" x2="60" y2="165" stroke="#94A3B8" />
              <polygon points="60,165 60,115 390,42 390,165" fill="rgba(6,182,212,0.22)" stroke="none" />
              <line x1="60" y1="115" x2="390" y2="42" stroke="#22D3EE" strokeWidth="2.5" />
              <text x="28" y="34" fill="#CBD5E1" fontSize="11" stroke="none">v(t)</text>
              <text x="485" y="182" fill="#CBD5E1" fontSize="11" stroke="none">t</text>
              <text x="175" y="130" fill="#67E8F9" fontSize="12" stroke="none">Area = ∫ v dt = Displacement</text>
              <text x="220" y="58" fill="#FBBF24" fontSize="11" stroke="none">Slope = dv/dt = a</text>
            </g>
          )}

          {svgType === 'projectile' && (
            <g fill="none">
              <line x1="50" y1="165" x2="510" y2="165" stroke="#94A3B8" strokeWidth="1.5" />
              <path d="M 70 165 Q 280 10 490 165" stroke="#22D3EE" strokeWidth="2.5" />
              <line x1="70" y1="165" x2="145" y2="90" stroke="#F59E0B" strokeWidth="2" />
              <circle cx="280" cy="87" r="4.5" fill="#22D3EE" />
              <line x1="280" y1="87" x2="355" y2="87" stroke="#34D399" strokeWidth="2" />
              <text x="360" y="91" fill="#6EE7B7" fontSize="11">v_x = u cos θ (v_y = 0)</text>
              <text x="150" y="88" fill="#FBBF24" fontSize="11">u at angle θ</text>
              <text x="245" y="182" fill="#CBD5E1" fontSize="11">Range R = u² sin(2θ) / g</text>
            </g>
          )}

          {svgType === 'fbd_incline' && (
            <g fill="none">
              <polygon points="80,165 440,165 440,55" fill="rgba(30,41,59,0.7)" stroke="#94A3B8" strokeWidth="1.5" />
              <g transform="translate(270,107) rotate(-17)">
                <rect x="-24" y="-22" width="48" height="22" fill="#0891B2" stroke="#E2E8F0" strokeWidth="1.5" />
                <line x1="0" y1="-22" x2="0" y2="-62" stroke="#34D399" strokeWidth="2" />
                <text x="6" y="-54" fill="#6EE7B7" fontSize="11">N</text>
                <line x1="24" y1="-11" x2="68" y2="-11" stroke="#FBBF24" strokeWidth="2" />
                <text x="72" y="-8" fill="#FBBF24" fontSize="11">f_s</text>
              </g>
              <line x1="270" y1="107" x2="270" y2="165" stroke="#F87171" strokeWidth="2" />
              <text x="276" y="158" fill="#FCA5A5" fontSize="11">mg</text>
              <text x="115" y="156" fill="#CBD5E1" fontSize="12">θ</text>
            </g>
          )}

          {(svgType === 'work_area' || svgType === 'stress_strain') && (
            <g fill="none">
              <line x1="65" y1="160" x2="495" y2="160" stroke="#94A3B8" strokeWidth="1.5" />
              <line x1="65" y1="28" x2="65" y2="160" stroke="#94A3B8" strokeWidth="1.5" />
              <path d="M 65 160 L 220 55 Q 320 45, 440 75" stroke="#22D3EE" strokeWidth="2.4" />
              <polygon points="65,160 220,55 220,160" fill="rgba(6,182,212,0.22)" />
              <text x="120" y="138" fill="#67E8F9" fontSize="11">Linear Elastic / W = ∫ F dx</text>
              <text x="230" y="45" fill="#FBBF24" fontSize="11">Proportional Limit / Yield</text>
            </g>
          )}

          {(svgType === 'torque_wheel' || svgType === 'orbit_kepler' || svgType === 'shm_phasor') && (
            <g fill="none">
              <ellipse cx="280" cy="100" rx="145" ry="62" stroke="#22D3EE" strokeWidth="2" />
              <circle cx="205" cy="100" r="10" fill="#F59E0B" />
              <circle cx="408" cy="68" r="7" fill="#38BDF8" />
              <line x1="205" y1="100" x2="408" y2="68" stroke="#94A3B8" strokeDasharray="4 3" />
              <text x="180" y="128" fill="#FBBF24" fontSize="11">Focus / Pivot / Phasor</text>
              <text x="422" y="72" fill="#E2E8F0" fontSize="11">v(t), L conserved</text>
            </g>
          )}

          {(svgType === 'bernoulli_pipe' || svgType === 'thermal_expansion' || svgType === 'pv_carnot' || svgType === 'maxwell_speed' || svgType === 'standing_wave') && (
            <g fill="none">
              <path d="M 60 65 Q 200 65, 280 85 Q 360 65, 500 65" stroke="#38BDF8" strokeWidth="2.5" />
              <path d="M 60 135 Q 200 135, 280 115 Q 360 135, 500 135" stroke="#38BDF8" strokeWidth="2.5" />
              <path d="M 85 100 Q 182 55, 280 100 T 475 100" stroke="#22D3EE" strokeWidth="2" />
              <path d="M 85 100 Q 182 145, 280 100 T 475 100" stroke="#FBBF24" strokeWidth="1.6" strokeDasharray="4 3" />
              <text x="145" y="168" fill="#CBD5E1" fontSize="11">Streamline Continuity / Wave Envelope & Harmonic Modes</text>
            </g>
          )}
        </svg>
      </div>
      <p className="mt-2 text-xs text-slate-600 leading-relaxed">{caption}</p>
    </figure>
  );
}
