import { useState } from 'react';
import { ShieldCheck, Info, CheckCircle2, XCircle } from 'lucide-react';
import { ALL_CHAPTERS } from '../data/curriculumIndex';
import { PYQ_COVERAGE_REGISTRY } from '../data/questionBank';
import { useApp } from '../context/AppContext';
import { MathText } from './MathBlock';
import type { QuestionDatabaseCategory, QuestionFormat } from '../types/physics';
import { verifyNumericalAnswer } from '../utils/physicsMath';

const DB_TABS: { id: 'ALL' | QuestionDatabaseCategory; label: string }[] = [
  { id: 'ALL', label: 'All Banks' },
  { id: 'A_VERIFIED_PYQ', label: 'Database A · Verified PYQs' },
  { id: 'B_AI_ORIGINAL', label: 'Database B · AI Practice' },
  { id: 'C_PYQ_INSPIRED', label: 'Database C · PYQ-Inspired' },
];

export function PyqArchive() {
  const { allQuestions } = useApp();
  const [dbFilter, setDbFilter] = useState<'ALL' | QuestionDatabaseCategory>('ALL');
  const [chapterFilter, setChapterFilter] = useState<string>('all');
  const [yearWindow, setYearWindow] = useState<'all' | '5' | '10' | '20' | '40'>('40');
  const [formatFilter, setFormatFilter] = useState<'all' | QuestionFormat>('all');

  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number[]>>({});
  const [numericalInputs, setNumericalInputs] = useState<Record<string, string>>({});
  const [checkedIds, setCheckedIds] = useState<Record<string, boolean>>({});

  const currentYear = 2026;

  const filtered = allQuestions.filter((q) => {
    if (dbFilter !== 'ALL' && q.databaseCategory !== dbFilter) return false;
    if (chapterFilter !== 'all' && q.chapterId !== chapterFilter) return false;
    if (formatFilter !== 'all' && q.format !== formatFilter) return false;
    if (yearWindow !== 'all') {
      const span = Number(yearWindow);
      if (q.year < currentYear - span) return false;
    }
    return true;
  });

  const toggleOption = (qId: string, optIdx: number, isMulti: boolean) => {
    setSelectedAnswers((prev) => {
      const cur = prev[qId] ?? [];
      if (!isMulti) return { ...prev, [qId]: [optIdx] };
      return {
        ...prev,
        [qId]: cur.includes(optIdx) ? cur.filter((x) => x !== optIdx) : [...cur, optIdx],
      };
    });
  };

  const evaluateItem = (qId: string) => {
    setCheckedIds((prev) => ({ ...prev, [qId]: true }));
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-[#0B1F3A]">
          40-Year JEE Previous-Year Question Bank &amp; Practice Archive
        </h1>
        <p className="mt-1 text-sm text-slate-600">
          Strictly separated into Verified Historical PYQs (Database A), Original AI-Generated Practice (Database B), and PYQ-Inspired Practice (Database C).
        </p>
      </div>

      {/* Historical Coverage Transparency Banner */}
      <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-2.5">
        <div className="flex items-center gap-2 text-xs font-bold text-[#0B1F3A]">
          <Info className="w-4 h-4 text-cyan-700" />
          <span>Historical Archive Integrity &amp; Coverage Status (1986–2025)</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          {PYQ_COVERAGE_REGISTRY.map((period) => (
            <div key={period.label} className="rounded-lg bg-slate-50 border border-slate-200 p-3 space-y-1">
              <p className="font-bold text-[#0B1F3A]">{period.label}</p>
              <p className={period.status.includes('Pending') ? 'text-amber-700 font-semibold' : 'text-emerald-700 font-semibold'}>
                {period.status}
              </p>
              <p className="text-slate-600">{period.notes}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Database Category Tabs */}
      <div className="flex flex-wrap gap-1.5 p-1 bg-slate-100 rounded-xl w-fit">
        {DB_TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setDbFilter(t.id)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
              dbFilter === t.id ? 'bg-[#0B1F3A] text-white' : 'text-slate-600 hover:text-[#0B1F3A]'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <select
          aria-label="Filter PYQs by chapter"
          value={chapterFilter}
          onChange={(e) => setChapterFilter(e.target.value)}
          className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-[#0B1F3A]"
        >
          <option value="all">All 14 Chapters</option>
          {ALL_CHAPTERS.map((c) => (
            <option key={c.id} value={c.id}>
              Ch {c.number}: {c.title}
            </option>
          ))}
        </select>

        <select
          aria-label="Filter PYQs by year window"
          value={yearWindow}
          onChange={(e) => setYearWindow(e.target.value as typeof yearWindow)}
          className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-[#0B1F3A]"
        >
          <option value="5">Last 5 Years</option>
          <option value="10">Last 10 Years</option>
          <option value="20">Last 20 Years</option>
          <option value="40">Last 40 Years (All Available)</option>
        </select>

        <select
          aria-label="Filter PYQs by format"
          value={formatFilter}
          onChange={(e) => setFormatFilter(e.target.value as typeof formatFilter)}
          className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-[#0B1F3A]"
        >
          <option value="all">All Question Formats</option>
          <option value="single_mcq">Single-Correct MCQ</option>
          <option value="multiple_mcq">Multiple-Correct MCQ</option>
          <option value="numerical">Numerical Value</option>
          <option value="integer">Integer Type</option>
          <option value="assertion_reason">Assertion-Reason</option>
          <option value="match">Matrix Match</option>
          <option value="paragraph">Paragraph Based</option>
        </select>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-8 text-center space-y-2">
          <p className="font-semibold text-[#0B1F3A]">
            No questions available for this specific filter combination yet.
          </p>
          <p className="text-xs text-slate-500">
            Historical paper coverage for earlier shifts/years is marked unavailable until verified papers are imported by the Academic Director.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map((q) => {
            const isChecked = Boolean(checkedIds[q.id]);
            const isNumerical = q.format === 'numerical' || q.format === 'integer';
            const isMulti = q.format === 'multiple_mcq';
            const sel = selectedAnswers[q.id] ?? [];
            const numVal = Number(numericalInputs[q.id] ?? '');
            const isCorrect = isChecked
              ? isNumerical
                ? verifyNumericalAnswer(numVal, q.numericalAnswer ?? 0, q.numericalTolerance ?? 0.05)
                : sel.length === (q.correctOptionIndices ?? []).length &&
                  [...sel].sort().every((v, i) => v === [...(q.correctOptionIndices ?? [])].sort()[i])
              : null;

            return (
              <article key={q.id} className="rounded-xl border border-slate-200 bg-white p-5 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
                  <span className="font-medium text-slate-700">
                    {q.exam} · {q.year}
                    {q.paper ? ` (${q.paper})` : ''} · {q.format.replace('_', ' ')} ·{' '}
                    {q.difficulty.replace('_', ' ')}
                  </span>
                  <span className="inline-flex items-center gap-1 font-semibold text-cyan-800">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>
                      {q.databaseCategory === 'A_VERIFIED_PYQ'
                        ? 'Database A: Verified PYQ'
                        : q.databaseCategory === 'B_AI_ORIGINAL'
                          ? 'Database B: Original AI-Generated'
                          : 'Database C: PYQ-Inspired Practice'}
                    </span>
                  </span>
                </div>

                <div className="text-sm sm:text-base text-[#0B1F3A] leading-relaxed font-medium">
                  <MathText text={q.prompt} />
                </div>

                {isNumerical ? (
                  <div className="flex flex-wrap items-center gap-3">
                    <input
                      type="number"
                      step="any"
                      value={numericalInputs[q.id] ?? ''}
                      onChange={(e) =>
                        setNumericalInputs((prev) => ({ ...prev, [q.id]: e.target.value }))
                      }
                      placeholder={`Enter numerical answer${q.unit ? ` (${q.unit})` : ''}`}
                      className="rounded-lg border border-slate-300 px-3 py-2 text-sm w-60 font-mono"
                    />
                    {q.unit && <span className="text-xs font-mono text-slate-500">{q.unit}</span>}
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {(q.options ?? []).map((opt, idx) => {
                      const active = sel.includes(idx);
                      return (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => toggleOption(q.id, idx, isMulti)}
                          className={`text-left rounded-lg border px-3.5 py-2.5 text-sm transition-colors ${
                            active
                              ? 'border-cyan-600 bg-cyan-50 text-[#0B1F3A] font-semibold'
                              : 'border-slate-200 hover:bg-slate-50 text-slate-800'
                          }`}
                        >
                          <span className="font-mono text-xs text-slate-500 mr-2">
                            ({String.fromCharCode(65 + idx)})
                          </span>
                          <MathText text={opt} />
                        </button>
                      );
                    })}
                  </div>
                )}

                <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => evaluateItem(q.id)}
                    className="px-4 py-2 rounded-lg bg-[#0B1F3A] hover:bg-[#132D52] text-white text-xs font-semibold"
                  >
                    Verify Answer &amp; View Solution
                  </button>
                  <span className="text-xs text-slate-400">{q.sourceCitation}</span>
                </div>

                {isChecked && (
                  <div
                    className={`rounded-lg border p-4 space-y-2 text-sm ${
                      isCorrect
                        ? 'border-emerald-200 bg-emerald-50/50'
                        : 'border-amber-200 bg-amber-50/50'
                    }`}
                  >
                    <div className="flex items-center gap-2 font-bold">
                      {isCorrect ? (
                        <>
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          <span className="text-emerald-800">Correct!</span>
                        </>
                      ) : (
                        <>
                          <XCircle className="w-4 h-4 text-amber-700" />
                          <span className="text-amber-900">
                            Expected Answer:{' '}
                            {isNumerical
                              ? `${q.numericalAnswer} ${q.unit ?? ''}`
                              : (q.correctOptionIndices ?? [])
                                  .map((i) => String.fromCharCode(65 + i))
                                  .join(', ')}
                          </span>
                        </>
                      )}
                    </div>
                    <p className="text-slate-700 leading-relaxed">
                      <MathText text={q.solution} />
                    </p>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
