import { useState } from 'react';
import { Send, Lightbulb, Sparkles, BookOpen } from 'lucide-react';
import { ALL_CHAPTERS, getChapterById } from '../data/curriculumIndex';
import { useApp } from '../context/AppContext';
import { MathText } from './MathBlock';

interface ChatTurn {
  id: string;
  role: 'user' | 'tutor';
  text: string;
}

const SUGGESTED_PROMPTS = [
  'Explain projectile motion from first principles.',
  'Derive the equation of trajectory step by step.',
  'Why does centripetal acceleration act towards the centre?',
  'Explain angular momentum conservation with a physical example.',
  'Give me five challenging JEE Advanced conceptual questions on this chapter.',
];

export function AiTutorView() {
  const { activeChapterId, setActiveChapterId, academicLevel, setActiveScreen } = useApp();
  const chapter = getChapterById(activeChapterId);

  const [hintOnly, setHintOnly] = useState(false);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatTurn[]>([
    {
      id: 'welcome-1',
      role: 'tutor',
      text: `Hello! I am your MASTER JEE Physics Teaching Assistant for **Chapter ${chapter.number}: ${chapter.title}** (${academicLevel.replace('_', ' ')} level). Ask me to explain concepts, derive equations step-by-step, verify your numerical solution, or switch on **Hint-First Mode** before seeing the answer.`,
    },
  ]);

  const sendMessage = async (promptText: string) => {
    const trimmed = promptText.trim();
    if (!trimmed || loading) return;

    const userTurn: ChatTurn = { id: `u-${Date.now()}`, role: 'user', text: trimmed };
    setMessages((prev) => [...prev, userTurn]);
    setInput('');
    setLoading(true);
    setErrorMsg(null);

    const chapterContext = chapter.subtopics
      .map(
        (s) =>
          `${s.title}: ${s.theoreticalExplanation[academicLevel]} Equations: ${s.mathematicalFormulation
            .map((m) => m.latex)
            .join(', ')}`
      )
      .join('\n');

    try {
      const res = await fetch('/api/tutor/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: trimmed,
          chapterTitle: `Chapter ${chapter.number}: ${chapter.title}`,
          chapterContext,
          academicLevel,
          hintOnly,
          history: messages.slice(-6).map((m) => ({ role: m.role, text: m.text })),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'AI Tutor service returned an error.');
      }
      setMessages((prev) => [
        ...prev,
        { id: `t-${Date.now()}`, role: 'tutor', text: data.reply },
      ]);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Network error reaching AI Tutor.';
      setErrorMsg(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-5">
      <div className="rounded-xl border border-slate-200 bg-white p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-[#0B1F3A]">AI Physics Tutor</h1>
          <p className="text-xs text-slate-500">
            Contextual explanations grounded in your active chapter and academic tier.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <select
            aria-label="Select chapter context for AI tutor"
            value={chapter.id}
            onChange={(e) => setActiveChapterId(e.target.value)}
            className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-sm font-medium text-[#0B1F3A]"
          >
            {ALL_CHAPTERS.map((c) => (
              <option key={c.id} value={c.id}>
                Ch {c.number}: {c.title}
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={() => setHintOnly((v) => !v)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold border inline-flex items-center gap-1.5 transition-colors whitespace-nowrap ${
              hintOnly
                ? 'bg-amber-50 border-amber-300 text-amber-800'
                : 'bg-white border-slate-200 text-slate-700'
            }`}
          >
            <Lightbulb className="w-3.5 h-3.5" />
            <span>{hintOnly ? 'Hint-First: ON' : 'Hint-First: OFF'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveScreen('reader')}
            className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-50 inline-flex items-center gap-1.5 whitespace-nowrap"
          >
            <BookOpen className="w-3.5 h-3.5 text-cyan-700" />
            <span>Open Textbook</span>
          </button>
        </div>
      </div>

      {/* Quick Prompt Buttons */}
      <div className="flex flex-wrap gap-2">
        {SUGGESTED_PROMPTS.map((p) => (
          <button
            key={p}
            type="button"
            onClick={() => sendMessage(p)}
            disabled={loading}
            className="px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:border-cyan-500 text-xs text-slate-700 transition-colors"
          >
            {p}
          </button>
        ))}
      </div>

      {/* Conversation Container */}
      <div className="rounded-xl border border-slate-200 bg-white flex flex-col h-[460px]">
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-3xl rounded-xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap ${
                  m.role === 'user'
                    ? 'bg-[#0B1F3A] text-white'
                    : 'bg-slate-50 border border-slate-200 text-slate-800'
                }`}
              >
                {m.role === 'tutor' && (
                  <p className="text-xs font-semibold text-cyan-800 mb-1 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Physics Assistant · {chapter.title}</span>
                  </p>
                )}
                <MathText text={m.text} />
              </div>
            </div>
          ))}
          {loading && (
            <div className="text-xs text-slate-500 italic">
              Deriving physics explanation and checking dimensional consistency...
            </div>
          )}
          {errorMsg && (
            <div role="alert" className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-xs text-red-800">
              {errorMsg}
            </div>
          )}
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            sendMessage(input);
          }}
          className="border-t border-slate-200 p-3 flex items-center gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask a Physics question, paste a numerical problem, or request a derivation..."
            aria-label="Ask AI Physics Tutor"
            className="flex-1 rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:outline-none focus:border-cyan-600"
          />
          <button
            type="submit"
            disabled={loading || !input.trim()}
            className="px-4 py-2.5 rounded-lg bg-[#0B1F3A] hover:bg-[#132D52] disabled:opacity-50 text-white text-sm font-semibold inline-flex items-center gap-1.5 whitespace-nowrap"
          >
            <Send className="w-4 h-4" />
            <span>Ask</span>
          </button>
        </form>
      </div>
    </div>
  );
}
