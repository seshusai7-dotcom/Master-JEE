import { useState, useEffect } from 'react';
import {
  CheckCircle2,
  BookmarkPlus,
  ChevronDown,
  ChevronUp,
  Network,
  FlaskConical,
  Brain,
  ClipboardCheck,
} from 'lucide-react';
import { ALL_CHAPTERS, getChapterById } from '../data/curriculumIndex';
import { useApp } from '../context/AppContext';
import { MathFormula, MathText } from './MathBlock';
import { PhysicsDiagramSvg } from './PhysicsDiagramSvg';
import type { AcademicLevel } from '../types/physics';

export function ChapterReader() {
  const {
    activeChapterId,
    setActiveChapterId,
    activeSubtopicId: contextSubtopicId,
    setActiveSubtopicId: setContextSubtopicId,
    academicLevel,
    setAcademicLevel,
    completedSubtopics,
    toggleSubtopicComplete,
    saveNote,
    managedContent,
    setActiveScreen,
  } = useApp();

  const chapter = getChapterById(activeChapterId);
  const [activeSubtopicId, setActiveSubtopicId] = useState(
    contextSubtopicId && chapter.subtopics.some((s) => s.id === contextSubtopicId)
      ? contextSubtopicId
      : chapter.subtopics[0]?.id ?? ''
  );
  const [expandedDerivationIds, setExpandedDerivationIds] = useState<string[]>(
    chapter.derivations[0] ? [chapter.derivations[0].id] : []
  );
  const [noteStatus, setNoteStatus] = useState<string | null>(null);

  useEffect(() => {
    if (contextSubtopicId && chapter.subtopics.some((s) => s.id === contextSubtopicId)) {
      setActiveSubtopicId(contextSubtopicId);
    } else {
      setActiveSubtopicId(chapter.subtopics[0]?.id ?? '');
    }
    setExpandedDerivationIds(chapter.derivations[0] ? [chapter.derivations[0].id] : []);
  }, [chapter.id, contextSubtopicId]);

  const selectSubtopic = (id: string) => {
    setActiveSubtopicId(id);
    setContextSubtopicId(id);
  };

  const subtopic =
    chapter.subtopics.find((s) => s.id === activeSubtopicId) ?? chapter.subtopics[0];

  const isCompleted = subtopic ? completedSubtopics.includes(subtopic.id) : false;

  const publishedSupplements = managedContent.filter(
    (m) => m.chapterId === chapter.id && m.workflowStatus === 'PUBLISH'
  );

  const toggleDerivation = (id: string) => {
    setExpandedDerivationIds((prev) =>
      prev.includes(id) ? prev.filter((d) => d !== id) : [...prev, id]
    );
  };

  const handleBookmarkSubtopic = async () => {
    if (!subtopic) return;
    await saveNote({
      noteId: `bm-${subtopic.id}`,
      chapterId: chapter.id,
      category: 'bookmark',
      title: `${chapter.number}. ${subtopic.title}`,
      body: subtopic.summaryPoints.join(' '),
    });
    setNoteStatus('Saved to Revision Vault');
    setTimeout(() => setNoteStatus(null), 2500);
  };

  const levelLabel: Record<AcademicLevel, string> = {
    foundation: 'Level 1 · Foundation Physics',
    jee_main: 'Level 2 · JEE Main',
    jee_advanced: 'Level 3 · JEE Advanced',
  };

  return (
    <div className="space-y-6">
      {/* Workspace Toolbar */}
      <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2.5">
            <label htmlFor="chapter-select" className="text-xs font-semibold text-slate-600">
              Chapter:
            </label>
            <select
              id="chapter-select"
              value={chapter.id}
              onChange={(e) => {
                setActiveChapterId(e.target.value);
                setContextSubtopicId(null);
              }}
              className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-sm font-semibold text-[#0B1F3A] focus:outline-none focus:border-cyan-600"
            >
              {ALL_CHAPTERS.map((c) => (
                <option key={c.id} value={c.id}>
                  Ch {c.number}: {c.title}
                </option>
              ))}
            </select>

            <div className="inline-flex rounded-lg bg-slate-100 p-1">
              {(['foundation', 'jee_main', 'jee_advanced'] as AcademicLevel[]).map((lvl) => (
                <button
                  key={lvl}
                  type="button"
                  onClick={() => setAcademicLevel(lvl)}
                  className={`px-2.5 py-1 rounded-md text-xs font-semibold transition-colors whitespace-nowrap ${
                    academicLevel === lvl
                      ? 'bg-[#0B1F3A] text-white'
                      : 'text-slate-600 hover:text-[#0B1F3A]'
                  }`}
                >
                  {lvl === 'foundation' ? 'Foundation' : lvl === 'jee_main' ? 'JEE Main' : 'JEE Adv'}
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveScreen('mindmap')}
              className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-50 inline-flex items-center gap-1.5 whitespace-nowrap"
            >
              <Network className="w-3.5 h-3.5 text-cyan-700" />
              <span>Mind Map</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveScreen('lab')}
              className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-50 inline-flex items-center gap-1.5 whitespace-nowrap"
            >
              <FlaskConical className="w-3.5 h-3.5 text-cyan-700" />
              <span>Virtual Lab</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveScreen('tutor')}
              className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-50 inline-flex items-center gap-1.5 whitespace-nowrap"
            >
              <Brain className="w-3.5 h-3.5 text-cyan-700" />
              <span>Ask AI Tutor</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveScreen('quiz')}
              className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap"
            >
              <ClipboardCheck className="w-3.5 h-3.5" />
              <span>Chapter Quiz</span>
            </button>
          </div>
        </div>
      </div>

      {/* Subtopic Tabs */}
      <div className="flex flex-wrap gap-2">
        {chapter.subtopics.map((s) => (
          <button
            key={s.id}
            type="button"
            onClick={() => selectSubtopic(s.id)}
            className={`px-3.5 py-2 rounded-lg text-xs font-semibold border transition-colors whitespace-nowrap ${
              s.id === subtopic?.id
                ? 'bg-[#0B1F3A] text-white border-[#0B1F3A]'
                : 'bg-white text-slate-700 border-slate-200 hover:border-cyan-500'
            }`}
          >
            {s.title}
          </button>
        ))}
      </div>

      {subtopic && (
        <div className="space-y-6">
          {/* Subtopic Header Card */}
          <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="space-y-1">
                <p className="text-xs text-slate-500 font-medium">
                  Chapter {chapter.number} · {subtopic.syllabusTag} · {levelLabel[academicLevel]} ·
                  Original Academic Module
                </p>
                <h1 className="text-2xl font-bold text-[#0B1F3A]">{subtopic.title}</h1>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleBookmarkSubtopic}
                  className="px-3 py-2 rounded-lg border border-slate-200 hover:bg-slate-50 text-xs font-medium text-slate-700 inline-flex items-center gap-1.5 whitespace-nowrap"
                >
                  <BookmarkPlus className="w-4 h-4 text-cyan-700" />
                  <span>{noteStatus ?? 'Bookmark Topic'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => toggleSubtopicComplete(subtopic.id)}
                  className={`px-3.5 py-2 rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap transition-colors ${
                    isCompleted
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isCompleted ? 'Completed' : 'Mark Complete'}</span>
                </button>
              </div>
            </div>

            {/* A. Introduction & Learning Objectives */}
            <div className="pt-4 border-t border-slate-100 space-y-2">
              <h2 className="text-sm font-bold text-[#0B1F3A]">
                A. Introduction &amp; Learning Objectives
              </h2>
              <ul className="list-disc pl-5 space-y-1 text-sm text-slate-700 leading-relaxed">
                {subtopic.introductionAndObjectives.map((item, i) => (
                  <li key={i}>
                    <MathText text={item} />
                  </li>
                ))}
              </ul>
            </div>

            {/* B. Detailed Theoretical Explanation (Adapted to Academic Level) */}
            <div className="pt-4 border-t border-slate-100 space-y-2">
              <h2 className="text-sm font-bold text-[#0B1F3A]">
                B. Theoretical Explanation ({levelLabel[academicLevel]})
              </h2>
              <p className="text-sm sm:text-base text-slate-800 leading-relaxed">
                <MathText text={subtopic.theoreticalExplanation[academicLevel]} />
              </p>
            </div>

            {/* C & D: Definitions & Physical Interpretation */}
            <div className="pt-4 border-t border-slate-100 grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-2">
                <h2 className="text-sm font-bold text-[#0B1F3A]">
                  C. Definitions &amp; Fundamental Principles
                </h2>
                <dl className="space-y-2">
                  {subtopic.definitionsAndPrinciples.map((def) => (
                    <div key={def.term} className="rounded-lg bg-slate-50 p-3 border border-slate-200/70">
                      <dt className="text-xs font-bold text-[#0B1F3A]">{def.term}</dt>
                      <dd className="mt-0.5 text-sm text-slate-700">
                        <MathText text={def.definition} />
                      </dd>
                    </div>
                  ))}
                </dl>
              </div>

              <div className="space-y-4">
                <div>
                  <h2 className="text-sm font-bold text-[#0B1F3A]">
                    D. Physical Interpretation
                  </h2>
                  <p className="mt-1.5 text-sm text-slate-700 leading-relaxed">
                    <MathText text={subtopic.physicalInterpretation} />
                  </p>
                </div>

                {/* G. Assumptions & Limitations */}
                <div>
                  <h2 className="text-sm font-bold text-[#0B1F3A]">
                    G. Assumptions &amp; Limitations
                  </h2>
                  <ul className="mt-1.5 list-disc pl-5 space-y-1 text-sm text-slate-700">
                    {subtopic.assumptionsAndLimitations.map((a, i) => (
                      <li key={i}>
                        <MathText text={a} />
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* E. Mathematical Formulation */}
            <div className="pt-4 border-t border-slate-100 space-y-3">
              <h2 className="text-sm font-bold text-[#0B1F3A]">E. Mathematical Formulation</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {subtopic.mathematicalFormulation.map((eq) => (
                  <div key={eq.label} className="rounded-lg border border-slate-200 p-3.5 bg-slate-50/50">
                    <p className="text-xs font-semibold text-cyan-800">{eq.label}</p>
                    <MathFormula latex={eq.latex} display />
                    <p className="text-xs text-slate-600">{eq.notes}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* H & I: Units/Dimensions Table + Technical Schematic */}
            <div className="pt-4 border-t border-slate-100 grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-2">
                <h2 className="text-sm font-bold text-[#0B1F3A]">
                  H. SI Units &amp; Dimensional Formulae
                </h2>
                <div className="overflow-x-auto rounded-lg border border-slate-200">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                      <tr>
                        <th className="py-2.5 px-3 font-semibold">Physical Quantity</th>
                        <th className="py-2.5 px-3 font-semibold">SI Unit</th>
                        <th className="py-2.5 px-3 font-semibold">Dimensions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {subtopic.unitsAndDimensions.map((u) => (
                        <tr key={u.quantity}>
                          <td className="py-2 px-3 font-medium text-slate-800">{u.quantity}</td>
                          <td className="py-2 px-3 font-mono text-slate-700">{u.siUnit}</td>
                          <td className="py-2 px-3 font-mono text-cyan-800">{u.dimensions}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="space-y-2">
                <h2 className="text-sm font-bold text-[#0B1F3A]">I. Diagram &amp; Illustration</h2>
                <PhysicsDiagramSvg
                  svgType={subtopic.diagramSpec.svgType}
                  title={subtopic.diagramSpec.title}
                  caption={subtopic.diagramSpec.caption}
                />
              </div>
            </div>

            {/* J, K, L: Applications, Exam Concepts, Common Mistakes */}
            <div className="pt-4 border-t border-slate-100 grid grid-cols-1 lg:grid-cols-3 gap-5">
              <div className="space-y-2">
                <h2 className="text-sm font-bold text-[#0B1F3A]">J. Real-Life Applications</h2>
                <ul className="list-disc pl-5 space-y-1.5 text-sm text-slate-700">
                  {subtopic.realLifeApplications.map((app, i) => (
                    <li key={i}>{app}</li>
                  ))}
                </ul>
              </div>
              <div className="space-y-2">
                <h2 className="text-sm font-bold text-[#0B1F3A]">K. Important JEE Concepts</h2>
                <ul className="list-disc pl-5 space-y-1.5 text-sm text-slate-700">
                  {subtopic.importantExamConcepts.map((c, i) => (
                    <li key={i}>
                      <MathText text={c} />
                    </li>
                  ))}
                </ul>
              </div>
              <div className="space-y-2">
                <h2 className="text-sm font-bold text-[#0B1F3A]">L. Common Misconceptions</h2>
                <div className="space-y-2">
                  {subtopic.commonMistakes.map((m, i) => (
                    <div key={i} className="rounded-lg bg-amber-50/70 border border-amber-200 p-3 text-xs space-y-1">
                      <p className="font-semibold text-amber-900">Trap: {m.misconception}</p>
                      <p className="text-slate-700">Fix: <MathText text={m.correction} /></p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* M, O, P, Q */}
            <div className="pt-4 border-t border-slate-100 grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h2 className="text-sm font-bold text-[#0B1F3A]">M. Conceptual Questions</h2>
                {subtopic.conceptualQuestions.map((cq, i) => (
                  <details key={i} className="rounded-lg border border-slate-200 p-3 bg-slate-50/60">
                    <summary className="cursor-pointer text-sm font-semibold text-[#0B1F3A]">
                      {cq.question}
                    </summary>
                    <p className="mt-2 text-sm text-slate-700 leading-relaxed">
                      <MathText text={cq.answer} />
                    </p>
                  </details>
                ))}
              </div>
              <div className="space-y-3">
                <h2 className="text-sm font-bold text-[#0B1F3A]">
                  O–Q. Advanced Techniques, Summary &amp; Revision Notes
                </h2>
                <div className="rounded-lg border border-slate-200 p-4 bg-slate-50/60 space-y-2 text-sm text-slate-700">
                  <p className="text-xs font-bold text-cyan-800">Advanced Strategy</p>
                  {subtopic.advancedTechniques.map((t, i) => (
                    <p key={i}>• <MathText text={t} /></p>
                  ))}
                  <p className="pt-2 text-xs font-bold text-[#0B1F3A]">Chapter Summary &amp; Revision</p>
                  {[...subtopic.summaryPoints, ...subtopic.revisionNotes].map((r, i) => (
                    <p key={i}>• <MathText text={r} /></p>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* F. Mathematical Derivation Engine */}
          <section className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
            <div>
              <h2 className="text-lg font-bold text-[#0B1F3A]">
                F. Mathematical Derivation Engine
              </h2>
              <p className="text-xs text-slate-500">
                Step-by-step formal derivations with physical assumptions, symbol tables, and worked verification.
              </p>
            </div>
            <div className="space-y-3">
              {chapter.derivations.map((drv) => {
                const isOpen = expandedDerivationIds.includes(drv.id);
                return (
                  <div key={drv.id} className="rounded-xl border border-slate-200 overflow-hidden">
                    <button
                      type="button"
                      onClick={() => toggleDerivation(drv.id)}
                      className="w-full px-4 py-3.5 bg-slate-50 hover:bg-slate-100 flex items-center justify-between gap-3 text-left"
                    >
                      <div>
                        <p className="text-sm font-bold text-[#0B1F3A]">{drv.title}</p>
                        <p className="text-xs text-slate-500">{drv.physicalPrinciple}</p>
                      </div>
                      {isOpen ? (
                        <ChevronUp className="w-4 h-4 text-slate-600 shrink-0" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-slate-600 shrink-0" />
                      )}
                    </button>

                    {isOpen && (
                      <div className="p-5 space-y-4 bg-white">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                          <div>
                            <p className="font-semibold text-slate-700">Initial Assumptions</p>
                            <ul className="mt-1 list-disc pl-4 text-slate-600 space-y-0.5">
                              {drv.assumptions.map((a, i) => (
                                <li key={i}>{a}</li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <p className="font-semibold text-slate-700">Symbol Definitions</p>
                            <ul className="mt-1 space-y-0.5 text-slate-600">
                              {drv.symbols.map((sym) => (
                                <li key={sym.symbol}>
                                  <span className="font-mono font-semibold text-[#0B1F3A]">
                                    {sym.symbol}
                                  </span>{' '}
                                  — {sym.meaning} ({sym.unit})
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>

                        <div className="space-y-2.5">
                          <p className="text-xs font-bold text-[#0B1F3A]">Step-by-Step Transformation</p>
                          {drv.steps.map((st) => (
                            <div
                              key={st.stepNumber}
                              className="rounded-lg border border-slate-200 p-3 bg-slate-50/40"
                            >
                              <p className="text-xs font-semibold text-cyan-800">
                                Step {st.stepNumber}: {st.transformationNote}
                              </p>
                              <MathFormula latex={st.equationLatex} display />
                            </div>
                          ))}
                        </div>

                        <div className="rounded-lg bg-[#0B1F3A] text-white p-4 space-y-1">
                          <p className="text-xs text-cyan-300 font-semibold">Final Derived Result</p>
                          <div className="overflow-x-auto py-1">
                            <MathFormula latex={drv.finalResultLatex} display className="!bg-white/10 !border-white/15 !text-white" />
                          </div>
                          <p className="text-xs text-slate-200">{drv.physicalSignificance}</p>
                        </div>

                        <div className="rounded-lg border border-cyan-200 bg-cyan-50/40 p-4 text-sm space-y-1">
                          <p className="text-xs font-bold text-cyan-900">Worked Example</p>
                          <p className="font-medium text-slate-800">{drv.workedExample.statement}</p>
                          <p className="text-slate-700">
                            <MathText text={drv.workedExample.solution} />
                          </p>
                          <p className="font-semibold text-[#0B1F3A]">
                            Answer: {drv.workedExample.answer}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </section>

          {/* N. Solved Problem Library */}
          <section className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
            <div>
              <h2 className="text-lg font-bold text-[#0B1F3A]">N. Solved Problem Library</h2>
              <p className="text-xs text-slate-500">
                Original solved numericals verified independently across Foundation, JEE Main, and JEE Advanced levels.
              </p>
            </div>
            <div className="space-y-4">
              {chapter.solvedProblems.map((prob, idx) => (
                <article key={prob.id} className="rounded-xl border border-slate-200 p-5 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
                    <span>
                      Problem {idx + 1} · {prob.category} · {prob.physicsConcept}
                    </span>
                    <span className="font-semibold text-cyan-800 uppercase">{prob.level.replace('_', ' ')}</span>
                  </div>
                  <p className="text-sm sm:text-base font-medium text-[#0B1F3A] leading-relaxed">
                    <MathText text={prob.statement} />
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs bg-slate-50 p-3 rounded-lg border border-slate-200/70">
                    <div>
                      <span className="font-semibold text-slate-700">Given Data: </span>
                      <span className="text-slate-600">{prob.givenData.join(' · ')}</span>
                    </div>
                    <div>
                      <span className="font-semibold text-slate-700">Required: </span>
                      <span className="text-slate-600">{prob.requiredQuantity}</span>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    {prob.applicableEquationsLatex.map((eq, i) => (
                      <MathFormula key={i} latex={eq} display />
                    ))}
                  </div>
                  <ol className="list-decimal pl-5 space-y-1 text-sm text-slate-700">
                    {prob.steps.map((step, i) => (
                      <li key={i}>
                        <MathText text={step} />
                      </li>
                    ))}
                  </ol>
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 text-sm">
                    <span className="font-bold text-emerald-700">Final Answer: {prob.finalAnswer}</span>
                    <span className="text-xs text-slate-600">Strategy: {prob.strategyExplanation}</span>
                  </div>
                </article>
              ))}
            </div>
          </section>

          {/* Teacher-Published Supplements */}
          {publishedSupplements.length > 0 && (
            <section className="rounded-xl border border-cyan-200 bg-cyan-50/40 p-5 space-y-3">
              <p className="text-xs font-bold text-cyan-900">
                Approved Academic Director Enrichment Supplements
              </p>
              {publishedSupplements.map((sup) => (
                <div key={sup.contentId} className="rounded-lg bg-white border border-slate-200 p-4 space-y-1">
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span>{sup.sourceLabel}</span>
                    <span>Status: Published</span>
                  </div>
                  <h3 className="text-sm font-bold text-[#0B1F3A]">{sup.title}</h3>
                  <p className="text-sm text-slate-700 leading-relaxed">
                    <MathText text={sup.summary} />
                  </p>
                </div>
              ))}
            </section>
          )}
        </div>
      )}
    </div>
  );
}
