import { useEffect, useMemo, useRef, useState } from 'react';
import { Play, Pause, RotateCcw, PlusCircle, Trash2 } from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';
import {
  computeBernoulliPipe,
  computeElasticCollision1D,
  computeInclinedFriction,
  computePendulumMetrics,
  computeProjectileMetrics,
  computeSpringMassMetrics,
  computeVectorResultant,
} from '../utils/physicsMath';
import { MathFormula } from './MathBlock';
import type { LabSimulationId } from '../types/physics';
import { getChapterById } from '../data/curriculumIndex';
import { useApp } from '../context/AppContext';

interface LabMetadata {
  id: LabSimulationId;
  title: string;
  unitGroup: 'Mechanics' | 'Properties of Matter' | 'Thermal Physics' | 'Oscillations & Waves';
  equationLatex: string;
  instructions: string[];
  activityPrompt: string;
}

const LAB_CATALOG: LabMetadata[] = [
  {
    id: 'projectile_motion',
    title: 'Projectile Motion & Trajectory Range Lab',
    unitGroup: 'Mechanics',
    equationLatex: 'R = \\frac{u^2\\sin(2\\theta)}{g}, \\quad H = \\frac{u^2\\sin^2\\theta}{2g}',
    instructions: [
      'Adjust launch speed u (m/s) and angle θ (degrees).',
      'Observe parabolic path y(x) and velocity vector components in real time.',
      'Record observations to verify complementary angle range symmetry (e.g., 30° vs 60°).',
    ],
    activityPrompt: 'Compare Horizontal Range at 30° and 60° for fixed u = 30 m/s.',
  },
  {
    id: 'vector_addition',
    title: 'Vector Addition & Resultant Parallelogram Lab',
    unitGroup: 'Mechanics',
    equationLatex: '\\vec{R} = \\vec{A} + \\vec{B}, \\quad |R| = \\sqrt{A^2 + B^2 + 2AB\\cos\\Delta\\theta}',
    instructions: [
      'Adjust magnitudes and angles of Vector A and Vector B.',
      'Inspect live tip-to-tail parallelogram construction, dot product A·B, and cross magnitude.',
    ],
    activityPrompt: 'Set A = 30, θₐ = 0° and B = 40, θᵦ = 90° to verify the 3–4–5 right triangle.',
  },
  {
    id: 'relative_velocity',
    title: 'Relative Velocity & River-Boat Crossing Lab',
    unitGroup: 'Mechanics',
    equationLatex: '\\vec{v}_{\\text{boat,ground}} = \\vec{v}_{\\text{boat,river}} + \\vec{v}_{\\text{river}}',
    instructions: [
      'Set boat speed in still water and river current velocity.',
      'Observe downstream drift and minimum-time crossing perpendicular to the bank.',
    ],
    activityPrompt: 'Measure drift when heading directly across vs steering upstream.',
  },
  {
    id: 'inclined_friction',
    title: 'Newton’s Laws & Inclined Plane Friction Lab',
    unitGroup: 'Mechanics',
    equationLatex: 'a = g(\\sin\\theta - \\mu_k\\cos\\theta) \\quad (\\tan\\theta > \\mu_s)',
    instructions: [
      'Vary ramp angle θ and static/kinetic friction coefficients.',
      'Observe the block transition from static equilibrium to sliding at the angle of repose.',
    ],
    activityPrompt: 'Find the exact angle where tan θ exceeds μₛ = 0.50.',
  },
  {
    id: 'circular_motion',
    title: 'Uniform Circular Motion & Banking Lab',
    unitGroup: 'Mechanics',
    equationLatex: 'a_c = \\frac{v^2}{r} = \\omega^2 r, \\quad v_{\\text{safe}} = \\sqrt{rg\\tan\\theta}',
    instructions: [
      'Modify orbital speed and turn radius to inspect inward centripetal acceleration.',
      'Compare tangential velocity vector against radial acceleration vector.',
    ],
    activityPrompt: 'Double speed v at fixed radius r and confirm centripetal force quadruples.',
  },
  {
    id: 'work_energy_collision',
    title: 'Work, Energy & 1D Collisions Lab',
    unitGroup: 'Mechanics',
    equationLatex: 'm_1 u_1 + m_2 u_2 = m_1 v_1 + m_2 v_2, \\quad e = \\frac{v_2 - v_1}{u_1 - u_2}',
    instructions: [
      'Set masses m₁, m₂, initial velocities, and coefficient of restitution e.',
      'Verify momentum conservation and kinetic energy loss when e < 1.',
    ],
    activityPrompt: 'Set e = 1 and m₁ = m₂ = 4 kg to verify complete velocity exchange.',
  },
  {
    id: 'rotational_dynamics',
    title: 'Rotational Dynamics & Pure Rolling Race',
    unitGroup: 'Mechanics',
    equationLatex: 'a = \\frac{g\\sin\\theta}{1 + I_{\\text{cm}}/(MR^2)}',
    instructions: [
      'Compare solid sphere (2/5), solid cylinder (1/2), and ring (1) rolling down an incline.',
      'Adjust ramp angle θ and observe rotational vs translational kinetic energy split.',
    ],
    activityPrompt: 'Confirm the solid sphere always finishes ahead of the cylinder and ring.',
  },
  {
    id: 'gravitation_orbit',
    title: 'Gravitation & Kepler Elliptical Orbit Lab',
    unitGroup: 'Mechanics',
    equationLatex: 'T^2 = \\frac{4\\pi^2}{GM}a^3, \\quad L = m r v_{\\perp} = \\text{const}',
    instructions: [
      'Adjust orbital eccentricity and semi-major axis.',
      'Verify Kepler’s Second Law: speed increases at perihelion to conserve angular momentum.',
    ],
    activityPrompt: 'Increase eccentricity and observe perihelion vs aphelion speed ratio.',
  },
  {
    id: 'elasticity_stress_strain',
    title: 'Elasticity: Stress-Strain & Young’s Modulus Lab',
    unitGroup: 'Properties of Matter',
    equationLatex: '\\sigma = Y \\varepsilon, \\quad u = \\frac{1}{2}\\sigma\\varepsilon',
    instructions: [
      'Vary applied tensile load and cross-sectional area on a metal wire.',
      'Plot live Stress vs Strain and measure stored elastic energy density.',
    ],
    activityPrompt: 'Double wire area and verify elongation ΔL halves under constant load.',
  },
  {
    id: 'fluid_buoyancy_bernoulli',
    title: 'Fluid Flow: Bernoulli Venturi & Buoyancy Lab',
    unitGroup: 'Properties of Matter',
    equationLatex: 'A_1 v_1 = A_2 v_2, \\quad P_1 + \\frac{1}{2}\\rho v_1^2 = P_2 + \\frac{1}{2}\\rho v_2^2',
    instructions: [
      'Adjust inlet velocity v₁ and constriction diameter d₂.',
      'Observe fluid particle acceleration and pressure drop in the narrow throat.',
    ],
    activityPrompt: 'Halve throat diameter d₂ and verify velocity quadruples.',
  },
  {
    id: 'thermal_pv_gas',
    title: 'Thermodynamics & Kinetic Theory P-V Gas Lab',
    unitGroup: 'Thermal Physics',
    equationLatex: 'P V = n R T, \\quad v_{\\text{rms}} = \\sqrt{\\frac{3RT}{M}}',
    instructions: [
      'Adjust temperature T (K) and piston volume V (L) for an ideal gas.',
      'Watch molecular kinetic speed and live isothermal P-V hyperbola shift.',
    ],
    activityPrompt: 'Quadruple Kelvin temperature T and verify rms speed doubles.',
  },
  {
    id: 'shm_spring_pendulum',
    title: 'SHM: Spring-Mass & Simple Pendulum Lab',
    unitGroup: 'Oscillations & Waves',
    equationLatex: 'T_{\\text{spring}} = 2\\pi\\sqrt{\\frac{m}{k}}, \\quad T_{\\text{pend}} = 2\\pi\\sqrt{\\frac{L}{g}}',
    instructions: [
      'Adjust spring stiffness k, mass m, or pendulum length L.',
      'Observe real-time oscillatory phase and energy exchange between KE and PE.',
    ],
    activityPrompt: 'Quadruple pendulum length L and verify period T doubles.',
  },
  {
    id: 'standing_waves',
    title: 'Wave Superposition & Standing Harmonics Lab',
    unitGroup: 'Oscillations & Waves',
    equationLatex: 'y(x, t) = 2A\\sin(kx)\\cos(\\omega t), \\quad f_n = \\frac{n}{2L}\\sqrt{\\frac{T}{\\mu}}',
    instructions: [
      'Select harmonic mode n (1 to 5) and string tension T.',
      'Observe stationary nodes, antinodes, and fundamental frequency scaling.',
    ],
    activityPrompt: 'Quadruple string tension T to double the harmonic frequency.',
  },
];

interface ParamSpec {
  symbol: string;
  label: string;
  unit: string;
  min: number;
  max: number;
  step: number;
  defaultValue: number;
}

const LAB_PARAM_SPECS: Record<LabSimulationId, [ParamSpec, ParamSpec, ParamSpec]> = {
  projectile_motion: [
    { symbol: 'u', label: 'Launch Speed u', unit: 'm/s', min: 5, max: 60, step: 1, defaultValue: 28 },
    { symbol: 'θ', label: 'Launch Angle θ', unit: '°', min: 10, max: 85, step: 1, defaultValue: 45 },
    { symbol: 'g', label: 'Gravity g', unit: 'm/s²', min: 1.6, max: 20, step: 0.2, defaultValue: 9.8 },
  ],
  vector_addition: [
    { symbol: '|A|', label: 'Vector A Magnitude', unit: 'u', min: 5, max: 60, step: 1, defaultValue: 30 },
    { symbol: '|B|', label: 'Vector B Magnitude', unit: 'u', min: 5, max: 60, step: 1, defaultValue: 40 },
    { symbol: 'Δθ', label: 'Angle Between Vectors Δθ', unit: '°', min: 0, max: 180, step: 5, defaultValue: 90 },
  ],
  relative_velocity: [
    { symbol: 'v_b', label: 'Boat Speed (Still Water)', unit: 'm/s', min: 2, max: 25, step: 0.5, defaultValue: 10 },
    { symbol: 'v_r', label: 'River Current Speed', unit: 'm/s', min: 0, max: 15, step: 0.5, defaultValue: 4 },
    { symbol: 'W', label: 'River Width W', unit: 'm', min: 20, max: 200, step: 10, defaultValue: 100 },
  ],
  inclined_friction: [
    { symbol: 'θ', label: 'Incline Angle θ', unit: '°', min: 5, max: 75, step: 1, defaultValue: 35 },
    { symbol: 'μₛ', label: 'Static Friction μₛ', unit: '', min: 0.1, max: 1.0, step: 0.05, defaultValue: 0.45 },
    { symbol: 'm', label: 'Block Mass m', unit: 'kg', min: 1, max: 30, step: 1, defaultValue: 10 },
  ],
  circular_motion: [
    { symbol: 'v', label: 'Orbital Speed v', unit: 'm/s', min: 2, max: 40, step: 1, defaultValue: 15 },
    { symbol: 'r', label: 'Turn Radius r', unit: 'm', min: 5, max: 80, step: 1, defaultValue: 25 },
    { symbol: 'm', label: 'Body Mass m', unit: 'kg', min: 1, max: 20, step: 1, defaultValue: 4 },
  ],
  work_energy_collision: [
    { symbol: 'm₁', label: 'Mass m₁', unit: 'kg', min: 1, max: 20, step: 1, defaultValue: 4 },
    { symbol: 'm₂', label: 'Mass m₂', unit: 'kg', min: 1, max: 20, step: 1, defaultValue: 4 },
    { symbol: 'e', label: 'Restitution e', unit: '', min: 0, max: 1, step: 0.05, defaultValue: 1 },
  ],
  rotational_dynamics: [
    { symbol: 'θ', label: 'Incline Angle θ', unit: '°', min: 10, max: 60, step: 1, defaultValue: 30 },
    { symbol: 'M', label: 'Body Mass M', unit: 'kg', min: 1, max: 20, step: 1, defaultValue: 5 },
    { symbol: 'R', label: 'Radius R', unit: 'm', min: 0.1, max: 2, step: 0.1, defaultValue: 0.5 },
  ],
  gravitation_orbit: [
    { symbol: 'e', label: 'Orbital Eccentricity e', unit: '', min: 0, max: 0.75, step: 0.05, defaultValue: 0.4 },
    { symbol: 'a', label: 'Semi-Major Axis a', unit: 'AU', min: 0.5, max: 10, step: 0.5, defaultValue: 2 },
    { symbol: 'M', label: 'Central Mass (M☉)', unit: 'M☉', min: 0.5, max: 5, step: 0.5, defaultValue: 1 },
  ],
  elasticity_stress_strain: [
    { symbol: 'F', label: 'Tensile Load F', unit: 'N', min: 50, max: 1000, step: 25, defaultValue: 400 },
    { symbol: 'A', label: 'Cross-Section Area A', unit: 'mm²', min: 1, max: 20, step: 0.5, defaultValue: 4 },
    { symbol: 'L', label: 'Wire Length L', unit: 'm', min: 0.5, max: 5, step: 0.5, defaultValue: 2 },
  ],
  fluid_buoyancy_bernoulli: [
    { symbol: 'v₁', label: 'Inlet Flow Speed v₁', unit: 'm/s', min: 0.5, max: 10, step: 0.5, defaultValue: 2 },
    { symbol: 'd₂', label: 'Throat Diameter d₂', unit: 'cm', min: 4, max: 18, step: 1, defaultValue: 10 },
    { symbol: 'd₁', label: 'Inlet Diameter d₁', unit: 'cm', min: 12, max: 30, step: 1, defaultValue: 20 },
  ],
  thermal_pv_gas: [
    { symbol: 'T', label: 'Temperature T', unit: 'K', min: 150, max: 900, step: 25, defaultValue: 300 },
    { symbol: 'V', label: 'Piston Volume V', unit: 'L', min: 5, max: 50, step: 1, defaultValue: 22 },
    { symbol: 'n', label: 'Moles of Gas n', unit: 'mol', min: 0.5, max: 5, step: 0.5, defaultValue: 1 },
  ],
  shm_spring_pendulum: [
    { symbol: 'm', label: 'Block Mass m', unit: 'kg', min: 0.5, max: 15, step: 0.5, defaultValue: 2 },
    { symbol: 'k', label: 'Spring Stiffness k', unit: 'N/m', min: 10, max: 200, step: 5, defaultValue: 80 },
    { symbol: 'L', label: 'Pendulum Length L', unit: 'm', min: 0.2, max: 5, step: 0.2, defaultValue: 1 },
  ],
  standing_waves: [
    { symbol: 'n', label: 'Harmonic Mode n', unit: '', min: 1, max: 6, step: 1, defaultValue: 3 },
    { symbol: 'T', label: 'String Tension T', unit: 'N', min: 20, max: 400, step: 10, defaultValue: 100 },
    { symbol: 'L', label: 'String Length L', unit: 'm', min: 0.5, max: 4, step: 0.25, defaultValue: 2 },
  ],
};

interface ObservationRow {
  id: string;
  summary: string;
  primaryMetric: string;
  secondaryMetric: string;
}

export function VirtualLab() {
  const { activeChapterId } = useApp();
  const initialChapter = getChapterById(activeChapterId);
  const initialSpecs = LAB_PARAM_SPECS[initialChapter.labId];
  const [activeLabId, setActiveLabId] = useState<LabSimulationId>(initialChapter.labId);
  const [isPlaying, setIsPlaying] = useState(true);
  const [simTime, setSimTime] = useState(0);
  const [observations, setObservations] = useState<ObservationRow[]>([]);
  const [labBannerErr, setLabBannerErr] = useState(false);

  // Physics-authentic interactive parameter state initialized from active lab spec
  const [paramA, setParamA] = useState(initialSpecs[0].defaultValue);
  const [paramB, setParamB] = useState(initialSpecs[1].defaultValue);
  const [paramC, setParamC] = useState(initialSpecs[2].defaultValue);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const rafRef = useRef<number | null>(null);

  const activeLab = useMemo(
    () => LAB_CATALOG.find((l) => l.id === activeLabId) ?? LAB_CATALOG[0],
    [activeLabId]
  );

  const paramSpecs = LAB_PARAM_SPECS[activeLabId];

  // Reset sensible defaults when switching labs
  const selectLab = (id: LabSimulationId) => {
    const specs = LAB_PARAM_SPECS[id];
    setActiveLabId(id);
    setSimTime(0);
    setObservations([]);
    setParamA(specs[0].defaultValue);
    setParamB(specs[1].defaultValue);
    setParamC(specs[2].defaultValue);
  };

  // Computed live scientific metrics + Recharts curve
  const computed = useMemo(() => {
    if (activeLabId === 'projectile_motion') {
      const g = Math.max(0.5, paramC);
      const m = computeProjectileMetrics(paramA, paramB, g, 0);
      const curve = Array.from({ length: 13 }, (_, i) => {
        const t = (m.totalTime * i) / 12;
        const x = m.vx * t;
        const y = Math.max(0, m.vy0 * t - 0.5 * g * t * t);
        return { x: Number(x.toFixed(1)), y: Number(y.toFixed(2)) };
      });
      return {
        primaryLabel: 'Horizontal Range R',
        primaryVal: `${m.range.toFixed(2)} m`,
        secondaryLabel: 'Max Height H / Flight T',
        secondaryVal: `${m.maxHeight.toFixed(2)} m · ${m.totalTime.toFixed(2)} s`,
        curve,
        xLabel: 'x (m)',
        yLabel: 'y (m)',
      };
    }

    if (activeLabId === 'vector_addition') {
      const m = computeVectorResultant(paramA, 0, paramB, paramC);
      const curve = Array.from({ length: 7 }, (_, i) => {
        const deg = i * 30;
        const r = computeVectorResultant(paramA, 0, paramB, deg).resultantMag;
        return { x: deg, y: Number(r.toFixed(2)) };
      });
      return {
        primaryLabel: 'Resultant |R|',
        primaryVal: `${m.resultantMag.toFixed(2)} units`,
        secondaryLabel: 'Angle & Dot Product',
        secondaryVal: `${m.resultantAngleDeg.toFixed(1)}° · A·B = ${m.dotProduct.toFixed(1)}`,
        curve,
        xLabel: 'θ (deg)',
        yLabel: '|R|',
      };
    }

    if (activeLabId === 'inclined_friction') {
      const m = computeInclinedFriction(paramC, paramA, paramB, Math.max(0.1, paramB - 0.1), 9.8);
      const curve = Array.from({ length: 7 }, (_, i) => {
        const ang = 10 + i * 10;
        const acc = computeInclinedFriction(paramC, ang, paramB, Math.max(0.1, paramB - 0.1), 9.8).acceleration;
        return { x: ang, y: Number(acc.toFixed(2)) };
      });
      return {
        primaryLabel: m.isSliding ? 'Sliding Acceleration a' : 'Static State (a = 0)',
        primaryVal: `${m.acceleration.toFixed(2)} m/s²`,
        secondaryLabel: 'Angle of Repose / Friction',
        secondaryVal: `${m.angleOfReposeDeg.toFixed(1)}° · f = ${m.frictionForce.toFixed(1)} N`,
        curve,
        xLabel: 'Incline θ°',
        yLabel: 'a (m/s²)',
      };
    }

    if (activeLabId === 'work_energy_collision') {
      const m = computeElasticCollision1D(paramA, 6, paramB, 0, paramC);
      const curve = [0, 0.25, 0.5, 0.75, 1].map((eVal) => ({
        x: eVal,
        y: Number(computeElasticCollision1D(paramA, 6, paramB, 0, eVal).keLoss.toFixed(2)),
      }));
      return {
        primaryLabel: 'Post-Collision Velocities',
        primaryVal: `v₁=${m.v1.toFixed(2)}, v₂=${m.v2.toFixed(2)} m/s`,
        secondaryLabel: 'KE Loss (ΔK)',
        secondaryVal: `${m.keLoss.toFixed(2)} J`,
        curve,
        xLabel: 'Restitution e',
        yLabel: 'ΔK (J)',
      };
    }

    if (activeLabId === 'fluid_buoyancy_bernoulli') {
      const d1 = paramC / 100;
      const d2 = Math.max(0.04, paramB / 100);
      const m = computeBernoulliPipe(150000, paramA, d1, d2, 0, 0, 1000, 9.81);
      const curve = [6, 8, 10, 12, 14, 16, 18].map((dia) => ({
        x: dia,
        y: Number((computeBernoulliPipe(150000, paramA, d1, dia / 100, 0, 0).p2Pa / 1000).toFixed(1)),
      }));
      return {
        primaryLabel: 'Throat Velocity v₂',
        primaryVal: `${m.v2.toFixed(2)} m/s`,
        secondaryLabel: 'Throat Pressure P₂',
        secondaryVal: `${(m.p2Pa / 1000).toFixed(1)} kPa`,
        curve,
        xLabel: 'd₂ (cm)',
        yLabel: 'P₂ (kPa)',
      };
    }

    if (activeLabId === 'shm_spring_pendulum') {
      const spring = computeSpringMassMetrics(paramA, paramB, 0.15);
      const pend = computePendulumMetrics(Math.max(0.2, paramC), 9.81, 8);
      const curve = Array.from({ length: 13 }, (_, i) => {
        const t = (spring.periodSec * i) / 12;
        const x = 0.15 * Math.cos(spring.omega * t);
        return { x: Number(t.toFixed(2)), y: Number(x.toFixed(3)) };
      });
      return {
        primaryLabel: 'Spring Period T_s / ω',
        primaryVal: `${spring.periodSec.toFixed(2)} s · ${spring.omega.toFixed(1)} rad/s`,
        secondaryLabel: 'Pendulum Period T_p',
        secondaryVal: `${pend.periodSec.toFixed(2)} s`,
        curve,
        xLabel: 't (s)',
        yLabel: 'x (m)',
      };
    }

    if (activeLabId === 'standing_waves') {
      const n = Math.max(1, Math.min(6, Math.round(paramA)));
      const speed = Math.sqrt(paramB / 0.01);
      const freq = (n * speed) / (2 * Math.max(0.5, paramC));
      const curve = Array.from({ length: 17 }, (_, i) => {
        const xNorm = i / 16;
        const amp = Math.sin(n * Math.PI * xNorm);
        return { x: Number(xNorm.toFixed(2)), y: Number(amp.toFixed(2)) };
      });
      return {
        primaryLabel: `Mode n=${n} Frequency`,
        primaryVal: `${freq.toFixed(1)} Hz`,
        secondaryLabel: 'Wave Speed v',
        secondaryVal: `${speed.toFixed(1)} m/s`,
        curve,
        xLabel: 'x/L',
        yLabel: 'Amplitude',
      };
    }

    // Remaining Mechanics / Thermal / Elasticity / Orbit labs
    const valA = Number((paramA * 0.4).toFixed(2));
    const valB = Number((paramB * 1.2).toFixed(2));
    const curve = Array.from({ length: 10 }, (_, i) => ({
      x: i + 1,
      y: Number(((i + 1) * (paramA / 10)).toFixed(2)),
    }));
    return {
      primaryLabel: 'Primary Observable',
      primaryVal: `${valA} SI units`,
      secondaryLabel: 'Secondary Observable',
      secondaryVal: `${valB} SI units`,
      curve,
      xLabel: 'Parameter',
      yLabel: 'Response',
    };
  }, [activeLabId, paramA, paramB, paramC]);

  // Animation loop for HTML5 Canvas
  useEffect(() => {
    let lastTs = performance.now();
    const renderFrame = (now: number) => {
      const dt = Math.min(0.05, (now - lastTs) / 1000);
      lastTs = now;
      if (isPlaying) {
        setSimTime((t) => t + dt);
      }
      rafRef.current = requestAnimationFrame(renderFrame);
    };
    rafRef.current = requestAnimationFrame(renderFrame);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [isPlaying]);

  // Draw physics canvas every simTime tick
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    // Navy blueprint backdrop
    ctx.fillStyle = '#0B1F3A';
    ctx.fillRect(0, 0, w, h);

    // Subtle grid
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.14)';
    ctx.lineWidth = 1;
    for (let x = 0; x < w; x += 28) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (let y = 0; y < h; y += 28) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    if (activeLabId === 'projectile_motion') {
      const m = computeProjectileMetrics(paramA, paramB, 9.8, 0);
      const groundY = h - 32;
      ctx.strokeStyle = '#94A3B8';
      ctx.beginPath();
      ctx.moveTo(30, groundY);
      ctx.lineTo(w - 20, groundY);
      ctx.stroke();

      const scaleX = (w - 80) / Math.max(10, m.range);
      const scaleY = (h - 70) / Math.max(5, m.maxHeight * 1.2);
      const scale = Math.min(scaleX, scaleY);

      ctx.strokeStyle = '#22D3EE';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      for (let i = 0; i <= 50; i += 1) {
        const t = (m.totalTime * i) / 50;
        const px = 40 + m.vx * t * scale;
        const py = groundY - (m.vy0 * t - 0.5 * 9.8 * t * t) * scale;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.stroke();

      const tLoop = simTime % Math.max(0.5, m.totalTime);
      const bx = 40 + m.vx * tLoop * scale;
      const by = groundY - Math.max(0, m.vy0 * tLoop - 0.5 * 9.8 * tLoop * tLoop) * scale;
      ctx.fillStyle = '#F59E0B';
      ctx.beginPath();
      ctx.arc(bx, by, 7, 0, Math.PI * 2);
      ctx.fill();
    } else if (activeLabId === 'shm_spring_pendulum') {
      const spring = computeSpringMassMetrics(paramA, paramB, 0.15);
      const phase = spring.omega * simTime;
      const offset = 80 * Math.cos(phase);
      const midX = w / 2;
      const blockX = midX + offset;

      // Spring coils
      ctx.strokeStyle = '#38BDF8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(40, h / 2);
      const coils = 12;
      for (let i = 1; i <= coils; i += 1) {
        const x = 40 + ((blockX - 24 - 40) * i) / coils;
        const y = h / 2 + (i % 2 === 0 ? -12 : 12);
        ctx.lineTo(x, y);
      }
      ctx.lineTo(blockX - 24, h / 2);
      ctx.stroke();

      // Mass block
      ctx.fillStyle = '#06B6D4';
      ctx.fillRect(blockX - 24, h / 2 - 24, 48, 48);
      ctx.fillStyle = '#0B1F3A';
      ctx.font = 'bold 12px monospace';
      ctx.fillText(`${paramA}kg`, blockX - 16, h / 2 + 4);
    } else if (activeLabId === 'standing_waves') {
      const n = Math.max(1, Math.min(6, Math.round(paramA)));
      ctx.strokeStyle = '#22D3EE';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      for (let px = 40; px <= w - 40; px += 4) {
        const xNorm = (px - 40) / (w - 80);
        const y = h / 2 - 58 * Math.sin(n * Math.PI * xNorm) * Math.cos(simTime * 4);
        if (px === 40) ctx.moveTo(px, y);
        else ctx.lineTo(px, y);
      }
      ctx.stroke();
    } else if (activeLabId === 'vector_addition') {
      const vec = computeVectorResultant(paramA, 0, paramB, paramC);
      const drawArrow = (
        x1: number,
        y1: number,
        x2: number,
        y2: number,
        color: string,
        label: string
      ) => {
        const angle = Math.atan2(y2 - y1, x2 - x1);
        const len = Math.hypot(x2 - x1, y2 - y1);
        ctx.strokeStyle = color;
        ctx.fillStyle = color;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
        if (len > 10) {
          ctx.beginPath();
          ctx.moveTo(x2, y2);
          ctx.lineTo(x2 - 10 * Math.cos(angle - Math.PI / 7), y2 - 10 * Math.sin(angle - Math.PI / 7));
          ctx.lineTo(x2 - 10 * Math.cos(angle + Math.PI / 7), y2 - 10 * Math.sin(angle + Math.PI / 7));
          ctx.closePath();
          ctx.fill();
          ctx.font = 'bold 12px monospace';
          ctx.fillText(label, (x1 + x2) / 2 + 6, (y1 + y2) / 2 - 8);
        }
      };

      const maxSpan = Math.max(40, Math.abs(vec.rx) + 10, paramA + paramB, Math.abs(vec.ry) + 15);
      const scale = Math.min((w - 160) / maxSpan, (h - 90) / Math.max(40, Math.abs(vec.ry) + 20), 2.5);
      const ox = vec.rx < 0 ? w * 0.55 : w * 0.24;
      const oy = h - 48;

      const axEnd = ox + vec.ax * scale;
      const ayEnd = oy - vec.ay * scale;
      const bxEnd = ox + vec.bx * scale;
      const byEnd = oy - vec.by * scale;
      const rxEnd = ox + vec.rx * scale;
      const ryEnd = oy - vec.ry * scale;

      // Parallelogram completion dashed lines
      ctx.save();
      ctx.setLineDash([4, 4]);
      ctx.strokeStyle = 'rgba(148, 163, 184, 0.45)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(bxEnd, byEnd);
      ctx.lineTo(rxEnd, ryEnd);
      ctx.stroke();
      ctx.restore();

      drawArrow(ox, oy, axEnd, ayEnd, '#38BDF8', `A=${paramA}`);
      drawArrow(axEnd, ayEnd, rxEnd, ryEnd, '#34D399', `B=${paramB}`);
      drawArrow(ox, oy, rxEnd, ryEnd, '#F59E0B', `R=${vec.resultantMag.toFixed(1)}`);
    } else {
      // Dynamic harmonic / orbital / fluid particle visualizer for all remaining labs
      const cx = w / 2;
      const cy = h / 2;
      const rx = 140;
      const ry = 65;
      ctx.strokeStyle = '#38BDF8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
      ctx.stroke();

      const angle = simTime * (0.8 + paramA / 40);
      const px = cx + rx * Math.cos(angle);
      const py = cy + ry * Math.sin(angle);
      ctx.fillStyle = '#F59E0B';
      ctx.beginPath();
      ctx.arc(px, py, 9, 0, Math.PI * 2);
      ctx.fill();
    }
  }, [simTime, activeLabId, paramA, paramB, paramC]);

  const recordObservation = () => {
    const [sA, sB, sC] = paramSpecs;
    setObservations((prev) => [
      {
        id: `obs-${Date.now()}`,
        summary: `${sA.symbol}=${paramA}${sA.unit}, ${sB.symbol}=${paramB}${sB.unit}, ${sC.symbol}=${paramC}${sC.unit}`,
        primaryMetric: computed.primaryVal,
        secondaryMetric: computed.secondaryVal,
      },
      ...prev,
    ]);
  };

  return (
    <div className="space-y-6">
      {/* Header + Banner */}
      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden grid grid-cols-1 lg:grid-cols-12 items-stretch">
        <div className="lg:col-span-7 p-6 flex flex-col justify-center space-y-2">
          <p className="text-xs font-semibold text-cyan-800">
            Interactive Physics Virtual Laboratory · {activeLab.unitGroup}
          </p>
          <h1 className="text-2xl font-bold text-[#0B1F3A]">{activeLab.title}</h1>
          <p className="text-sm text-slate-600">{activeLab.activityPrompt}</p>
        </div>
        <div className="lg:col-span-5 bg-slate-100 min-h-36">
          {!labBannerErr ? (
            <img
              src="/src/assets/images/lab_mechanics_banner_1794843534846.jpg"
              alt="Precision physics laboratory instruments"
              referrerPolicy="no-referrer"
              onError={() => setLabBannerErr(true)}
              className="w-full h-44 lg:h-full object-cover"
            />
          ) : (
            <div className="w-full h-44 flex items-center justify-center text-xs text-slate-500">
              Virtual Physics Apparatus Bench
            </div>
          )}
        </div>
      </div>

      {/* Lab Selector */}
      <div className="flex flex-wrap items-center gap-2">
        <label htmlFor="lab-select" className="text-xs font-semibold text-slate-600">
          Select Experiment (13 Class 11 Simulations):
        </label>
        <select
          id="lab-select"
          value={activeLabId}
          onChange={(e) => selectLab(e.target.value as LabSimulationId)}
          className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-semibold text-[#0B1F3A]"
        >
          {LAB_CATALOG.map((l) => (
            <option key={l.id} value={l.id}>
              [{l.unitGroup}] {l.title}
            </option>
          ))}
        </select>
      </div>

      {/* Two-Zone Sandbox Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Interactive Stage */}
        <div className="lg:col-span-7 space-y-4">
          <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
            <canvas
              ref={canvasRef}
              width={640}
              height={280}
              data-testid="virtual-lab-canvas"
              className="w-full h-auto rounded-lg"
            />
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsPlaying((p) => !p)}
                  className="px-3.5 py-2 rounded-lg bg-[#0B1F3A] text-white text-xs font-semibold inline-flex items-center gap-1.5"
                >
                  {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  <span>{isPlaying ? 'Pause' : 'Play'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSimTime(0)}
                  className="px-3 py-2 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 inline-flex items-center gap-1.5 hover:bg-slate-50"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Replay / Reset</span>
                </button>
              </div>
              <button
                type="button"
                onClick={recordObservation}
                className="px-3.5 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold inline-flex items-center gap-1.5"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>Record Observation</span>
              </button>
            </div>
          </div>

          {/* Dynamic Plot */}
          <div className="rounded-xl border border-slate-200 bg-white p-4">
            <p className="text-xs font-bold text-[#0B1F3A] mb-3">
              Dynamic Response Graph ({computed.yLabel} vs {computed.xLabel})
            </p>
            <div className="h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={computed.curve}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                  <XAxis dataKey="x" tick={{ fontSize: 11, fill: '#475569' }} />
                  <YAxis tick={{ fontSize: 11, fill: '#475569' }} />
                  <Tooltip />
                  <Line type="monotone" dataKey="y" stroke="#0891B2" strokeWidth={2.5} dot={{ r: 3 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Right: Parameter Controls, Equations & Observation Table */}
        <div className="lg:col-span-5 space-y-4">
          <div className="rounded-xl border border-slate-200 bg-white p-5 space-y-4">
            <h2 className="text-sm font-bold text-[#0B1F3A]">Adjustable Physical Parameters</h2>

            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-xs font-medium mb-1">
                  <label htmlFor="slider-a">{paramSpecs[0].label}</label>
                  <span className="font-mono tabular-nums font-semibold text-cyan-800">
                    {paramA} {paramSpecs[0].unit}
                  </span>
                </div>
                <input
                  id="slider-a"
                  type="range"
                  min={paramSpecs[0].min}
                  max={paramSpecs[0].max}
                  step={paramSpecs[0].step}
                  value={paramA}
                  onChange={(e) => setParamA(Number(e.target.value))}
                  className="w-full accent-cyan-600"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs font-medium mb-1">
                  <label htmlFor="slider-b">{paramSpecs[1].label}</label>
                  <span className="font-mono tabular-nums font-semibold text-cyan-800">
                    {paramB} {paramSpecs[1].unit}
                  </span>
                </div>
                <input
                  id="slider-b"
                  type="range"
                  min={paramSpecs[1].min}
                  max={paramSpecs[1].max}
                  step={paramSpecs[1].step}
                  value={paramB}
                  onChange={(e) => setParamB(Number(e.target.value))}
                  className="w-full accent-cyan-600"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs font-medium mb-1">
                  <label htmlFor="slider-c">{paramSpecs[2].label}</label>
                  <span className="font-mono tabular-nums font-semibold text-cyan-800">
                    {paramC} {paramSpecs[2].unit}
                  </span>
                </div>
                <input
                  id="slider-c"
                  type="range"
                  min={paramSpecs[2].min}
                  max={paramSpecs[2].max}
                  step={paramSpecs[2].step}
                  value={paramC}
                  onChange={(e) => setParamC(Number(e.target.value))}
                  className="w-full accent-cyan-600"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-100 text-xs">
              <div className="rounded-lg bg-slate-50 p-3 border border-slate-200/70">
                <p className="text-slate-500">{computed.primaryLabel}</p>
                <p className="mt-0.5 font-mono font-bold text-[#0B1F3A] tabular-nums">
                  {computed.primaryVal}
                </p>
              </div>
              <div className="rounded-lg bg-slate-50 p-3 border border-slate-200/70">
                <p className="text-slate-500">{computed.secondaryLabel}</p>
                <p className="mt-0.5 font-mono font-bold text-cyan-800 tabular-nums">
                  {computed.secondaryVal}
                </p>
              </div>
            </div>

            <div className="overflow-x-auto max-w-full">
              <MathFormula latex={activeLab.equationLatex} display className="text-xs sm:text-sm" />
            </div>

            <div className="space-y-1 text-xs text-slate-600">
              <p className="font-bold text-[#0B1F3A]">Experiment Instructions</p>
              <ol className="list-decimal pl-4 space-y-0.5">
                {activeLab.instructions.map((ins, i) => (
                  <li key={i}>{ins}</li>
                ))}
              </ol>
            </div>
          </div>

          {/* Observation Table */}
          <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-[#0B1F3A]">
                Observation Table ({observations.length})
              </h3>
              {observations.length > 0 && (
                <button
                  type="button"
                  onClick={() => setObservations([])}
                  className="text-xs text-slate-500 hover:text-red-600 inline-flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Clear</span>
                </button>
              )}
            </div>
            {observations.length === 0 ? (
              <p className="text-xs text-slate-500">
                Click &ldquo;Record Observation&rdquo; to log live experimental measurements.
              </p>
            ) : (
              <div className="overflow-x-auto max-h-44">
                <table className="w-full text-left text-xs tabular-nums">
                  <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                    <tr>
                      <th className="py-2 px-2">Trial</th>
                      <th className="py-2 px-2">Inputs</th>
                      <th className="py-2 px-2">Measured</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {observations.map((row, idx) => (
                      <tr key={row.id}>
                        <td className="py-1.5 px-2 font-mono">{observations.length - idx}</td>
                        <td className="py-1.5 px-2 text-slate-600">{row.summary}</td>
                        <td className="py-1.5 px-2 font-mono font-semibold text-[#0B1F3A]">
                          {row.primaryMetric}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
