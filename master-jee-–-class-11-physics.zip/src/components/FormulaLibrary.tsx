import { useMemo, useState } from 'react';
import { Bookmark, Search, Eye, EyeOff } from 'lucide-react';
import { ALL_CHAPTERS, getAllFormulas } from '../data/curriculumIndex';
import { useApp } from '../context/AppContext';
import { MathFormula } from './MathBlock';

export function FormulaLibrary() {
  const { bookmarkedFormulaIds, toggleFormulaBookmark, setActiveChapterId, setActiveScreen } =
    useApp();
  const [chapterFilter, setChapterFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [onlyBookmarked, setOnlyBookmarked] = useState(false);
  const [quickRevisionMode, setQuickRevisionMode] = useState(false);
  const [revealedIds, setRevealedIds] = useState<string[]>([]);

  const allFormulas = useMemo(() => getAllFormulas(), []);

  const filtered = allFormulas.filter((f) => {
    if (chapterFilter !== 'all' && f.chapterId !== chapterFilter) return false;
    if (onlyBookmarked && !bookmarkedFormulaIds.includes(f.id)) return false;
    const q = searchTerm.trim().toLowerCase();
    if (
      q &&
      !f.name.toLowerCase().includes(q) &&
      !f.interpretation.toLowerCase().includes(q) &&
      !f.dimensions.toLowerCase().includes(q)
    ) {
      return false;
    }
    return true;
  });

  const toggleReveal = (id: string) => {
    setRevealedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#0B1F3A]">Comprehensive Physics Formula Bank</h1>
          <p className="mt-1 text-sm text-slate-600">
            Chapter-wise equation sheets with SI units, dimensional formulas, and validity bounds.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setOnlyBookmarked((v) => !v)}
            className={`px-3 py-2 rounded-lg text-xs font-semibold border whitespace-nowrap ${
              onlyBookmarked
                ? 'bg-[#0B1F3A] text-white border-[#0B1F3A]'
                : 'bg-white text-slate-700 border-slate-200'
            }`}
          >
            Bookmarked ({bookmarkedFormulaIds.length})
          </button>
          <button
            type="button"
            onClick={() => {
              setQuickRevisionMode((v) => !v);
              setRevealedIds([]);
            }}
            className={`px-3 py-2 rounded-lg text-xs font-semibold border whitespace-nowrap ${
              quickRevisionMode
                ? 'bg-cyan-600 text-white border-cyan-600'
                : 'bg-white text-slate-700 border-slate-200'
            }`}
          >
            {quickRevisionMode ? 'Quick Revision: ON' : 'Quick Revision Mode'}
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="search"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search formula name, dimension, or keyword..."
            aria-label="Search formulas"
            className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-300 bg-white text-sm"
          />
        </div>
        <select
          aria-label="Filter formulas by chapter"
          value={chapterFilter}
          onChange={(e) => setChapterFilter(e.target.value)}
          className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-[#0B1F3A]"
        >
          <option value="all">All 14 Chapters</option>
          {ALL_CHAPTERS.map((c) => (
            <option key={c.id} value={c.id}>
              Ch {c.number}: {c.title}
            </option>
          ))}
        </select>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-600">
          No formulas match your active filter. Clear search or bookmark filter to view all formulas.
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {filtered.map((f) => {
            const isBookmarked = bookmarkedFormulaIds.includes(f.id);
            const isHidden = quickRevisionMode && !revealedIds.includes(f.id);
            const ch = ALL_CHAPTERS.find((c) => c.id === f.chapterId);

            return (
              <article key={f.id} className="rounded-xl border border-slate-200 bg-white p-5 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-xs text-slate-500">
                      Ch {ch?.number} · {ch?.title} {f.isImportant ? '· High-Yield JEE' : ''}
                    </p>
                    <h2 className="text-base font-bold text-[#0B1F3A]">{f.name}</h2>
                  </div>
                  <button
                    type="button"
                    aria-label={isBookmarked ? `Remove bookmark for ${f.name}` : `Bookmark ${f.name}`}
                    onClick={() => toggleFormulaBookmark(f.id)}
                    className={`p-2 rounded-lg border transition-colors ${
                      isBookmarked
                        ? 'bg-amber-50 border-amber-300 text-amber-600'
                        : 'border-slate-200 text-slate-400 hover:text-slate-700'
                    }`}
                  >
                    <Bookmark className="w-4 h-4" fill={isBookmarked ? 'currentColor' : 'none'} />
                  </button>
                </div>

                {isHidden ? (
                  <button
                    type="button"
                    onClick={() => toggleReveal(f.id)}
                    className="w-full py-4 rounded-lg border border-dashed border-cyan-400 bg-cyan-50/40 text-xs font-semibold text-cyan-800 inline-flex items-center justify-center gap-2"
                  >
                    <Eye className="w-4 h-4" />
                    <span>Recall Formula, then Click to Reveal</span>
                  </button>
                ) : (
                  <>
                    <MathFormula latex={f.latex} display />
                    {quickRevisionMode && (
                      <button
                        type="button"
                        onClick={() => toggleReveal(f.id)}
                        className="text-xs text-slate-500 inline-flex items-center gap-1"
                      >
                        <EyeOff className="w-3.5 h-3.5" />
                        <span>Hide</span>
                      </button>
                    )}
                  </>
                )}

                <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-2.5 rounded-lg border border-slate-200/70">
                  <div>
                    <span className="text-slate-500">SI Unit: </span>
                    <span className="font-mono font-semibold text-slate-800">{f.siUnit}</span>
                  </div>
                  <div>
                    <span className="text-slate-500">Dimensions: </span>
                    <span className="font-mono font-semibold text-cyan-800">{f.dimensions}</span>
                  </div>
                </div>

                <p className="text-xs text-slate-700 leading-relaxed">{f.interpretation}</p>
                <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 text-xs text-slate-500">
                  <span>Validity: {f.validity}</span>
                  {f.relatedDerivationId && (
                    <button
                      type="button"
                      onClick={() => {
                        setActiveChapterId(f.chapterId);
                        setActiveScreen('reader');
                      }}
                      className="font-semibold text-cyan-700 hover:underline"
                    >
                      Open Derivation →
                    </button>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
