import {
  collection,
  doc,
  getDocs,
  orderBy,
  query,
  serverTimestamp,
  writeBatch,
  type Firestore,
} from 'firebase/firestore';
import type {
  AcademicLevel,
  CurriculumScope,
  LabSimulationId,
  SyllabusChapterNode,
  SyllabusSubtopicNode,
  SyllabusTopicNode,
} from '../types/physics';
import { handleFirestoreError, OperationType } from './firebase';
import {
  buildFirestoreSyllabusPayloads,
  type SyllabusChapterRecord,
  type SyllabusTopicRecord,
  type SyllabusSubtopicRecord,
} from './syllabusPayloads';

export {
  buildFirestoreSyllabusPayloads,
  type SyllabusChapterRecord,
  type SyllabusTopicRecord,
  type SyllabusSubtopicRecord,
};

export async function seedSyllabusToFirestore(
  db: Firestore,
  chapters: SyllabusChapterNode[],
  authorId: string
): Promise<{ chaptersWritten: number; topicsWritten: number; subtopicsWritten: number }> {
  let chaptersWritten = 0;
  let topicsWritten = 0;
  let subtopicsWritten = 0;

  let batch = writeBatch(db);
  let opCount = 0;

  const commitIfNearLimit = async () => {
    if (opCount >= 400) {
      try {
        await batch.commit();
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, 'syllabus');
      }
      batch = writeBatch(db);
      opCount = 0;
    }
  };

  for (const chapter of chapters) {
    const { chapterDoc, topicDocs, subtopicDocs } = buildFirestoreSyllabusPayloads(chapter, authorId);
    const chapterRef = doc(db, 'syllabus', chapterDoc.chapterId);

    batch.set(chapterRef, {
      ...chapterDoc,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    opCount += 1;
    chaptersWritten += 1;

    for (const topic of topicDocs) {
      const topicRef = doc(db, 'syllabus', chapterDoc.chapterId, 'topics', topic.topicId);
      batch.set(topicRef, {
        ...topic,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      opCount += 1;
      topicsWritten += 1;
    }

    for (const subtopic of subtopicDocs) {
      const subtopicRef = doc(
        db,
        'syllabus',
        chapterDoc.chapterId,
        'topics',
        subtopic.topicId,
        'subtopics',
        subtopic.subtopicId
      );
      batch.set(subtopicRef, {
        ...subtopic,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      opCount += 1;
      subtopicsWritten += 1;
    }

    await commitIfNearLimit();
  }

  if (opCount > 0) {
    try {
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'syllabus');
    }
  }

  return { chaptersWritten, topicsWritten, subtopicsWritten };
}

export async function fetchSyllabusFromFirestore(
  db: Firestore
): Promise<SyllabusChapterNode[]> {
  let chapterSnap;
  try {
    chapterSnap = await getDocs(query(collection(db, 'syllabus'), orderBy('chapterNumber', 'asc')));
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'syllabus');
  }

  if (chapterSnap.empty) {
    return [];
  }

  const chapters: SyllabusChapterNode[] = [];

  for (const chapDoc of chapterSnap.docs) {
    const c = chapDoc.data();
    const chapterId = String(c.chapterId || chapDoc.id);

    let topicSnap;
    try {
      topicSnap = await getDocs(
        query(collection(db, 'syllabus', chapterId, 'topics'), orderBy('order', 'asc'))
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, `syllabus/${chapterId}/topics`);
    }

    const topics: SyllabusTopicNode[] = [];
    for (const topDoc of topicSnap.docs) {
      const t = topDoc.data();
      const topicId = String(t.topicId || topDoc.id);

      let subSnap;
      try {
        subSnap = await getDocs(
          query(
            collection(db, 'syllabus', chapterId, 'topics', topicId, 'subtopics'),
            orderBy('order', 'asc')
          )
        );
      } catch (err) {
        handleFirestoreError(
          err,
          OperationType.LIST,
          `syllabus/${chapterId}/topics/${topicId}/subtopics`
        );
      }

      const subtopics: SyllabusSubtopicNode[] = subSnap.docs.map((sd) => {
        const s = sd.data();
        return {
          subtopicId: String(s.subtopicId || sd.id),
          topicId,
          chapterId,
          order: Number(s.order || 1),
          code: String(s.code || ''),
          title: String(s.title || ''),
          ncertAligned: Boolean(s.ncertAligned),
          jeeMainAligned: Boolean(s.jeeMainAligned),
          jeeAdvancedAligned: Boolean(s.jeeAdvancedAligned),
          enrichmentOnly: Boolean(s.enrichmentOnly),
          keyConcepts: Array.isArray(s.keyConcepts) ? s.keyConcepts.map(String) : [],
          linkedContentSubtopicId: String(s.linkedContentSubtopicId || `${chapterId}-s1`),
        };
      });

      topics.push({
        topicId,
        chapterId,
        order: Number(t.order || 1),
        code: String(t.code || ''),
        title: String(t.title || ''),
        ncertSectionRef: String(t.ncertSectionRef || ''),
        curriculumScope: (t.curriculumScope as CurriculumScope) || 'NCERT Core',
        isEnrichment: Boolean(t.isEnrichment),
        targetLevels: Array.isArray(t.targetLevels)
          ? (t.targetLevels as AcademicLevel[])
          : ['foundation', 'jee_main'],
        linkedContentSubtopicId: String(t.linkedContentSubtopicId || `${chapterId}-s1`),
        subtopics,
      });
    }

    chapters.push({
      chapterId,
      chapterNumber: Number(c.chapterNumber || 1),
      title: String(c.title || ''),
      ncertBookPart: (c.ncertBookPart as 'Part I' | 'Part II') || 'Part I',
      ncertChapterNumber: Number(c.ncertChapterNumber || 1),
      unitGroup:
        (c.unitGroup as SyllabusChapterNode['unitGroup']) || 'Mechanics',
      ncertWeightage: String(c.ncertWeightage || ''),
      jeeWeightage: String(c.jeeWeightage || ''),
      estimatedHours: Number(c.estimatedHours || 6),
      overview: String(c.overview || ''),
      labId: (c.labId as LabSimulationId) || 'vector_addition',
      topics,
    });
  }

  return chapters;
}
