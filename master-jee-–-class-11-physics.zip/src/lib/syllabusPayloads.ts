import type {
  AcademicLevel,
  CurriculumScope,
  LabSimulationId,
  SyllabusChapterNode,
} from '../types/physics';

const VALID_ID_REGEX = /^[a-zA-Z0-9_-]+$/;

export interface SyllabusChapterRecord {
  chapterId: string;
  chapterNumber: number;
  title: string;
  ncertBookPart: 'Part I' | 'Part II';
  ncertChapterNumber: number;
  unitGroup: 'Mechanics' | 'Properties of Matter' | 'Thermal Physics' | 'Oscillations & Waves';
  ncertWeightage: string;
  jeeWeightage: string;
  estimatedHours: number;
  overview: string;
  labId: LabSimulationId;
  topicCount: number;
  subtopicCount: number;
  authorId: string;
}

export interface SyllabusTopicRecord {
  topicId: string;
  chapterId: string;
  order: number;
  code: string;
  title: string;
  ncertSectionRef: string;
  curriculumScope: CurriculumScope;
  isEnrichment: boolean;
  targetLevels: AcademicLevel[];
  linkedContentSubtopicId: string;
  authorId: string;
}

export interface SyllabusSubtopicRecord {
  subtopicId: string;
  topicId: string;
  chapterId: string;
  order: number;
  code: string;
  title: string;
  ncertAligned: boolean;
  jeeMainAligned: boolean;
  jeeAdvancedAligned: boolean;
  enrichmentOnly: boolean;
  keyConcepts: string[];
  linkedContentSubtopicId: string;
  authorId: string;
}

function assertValidFirestoreId(id: string, maxLen = 128) {
  if (!id || id.length > maxLen || !VALID_ID_REGEX.test(id)) {
    throw new Error(`Invalid Firestore document ID: "${id}"`);
  }
}

export function buildFirestoreSyllabusPayloads(
  chapter: SyllabusChapterNode,
  authorId: string
): {
  chapterDoc: SyllabusChapterRecord;
  topicDocs: SyllabusTopicRecord[];
  subtopicDocs: SyllabusSubtopicRecord[];
} {
  assertValidFirestoreId(chapter.chapterId, 64);
  assertValidFirestoreId(chapter.labId, 64);
  assertValidFirestoreId(authorId, 128);

  const totalSubtopics = chapter.topics.reduce((acc, t) => acc + t.subtopics.length, 0);

  const chapterDoc: SyllabusChapterRecord = {
    chapterId: chapter.chapterId,
    chapterNumber: chapter.chapterNumber,
    title: chapter.title.slice(0, 160),
    ncertBookPart: chapter.ncertBookPart,
    ncertChapterNumber: chapter.ncertChapterNumber,
    unitGroup: chapter.unitGroup,
    ncertWeightage: chapter.ncertWeightage.slice(0, 64),
    jeeWeightage: chapter.jeeWeightage.slice(0, 80),
    estimatedHours: Math.max(1, Math.min(100, Math.round(chapter.estimatedHours))),
    overview: chapter.overview.slice(0, 1200),
    labId: chapter.labId,
    topicCount: chapter.topics.length,
    subtopicCount: totalSubtopics,
    authorId,
  };

  const topicDocs: SyllabusTopicRecord[] = [];
  const subtopicDocs: SyllabusSubtopicRecord[] = [];

  for (const topic of chapter.topics) {
    assertValidFirestoreId(topic.topicId, 128);
    assertValidFirestoreId(topic.linkedContentSubtopicId, 64);

    topicDocs.push({
      topicId: topic.topicId,
      chapterId: chapter.chapterId,
      order: topic.order,
      code: topic.code.slice(0, 24),
      title: topic.title.slice(0, 200),
      ncertSectionRef: topic.ncertSectionRef.slice(0, 80),
      curriculumScope: topic.curriculumScope,
      isEnrichment: topic.isEnrichment,
      targetLevels: topic.targetLevels.slice(0, 3),
      linkedContentSubtopicId: topic.linkedContentSubtopicId,
      authorId,
    });

    for (const st of topic.subtopics) {
      assertValidFirestoreId(st.subtopicId, 128);
      assertValidFirestoreId(st.linkedContentSubtopicId, 64);
      const boundedConcepts = st.keyConcepts
        .map((k) => k.trim().slice(0, 160))
        .filter((k) => k.length > 0)
        .slice(0, 10);

      subtopicDocs.push({
        subtopicId: st.subtopicId,
        topicId: topic.topicId,
        chapterId: chapter.chapterId,
        order: st.order,
        code: st.code.slice(0, 24),
        title: st.title.slice(0, 220),
        ncertAligned: st.ncertAligned,
        jeeMainAligned: st.jeeMainAligned,
        jeeAdvancedAligned: st.jeeAdvancedAligned,
        enrichmentOnly: st.enrichmentOnly,
        keyConcepts: boundedConcepts.length > 0 ? boundedConcepts : ['Core concept'],
        linkedContentSubtopicId: st.linkedContentSubtopicId,
        authorId,
      });
    }
  }

  return { chapterDoc, topicDocs, subtopicDocs };
}
