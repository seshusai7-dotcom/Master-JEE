import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut, type User } from 'firebase/auth';
import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  getDocs,
  deleteDoc,
  serverTimestamp,
  query,
  orderBy,
  limit,
} from 'firebase/firestore';
import {
  auth,
  db,
  googleProvider,
  handleFirestoreError,
  OperationType,
  validateFirestoreConnection,
} from '../lib/firebase';
import type {
  AcademicLevel,
  AppScreen,
  FlashcardProgressRecord,
  ManagedContentItem,
  QuestionEntry,
  QuizAttempt,
  StudyNote,
  SyllabusChapterNode,
  WorkflowStatus,
} from '../types/physics';
import { QUESTION_BANK } from '../data/questionBank';
import { SYLLABUS_HIERARCHY } from '../data/syllabusHierarchy';
import { fetchSyllabusFromFirestore, seedSyllabusToFirestore } from '../lib/syllabusFirestore';

export type AuthMode = 'unauthenticated' | 'firebase' | 'demo_student' | 'demo_admin';

export interface UserProfileState {
  uid: string;
  displayName: string;
  email: string;
  role: 'student' | 'admin';
  academicLevel: AcademicLevel;
  streakDays: number;
  totalStudyMinutes: number;
  dailyTargetQuestions: number;
}

interface AppContextValue {
  authReady: boolean;
  authMode: AuthMode;
  firebaseUser: User | null;
  profile: UserProfileState;
  activeScreen: AppScreen;
  setActiveScreen: (screen: AppScreen) => void;
  activeChapterId: string;
  setActiveChapterId: (chapterId: string) => void;
  activeSubtopicId: string | null;
  setActiveSubtopicId: (subtopicId: string | null) => void;
  syllabusHierarchy: SyllabusChapterNode[];
  syllabusSyncStatus: 'local_seed' | 'syncing' | 'firestore_synced';
  syllabusSyncMessage: string | null;
  syncSyllabusHierarchy: () => Promise<void>;
  academicLevel: AcademicLevel;
  setAcademicLevel: (level: AcademicLevel) => Promise<void>;
  completedSubtopics: string[];
  toggleSubtopicComplete: (subtopicId: string) => void;
  bookmarkedFormulaIds: string[];
  toggleFormulaBookmark: (formulaId: string) => void;
  attempts: QuizAttempt[];
  recordAttempt: (attempt: QuizAttempt) => Promise<void>;
  notes: StudyNote[];
  saveNote: (note: Omit<StudyNote, 'createdAtIso' | 'updatedAtIso'>) => Promise<void>;
  deleteNote: (noteId: string) => Promise<void>;
  flashcardProgress: Record<string, FlashcardProgressRecord>;
  updateFlashcardProgress: (record: FlashcardProgressRecord) => Promise<void>;
  managedContent: ManagedContentItem[];
  addManagedContent: (item: Omit<ManagedContentItem, 'updatedAtIso'>) => Promise<void>;
  advanceWorkflowStatus: (contentId: string, nextStatus: WorkflowStatus) => Promise<void>;
  customQuestions: QuestionEntry[];
  allQuestions: QuestionEntry[];
  addQuestionEntry: (entry: QuestionEntry) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  enterDemoMode: (role: 'student' | 'admin') => void;
  logout: () => Promise<void>;
  authError: string | null;
}

const STORAGE_KEY = 'master_jee_physics_state_v1';
const ADMIN_EMAIL = 'seshusai7@gmail.com';

const DEFAULT_PROFILE: UserProfileState = {
  uid: 'demo-student',
  displayName: 'Aarav Sharma (Class 11 Aspirant)',
  email: 'student.demo@masterjee.edu',
  role: 'student',
  academicLevel: 'jee_main',
  streakDays: 7,
  totalStudyMinutes: 420,
  dailyTargetQuestions: 25,
};

const SEED_ATTEMPTS: QuizAttempt[] = [
  {
    attemptId: 'seed-att-1',
    chapterId: 'ch1',
    chapterTitle: 'Units and Measurements',
    mode: 'chapter_test',
    score: 16,
    maxScore: 20,
    accuracyPct: 80,
    timeSpentSec: 340,
    totalQuestions: 5,
    correctCount: 4,
    wrongCount: 1,
    unattemptedCount: 0,
    weakTopics: ['vernier'],
    createdAtIso: '2026-11-12T10:15:00.000Z',
  },
  {
    attemptId: 'seed-att-2',
    chapterId: 'ch3',
    chapterTitle: 'Motion in a Plane',
    mode: 'topic_quiz',
    score: 12,
    maxScore: 16,
    accuracyPct: 75,
    timeSpentSec: 280,
    totalQuestions: 4,
    correctCount: 3,
    wrongCount: 1,
    unattemptedCount: 0,
    weakTopics: ['projectile'],
    createdAtIso: '2026-11-14T16:30:00.000Z',
  },
];

const SEED_NOTES: StudyNote[] = [
  {
    noteId: 'seed-note-1',
    chapterId: 'ch1',
    category: 'mistake',
    title: 'Screw Gauge Negative Zero Error Sign',
    body: 'Remember: when the circular scale zero sits ABOVE the datum line, the zero error is NEGATIVE. True Reading = Observed − (−e). Do not take circular division directly—use (N − k) × LC.',
    createdAtIso: '2026-11-12T10:20:00.000Z',
    updatedAtIso: '2026-11-12T10:20:00.000Z',
  },
  {
    noteId: 'seed-note-2',
    chapterId: 'ch6',
    category: 'note',
    title: 'Pure Rolling Down Incline Shortcut',
    body: 'Acceleration a = g sin θ / (1 + I_cm / (MR²)). Solid sphere (2/5) beats solid cylinder (1/2) beats ring (1) regardless of mass or radius.',
    createdAtIso: '2026-11-14T18:00:00.000Z',
    updatedAtIso: '2026-11-14T18:00:00.000Z',
  },
];

const SEED_MANAGED_CONTENT: ManagedContentItem[] = [
  {
    contentId: 'mc-ch1-buckingham',
    chapterId: 'ch1',
    subtopicId: 'ch1-s4',
    title: 'Buckingham Pi Theorem & Non-Standard Basis Conversion',
    summary:
      'Enrichment note reviewed for JEE Advanced aspirants: constructing dimensionless Π-groups from physical variables when selecting {E, v, T} or {G, h, c} as base quantities.',
    workflowStatus: 'PUBLISH',
    sourceLabel: 'Academic Director Curated',
    updatedAtIso: '2026-11-10T09:00:00.000Z',
  },
  {
    contentId: 'mc-ch6-iaor',
    chapterId: 'ch6',
    subtopicId: 'ch6-s1',
    title: 'Instantaneous Axis of Rotation (IAOR) Problem Drill',
    summary:
      'Draft enrichment supplement demonstrating how computing kinetic energy and torque about the instantaneous contact point simplifies constrained rolling problems.',
    workflowStatus: 'TEACHER_REVIEW',
    sourceLabel: 'Original AI-Generated',
    updatedAtIso: '2026-11-15T11:30:00.000Z',
  },
];

const AppContext = createContext<AppContextValue | null>(null);

interface LocalPersistedState {
  authMode?: AuthMode;
  profile?: UserProfileState;
  activeChapterId?: string;
  completedSubtopics?: string[];
  bookmarkedFormulaIds?: string[];
  attempts?: QuizAttempt[];
  notes?: StudyNote[];
  flashcardProgress?: Record<string, FlashcardProgressRecord>;
  managedContent?: ManagedContentItem[];
  customQuestions?: QuestionEntry[];
}

function readLocalState(): LocalPersistedState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as LocalPersistedState) : {};
  } catch {
    return {};
  }
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const initialLocal = readLocalState();
  const autostartDemo =
    typeof window !== 'undefined' &&
    new URLSearchParams(window.location.search).get('autostart') === '1';

  const [authReady, setAuthReady] = useState(false);
  const [authMode, setAuthMode] = useState<AuthMode>(() => {
    if (autostartDemo) return 'demo_student';
    if (initialLocal.authMode === 'demo_student' || initialLocal.authMode === 'demo_admin') {
      return initialLocal.authMode;
    }
    return 'unauthenticated';
  });
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfileState>(
    initialLocal.profile ?? DEFAULT_PROFILE
  );
  const [activeScreen, setActiveScreen] = useState<AppScreen>('dashboard');
  const [activeChapterId, setActiveChapterId] = useState<string>(
    initialLocal.activeChapterId ?? 'ch1'
  );
  const [activeSubtopicId, setActiveSubtopicId] = useState<string | null>(null);
  const [syllabusHierarchy, setSyllabusHierarchy] = useState<SyllabusChapterNode[]>(
    SYLLABUS_HIERARCHY
  );
  const [syllabusSyncStatus, setSyllabusSyncStatus] = useState<
    'local_seed' | 'syncing' | 'firestore_synced'
  >('local_seed');
  const [syllabusSyncMessage, setSyllabusSyncMessage] = useState<string | null>(null);
  const [completedSubtopics, setCompletedSubtopics] = useState<string[]>(
    initialLocal.completedSubtopics ?? ['ch1-s1']
  );
  const [bookmarkedFormulaIds, setBookmarkedFormulaIds] = useState<string[]>(
    initialLocal.bookmarkedFormulaIds ?? ['ch1-f1', 'ch1-f4']
  );
  const [attempts, setAttempts] = useState<QuizAttempt[]>(
    initialLocal.attempts ?? SEED_ATTEMPTS
  );
  const [notes, setNotes] = useState<StudyNote[]>(initialLocal.notes ?? SEED_NOTES);
  const [flashcardProgress, setFlashcardProgress] = useState<
    Record<string, FlashcardProgressRecord>
  >(initialLocal.flashcardProgress ?? {});
  const [managedContent, setManagedContent] = useState<ManagedContentItem[]>(
    initialLocal.managedContent ?? SEED_MANAGED_CONTENT
  );
  const [customQuestions, setCustomQuestions] = useState<QuestionEntry[]>(
    initialLocal.customQuestions ?? []
  );
  const [authError, setAuthError] = useState<string | null>(null);

  // Persist demo/offline state to localStorage cleanly
  useEffect(() => {
    try {
      const payload: LocalPersistedState = {
        authMode,
        profile,
        activeChapterId,
        completedSubtopics,
        bookmarkedFormulaIds,
        attempts,
        notes,
        flashcardProgress,
        managedContent,
        customQuestions,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    } catch {
      // Ignore storage quota errors
    }
  }, [
    authMode,
    profile,
    activeChapterId,
    completedSubtopics,
    bookmarkedFormulaIds,
    attempts,
    notes,
    flashcardProgress,
    managedContent,
    customQuestions,
  ]);

  // Boot Firestore validation + Auth observer
  useEffect(() => {
    validateFirestoreConnection();
    const unsub = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      if (user && user.emailVerified) {
        setAuthMode('firebase');
        const isDirector = user.email === ADMIN_EMAIL;
        const userRef = doc(db, 'users', user.uid);
        try {
          const snap = await getDoc(userRef);
          if (snap.exists()) {
            const data = snap.data();
            setProfile({
              uid: user.uid,
              displayName: String(data.displayName || user.displayName || 'Student'),
              email: String(data.email || user.email || ''),
              role: isDirector || data.role === 'admin' ? 'admin' : 'student',
              academicLevel: (data.academicLevel as AcademicLevel) || 'jee_main',
              streakDays: Number(data.streakDays ?? 1),
              totalStudyMinutes: Number(data.totalStudyMinutes ?? 0),
              dailyTargetQuestions: Number(data.dailyTargetQuestions ?? 25),
            });
          } else {
            const newProfile: UserProfileState = {
              uid: user.uid,
              displayName: user.displayName || (isDirector ? 'Dr. V. Sesha Sai Kumar' : 'JEE Student'),
              email: user.email || '',
              role: isDirector ? 'admin' : 'student',
              academicLevel: 'jee_main',
              streakDays: 1,
              totalStudyMinutes: 0,
              dailyTargetQuestions: 25,
            };
            await setDoc(userRef, {
              ...newProfile,
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp(),
            });
            setProfile(newProfile);
          }

          // Load attempts & notes
          const attSnap = await getDocs(
            query(collection(db, 'users', user.uid, 'attempts'), orderBy('createdAt', 'desc'), limit(50))
          );
          if (!attSnap.empty) {
            setAttempts(
              attSnap.docs.map((d) => {
                const raw = d.data();
                return {
                  attemptId: d.id,
                  chapterId: String(raw.chapterId || 'ch1'),
                  chapterTitle: String(raw.chapterId || 'Chapter'),
                  mode: raw.mode,
                  score: Number(raw.score || 0),
                  maxScore: Number(raw.maxScore || 20),
                  accuracyPct: Number(raw.accuracyPct || 0),
                  timeSpentSec: Number(raw.timeSpentSec || 0),
                  totalQuestions: Number(raw.totalQuestions || 1),
                  correctCount: Number(raw.correctCount || 0),
                  wrongCount: Math.max(0, Number(raw.totalQuestions || 0) - Number(raw.correctCount || 0)),
                  unattemptedCount: 0,
                  weakTopics: [],
                  createdAtIso: new Date().toISOString(),
                };
              })
            );
          }
          const notesSnap = await getDocs(collection(db, 'users', user.uid, 'notes'));
          if (!notesSnap.empty) {
            setNotes(
              notesSnap.docs.map((d) => {
                const raw = d.data();
                return {
                  noteId: d.id,
                  chapterId: String(raw.chapterId || 'ch1'),
                  category: raw.category || 'note',
                  title: String(raw.title || ''),
                  body: String(raw.body || ''),
                  createdAtIso: new Date().toISOString(),
                  updatedAtIso: new Date().toISOString(),
                };
              })
            );
          }

          // Load or bootstrap the 14-chapter structural syllabus hierarchy in Firestore
          try {
            const remoteSyllabus = await fetchSyllabusFromFirestore(db);
            if (remoteSyllabus.length === 14) {
              setSyllabusHierarchy(remoteSyllabus);
              setSyllabusSyncStatus('firestore_synced');
              setSyllabusSyncMessage('Loaded 14-chapter syllabus hierarchy from Firestore.');
            } else if (isDirector) {
              setSyllabusSyncStatus('syncing');
              const counts = await seedSyllabusToFirestore(db, SYLLABUS_HIERARCHY, user.uid);
              setSyllabusHierarchy(SYLLABUS_HIERARCHY);
              setSyllabusSyncStatus('firestore_synced');
              setSyllabusSyncMessage(
                `Seeded ${counts.chaptersWritten} chapters, ${counts.topicsWritten} topics, and ${counts.subtopicsWritten} subtopics to Firestore.`
              );
            }
          } catch {
            // Keep bundled SYLLABUS_HIERARCHY if Firestore syllabus fetch/seed encounters rules or offline issues
          }
        } catch (err) {
          handleFirestoreError(err, OperationType.GET, `users/${user.uid}`);
        }
      }
      setAuthReady(true);
    });
    return () => unsub();
  }, []);

  const loginWithGoogle = useCallback(async () => {
    setAuthError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Google Sign-In failed.';
      setAuthError(msg);
    }
  }, []);

  const enterDemoMode = useCallback((role: 'student' | 'admin') => {
    setAuthError(null);
    if (role === 'admin') {
      setAuthMode('demo_admin');
      setProfile({
        uid: 'demo-director',
        displayName: 'Dr. V. Sesha Sai Kumar (Academic Director)',
        email: ADMIN_EMAIL,
        role: 'admin',
        academicLevel: 'jee_advanced',
        streakDays: 14,
        totalStudyMinutes: 960,
        dailyTargetQuestions: 30,
      });
      setActiveScreen('admin');
    } else {
      setAuthMode('demo_student');
      setProfile(DEFAULT_PROFILE);
      setActiveScreen('dashboard');
    }
  }, []);

  const logout = useCallback(async () => {
    if (auth.currentUser) {
      await signOut(auth);
    }
    setAuthMode('unauthenticated');
    setActiveScreen('dashboard');
  }, []);

  const setAcademicLevel = useCallback(
    async (level: AcademicLevel) => {
      setProfile((prev) => ({ ...prev, academicLevel: level }));
      if (authMode === 'firebase' && firebaseUser) {
        const path = `users/${firebaseUser.uid}`;
        try {
          await updateDoc(doc(db, 'users', firebaseUser.uid), {
            academicLevel: level,
            updatedAt: serverTimestamp(),
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.UPDATE, path);
        }
      }
    },
    [authMode, firebaseUser]
  );

  const toggleSubtopicComplete = useCallback((subtopicId: string) => {
    setCompletedSubtopics((prev) =>
      prev.includes(subtopicId) ? prev.filter((id) => id !== subtopicId) : [...prev, subtopicId]
    );
  }, []);

  const toggleFormulaBookmark = useCallback((formulaId: string) => {
    setBookmarkedFormulaIds((prev) =>
      prev.includes(formulaId) ? prev.filter((id) => id !== formulaId) : [...prev, formulaId]
    );
  }, []);

  const recordAttempt = useCallback(
    async (attempt: QuizAttempt) => {
      setAttempts((prev) => [attempt, ...prev]);
      if (authMode === 'firebase' && firebaseUser) {
        const path = `users/${firebaseUser.uid}/attempts/${attempt.attemptId}`;
        try {
          await setDoc(doc(db, 'users', firebaseUser.uid, 'attempts', attempt.attemptId), {
            attemptId: attempt.attemptId,
            userId: firebaseUser.uid,
            chapterId: attempt.chapterId,
            mode: attempt.mode,
            score: attempt.score,
            maxScore: attempt.maxScore,
            accuracyPct: attempt.accuracyPct,
            timeSpentSec: Math.round(attempt.timeSpentSec),
            totalQuestions: attempt.totalQuestions,
            correctCount: attempt.correctCount,
            createdAt: serverTimestamp(),
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.CREATE, path);
        }
      }
    },
    [authMode, firebaseUser]
  );

  const saveNote = useCallback(
    async (note: Omit<StudyNote, 'createdAtIso' | 'updatedAtIso'>) => {
      const nowIso = new Date().toISOString();
      const exists = notes.some((n) => n.noteId === note.noteId);
      setNotes((prev) => {
        const filtered = prev.filter((n) => n.noteId !== note.noteId);
        return [{ ...note, createdAtIso: nowIso, updatedAtIso: nowIso }, ...filtered];
      });

      if (authMode === 'firebase' && firebaseUser) {
        const path = `users/${firebaseUser.uid}/notes/${note.noteId}`;
        try {
          if (exists) {
            await updateDoc(doc(db, 'users', firebaseUser.uid, 'notes', note.noteId), {
              title: note.title.slice(0, 200),
              body: note.body.slice(0, 4000),
              category: note.category,
              updatedAt: serverTimestamp(),
            });
          } else {
            await setDoc(doc(db, 'users', firebaseUser.uid, 'notes', note.noteId), {
              noteId: note.noteId,
              userId: firebaseUser.uid,
              chapterId: note.chapterId,
              category: note.category,
              title: note.title.slice(0, 200),
              body: note.body.slice(0, 4000),
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp(),
            });
          }
        } catch (err) {
          handleFirestoreError(err, OperationType.WRITE, path);
        }
      }
    },
    [authMode, firebaseUser, notes]
  );

  const deleteNote = useCallback(
    async (noteId: string) => {
      setNotes((prev) => prev.filter((n) => n.noteId !== noteId));
      if (authMode === 'firebase' && firebaseUser) {
        const path = `users/${firebaseUser.uid}/notes/${noteId}`;
        try {
          await deleteDoc(doc(db, 'users', firebaseUser.uid, 'notes', noteId));
        } catch (err) {
          handleFirestoreError(err, OperationType.DELETE, path);
        }
      }
    },
    [authMode, firebaseUser]
  );

  const updateFlashcardProgress = useCallback(
    async (record: FlashcardProgressRecord) => {
      setFlashcardProgress((prev) => ({ ...prev, [record.cardId]: record }));
      if (authMode === 'firebase' && firebaseUser) {
        const path = `users/${firebaseUser.uid}/flashcards/${record.cardId}`;
        try {
          await setDoc(doc(db, 'users', firebaseUser.uid, 'flashcards', record.cardId), {
            cardId: record.cardId,
            userId: firebaseUser.uid,
            chapterId: record.chapterId,
            box: record.box,
            nextReviewEpochMs: record.nextReviewEpochMs,
            updatedAt: serverTimestamp(),
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.WRITE, path);
        }
      }
    },
    [authMode, firebaseUser]
  );

  const addManagedContent = useCallback(
    async (item: Omit<ManagedContentItem, 'updatedAtIso'>) => {
      const nowIso = new Date().toISOString();
      setManagedContent((prev) => [{ ...item, updatedAtIso: nowIso }, ...prev]);
      if (authMode === 'firebase' && firebaseUser && profile.role === 'admin') {
        const path = `managedContent/${item.contentId}`;
        try {
          await setDoc(doc(db, 'managedContent', item.contentId), {
            contentId: item.contentId,
            chapterId: item.chapterId,
            subtopicId: item.subtopicId,
            title: item.title.slice(0, 200),
            summary: item.summary.slice(0, 8000),
            workflowStatus: item.workflowStatus,
            sourceLabel: item.sourceLabel,
            authorId: firebaseUser.uid,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.CREATE, path);
        }
      }
    },
    [authMode, firebaseUser, profile.role]
  );

  const advanceWorkflowStatus = useCallback(
    async (contentId: string, nextStatus: WorkflowStatus) => {
      setManagedContent((prev) =>
        prev.map((c) =>
          c.contentId === contentId
            ? { ...c, workflowStatus: nextStatus, updatedAtIso: new Date().toISOString() }
            : c
        )
      );
      if (authMode === 'firebase' && firebaseUser && profile.role === 'admin') {
        const path = `managedContent/${contentId}`;
        try {
          await updateDoc(doc(db, 'managedContent', contentId), {
            workflowStatus: nextStatus,
            updatedAt: serverTimestamp(),
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.UPDATE, path);
        }
      }
    },
    [authMode, firebaseUser, profile.role]
  );

  const addQuestionEntry = useCallback(
    async (entry: QuestionEntry) => {
      setCustomQuestions((prev) => [entry, ...prev]);
      if (authMode === 'firebase' && firebaseUser && profile.role === 'admin') {
        const path = `questionBank/${entry.id}`;
        try {
          await setDoc(doc(db, 'questionBank', entry.id), {
            questionId: entry.id,
            databaseCategory: entry.databaseCategory,
            chapterId: entry.chapterId,
            exam: entry.exam.slice(0, 80),
            year: entry.year,
            format: entry.format,
            difficulty: entry.difficulty,
            prompt: entry.prompt.slice(0, 4000),
            answer:
              entry.numericalAnswer !== undefined
                ? String(entry.numericalAnswer)
                : String((entry.correctOptionIndices ?? [0]).join(',')),
            solution: entry.solution.slice(0, 6000),
            sourceCitation: entry.sourceCitation.slice(0, 300),
            verified: entry.verified,
            authorId: firebaseUser.uid,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.CREATE, path);
        }
      }
    },
    [authMode, firebaseUser, profile.role]
  );

  const syncSyllabusHierarchy = useCallback(async () => {
    setSyllabusSyncStatus('syncing');
    if (authMode === 'firebase' && firebaseUser && profile.role === 'admin') {
      const counts = await seedSyllabusToFirestore(db, SYLLABUS_HIERARCHY, firebaseUser.uid);
      const reloaded = await fetchSyllabusFromFirestore(db);
      if (reloaded.length > 0) {
        setSyllabusHierarchy(reloaded);
      }
      setSyllabusSyncStatus('firestore_synced');
      setSyllabusSyncMessage(
        `Synced ${counts.chaptersWritten} chapters, ${counts.topicsWritten} topics, and ${counts.subtopicsWritten} subtopics to Firestore (/syllabus/{chapterId}/topics/{topicId}/subtopics/{subtopicId}).`
      );
      return;
    }
    setSyllabusSyncStatus('local_seed');
    setSyllabusSyncMessage(
      'Demo mode active: sign in with the Academic Director Google account (seshusai7@gmail.com) to write the 14-chapter hierarchy directly to Cloud Firestore.'
    );
  }, [authMode, firebaseUser, profile.role]);

  const allQuestions = [...customQuestions, ...QUESTION_BANK];

  return (
    <AppContext.Provider
      value={{
        authReady,
        authMode,
        firebaseUser,
        profile,
        activeScreen,
        setActiveScreen,
        activeChapterId,
        setActiveChapterId,
        activeSubtopicId,
        setActiveSubtopicId,
        syllabusHierarchy,
        syllabusSyncStatus,
        syllabusSyncMessage,
        syncSyllabusHierarchy,
        academicLevel: profile.academicLevel,
        setAcademicLevel,
        completedSubtopics,
        toggleSubtopicComplete,
        bookmarkedFormulaIds,
        toggleFormulaBookmark,
        attempts,
        recordAttempt,
        notes,
        saveNote,
        deleteNote,
        flashcardProgress,
        updateFlashcardProgress,
        managedContent,
        addManagedContent,
        advanceWorkflowStatus,
        customQuestions,
        allQuestions,
        addQuestionEntry,
        loginWithGoogle,
        enterDemoMode,
        logout,
        authError,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
