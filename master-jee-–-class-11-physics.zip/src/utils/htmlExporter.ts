import katex from 'katex';
import type {
  ChapterData,
  QuestionEntry,
  SyllabusChapterNode,
} from '../types/physics';
import { getSyllabusStats } from '../data/syllabusHierarchy';

export function escapeHtml(input: string): string {
  return String(input)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function renderFormulaToHtml(latex: string, display = false): string {
  try {
    return katex.renderToString(latex, {
      displayMode: display,
      throwOnError: false,
      strict: false,
    });
  } catch {
    return `<code>${escapeHtml(latex)}</code>`;
  }
}

export function renderMathToHtml(text: string): string {
  if (!text) return '';
  const regex = /(\$\$[\s\S]+?\$\$|\$[^$\n]+?\$)/g;
  let result = '';
  let lastIdx = 0;
  let match: RegExpExecArray | null;

  while ((match = regex.exec(text)) !== null) {
    if (match.index > lastIdx) {
      result += escapeHtml(text.slice(lastIdx, match.index));
    }
    const raw = match[0];
    if (raw.startsWith('$$') && raw.endsWith('$$')) {
      const inner = raw.slice(2, -2).trim();
      result += `<div class="math-block">${renderFormulaToHtml(inner, true)}</div>`;
    } else {
      const inner = raw.slice(1, -1).trim();
      result += `<span class="math-inline">${renderFormulaToHtml(inner, false)}</span>`;
    }
    lastIdx = regex.lastIndex;
  }

  if (lastIdx < text.length) {
    result += escapeHtml(text.slice(lastIdx));
  }
  return result;
}

export interface BuildProjectHtmlOptions {
  chapters: ChapterData[];
  syllabus: SyllabusChapterNode[];
  questions: QuestionEntry[];
  katexCss?: string;
  generatedAtIso?: string;
}

export function buildProjectHtmlDocument({
  chapters,
  syllabus,
  questions,
  katexCss = '',
  generatedAtIso = new Date().toISOString(),
}: BuildProjectHtmlOptions): string {
  const stats = getSyllabusStats(syllabus);
  const totalDerivations = chapters.reduce((acc, ch) => acc + ch.derivations.length, 0);
  const totalSolved = chapters.reduce((acc, ch) => acc + ch.solvedProblems.length, 0);
  const totalFormulas = chapters.reduce((acc, ch) => acc + ch.formulas.length, 0);

  const syllabusByChapterId = new Map(syllabus.map((s) => [s.chapterId, s]));

  const sidebarLinksHtml = chapters
    .map(
      (ch) => `
      <a class="toc-link" href="#chapter-${escapeHtml(ch.id)}" data-chapter-link="${escapeHtml(ch.id)}">
        <span class="toc-num">${String(ch.number).padStart(2, '0')}</span>
        <span class="toc-title">${escapeHtml(ch.title)}</span>
      </a>`
    )
    .join('\n');

  const chaptersHtml = chapters
    .map((ch) => {
      const syl = syllabusByChapterId.get(ch.id);

      const hierarchyHtml = syl
        ? `
        <div class="card-section">
          <h3>NCERT &amp; JEE Structural Hierarchy (${escapeHtml(syl.ncertBookPart)} · Ch ${syl.ncertChapterNumber})</h3>
          <div class="topic-grid">
            ${syl.topics
              .map(
                (t) => `
              <div class="topic-box ${t.isEnrichment ? 'is-enrichment' : ''}">
                <div class="topic-head">
                  <strong>${escapeHtml(t.code)} ${escapeHtml(t.title)}</strong>
                  <span class="tag ${t.isEnrichment ? 'tag-amber' : 'tag-slate'}">${escapeHtml(t.curriculumScope)}</span>
                </div>
                <p class="muted small">${escapeHtml(t.ncertSectionRef)}</p>
                <ul class="subtopic-list">
                  ${t.subtopics
                    .map(
                      (st) => `
                    <li>
                      <div>
                        <span class="mono">${escapeHtml(st.code)}</span> ${escapeHtml(st.title)}
                        <span class="badge-row">
                          ${st.ncertAligned ? '<span class="tag tag-slate">NCERT</span>' : ''}
                          ${st.jeeMainAligned ? '<span class="tag tag-cyan">JEE Main</span>' : ''}
                          ${st.jeeAdvancedAligned ? '<span class="tag tag-navy">JEE Adv</span>' : ''}
                          ${st.enrichmentOnly ? '<span class="tag tag-amber">Enrichment Only</span>' : ''}
                        </span>
                      </div>
                      <p class="muted tiny">Key concepts: ${escapeHtml(st.keyConcepts.join(' · '))}</p>
                    </li>`
                    )
                    .join('')}
                </ul>
              </div>`
              )
              .join('')}
          </div>
        </div>`
        : '';

      const subtopicsHtml = ch.subtopics
        .map(
          (sub) => `
        <article class="subtopic-article" id="sub-${escapeHtml(sub.id)}">
          <div class="subtopic-header">
            <span class="tag tag-cyan">${escapeHtml(sub.syllabusTag)}</span>
            <h3>${escapeHtml(sub.title)}</h3>
          </div>

          <div class="two-col">
            <div>
              <h4>A. Introduction &amp; Learning Objectives</h4>
              <ul>
                ${sub.introductionAndObjectives.map((item) => `<li>${renderMathToHtml(item)}</li>`).join('')}
              </ul>
            </div>
            <div>
              <h4>D. Physical Interpretation</h4>
              <p>${renderMathToHtml(sub.physicalInterpretation)}</p>
            </div>
          </div>

          <div class="level-box">
            <h4>B. Theoretical Explanation</h4>
            <div class="level-content" data-level="foundation">
              <p class="level-caption">Level 1 · Foundation Physics</p>
              <p>${renderMathToHtml(sub.theoreticalExplanation.foundation)}</p>
            </div>
            <div class="level-content" data-level="jee_main">
              <p class="level-caption">Level 2 · JEE Main</p>
              <p>${renderMathToHtml(sub.theoreticalExplanation.jee_main)}</p>
            </div>
            <div class="level-content" data-level="jee_advanced">
              <p class="level-caption">Level 3 · JEE Advanced</p>
              <p>${renderMathToHtml(sub.theoreticalExplanation.jee_advanced)}</p>
            </div>
          </div>

          <div class="two-col">
            <div>
              <h4>C. Definitions &amp; Fundamental Principles</h4>
              <dl class="def-list">
                ${sub.definitionsAndPrinciples
                  .map(
                    (d) => `
                  <div class="def-item">
                    <dt>${escapeHtml(d.term)}</dt>
                    <dd>${renderMathToHtml(d.definition)}</dd>
                  </div>`
                  )
                  .join('')}
              </dl>
            </div>
            <div>
              <h4>G. Assumptions &amp; Limitations</h4>
              <ul>
                ${sub.assumptionsAndLimitations.map((a) => `<li>${renderMathToHtml(a)}</li>`).join('')}
              </ul>
              <h4 style="margin-top: 1rem;">I. Schematic Reference</h4>
              <div class="schematic-note">
                <strong>${escapeHtml(sub.diagramSpec.title)}</strong>
                <p class="muted small">${escapeHtml(sub.diagramSpec.caption)}</p>
              </div>
            </div>
          </div>

          <h4>E. Mathematical Formulation</h4>
          <div class="formula-grid">
            ${sub.mathematicalFormulation
              .map(
                (eq) => `
              <div class="formula-card">
                <p class="formula-label">${escapeHtml(eq.label)}</p>
                <div class="math-block">${renderFormulaToHtml(eq.latex, true)}</div>
                <p class="muted small">${renderMathToHtml(eq.notes)}</p>
              </div>`
              )
              .join('')}
          </div>

          <h4>H. SI Units &amp; Dimensional Formulae</h4>
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Physical Quantity</th>
                  <th>SI Unit</th>
                  <th>Dimensions</th>
                </tr>
              </thead>
              <tbody>
                ${sub.unitsAndDimensions
                  .map(
                    (u) => `
                  <tr>
                    <td>${escapeHtml(u.quantity)}</td>
                    <td class="mono">${escapeHtml(u.siUnit)}</td>
                    <td class="mono">${escapeHtml(u.dimensions)}</td>
                  </tr>`
                  )
                  .join('')}
              </tbody>
            </table>
          </div>

          <div class="three-col">
            <div>
              <h4>J. Real-Life Applications</h4>
              <ul>
                ${sub.realLifeApplications.map((app) => `<li>${escapeHtml(app)}</li>`).join('')}
              </ul>
            </div>
            <div>
              <h4>K. Important Exam Concepts</h4>
              <ul>
                ${sub.importantExamConcepts.map((c) => `<li>${renderMathToHtml(c)}</li>`).join('')}
              </ul>
            </div>
            <div>
              <h4>L. Common Mistakes &amp; Fixes</h4>
              ${sub.commonMistakes
                .map(
                  (m) => `
                <div class="trap-box">
                  <p><strong>Trap:</strong> ${escapeHtml(m.misconception)}</p>
                  <p><strong>Fix:</strong> ${renderMathToHtml(m.correction)}</p>
                </div>`
                )
                .join('')}
            </div>
          </div>

          <div class="two-col">
            <div>
              <h4>M. Conceptual Questions</h4>
              ${sub.conceptualQuestions
                .map(
                  (cq) => `
                <details class="qa-details">
                  <summary>${escapeHtml(cq.question)}</summary>
                  <p>${renderMathToHtml(cq.answer)}</p>
                </details>`
                )
                .join('')}
            </div>
            <div>
              <h4>O–Q. Advanced Techniques, Summary &amp; Revision</h4>
              <div class="summary-box">
                <p class="small"><strong>Advanced Strategy</strong></p>
                <ul>
                  ${sub.advancedTechniques.map((t) => `<li>${renderMathToHtml(t)}</li>`).join('')}
                </ul>
                <p class="small" style="margin-top:0.75rem;"><strong>Summary &amp; Revision Notes</strong></p>
                <ul>
                  ${[...sub.summaryPoints, ...sub.revisionNotes].map((r) => `<li>${renderMathToHtml(r)}</li>`).join('')}
                </ul>
              </div>
            </div>
          </div>
        </article>`
        )
        .join('\n');

      const derivationsHtml = ch.derivations
        .map(
          (drv) => `
        <details class="qa-details" open>
          <summary><strong>${escapeHtml(drv.title)}</strong> — <span class="muted">${escapeHtml(drv.physicalPrinciple)}</span></summary>
          <div class="derivation-body">
            <div class="two-col">
              <div>
                <p class="small"><strong>Assumptions</strong></p>
                <ul>${drv.assumptions.map((a) => `<li>${escapeHtml(a)}</li>`).join('')}</ul>
              </div>
              <div>
                <p class="small"><strong>Symbols</strong></p>
                <ul>${drv.symbols.map((s) => `<li><span class="mono">${escapeHtml(s.symbol)}</span> — ${escapeHtml(s.meaning)} (${escapeHtml(s.unit)})</li>`).join('')}</ul>
              </div>
            </div>
            <div class="steps-list">
              ${drv.steps
                .map(
                  (st) => `
                <div class="step-item">
                  <p class="small"><strong>Step ${st.stepNumber}:</strong> ${escapeHtml(st.transformationNote)}</p>
                  <div class="math-block">${renderFormulaToHtml(st.equationLatex, true)}</div>
                </div>`
                )
                .join('')}
            </div>
            <div class="final-eq">
              <p class="small"><strong>Final Result &amp; Physical Significance</strong></p>
              <div class="math-block">${renderFormulaToHtml(drv.finalResultLatex, true)}</div>
              <p class="small">${escapeHtml(drv.physicalSignificance)}</p>
            </div>
            <div class="worked-box">
              <p class="small"><strong>Worked Example:</strong> ${renderMathToHtml(drv.workedExample.statement)}</p>
              <p class="small">${renderMathToHtml(drv.workedExample.solution)}</p>
              <p class="small"><strong>Answer:</strong> ${escapeHtml(drv.workedExample.answer)}</p>
            </div>
          </div>
        </details>`
        )
        .join('\n');

      const problemsHtml = ch.solvedProblems
        .map(
          (p, idx) => `
        <article class="problem-card">
          <div class="topic-head">
            <span class="small muted">Problem ${idx + 1} · ${escapeHtml(p.category)} · ${escapeHtml(p.physicsConcept)}</span>
            <span class="tag tag-navy">${escapeHtml(p.level.replace('_', ' ').toUpperCase())}</span>
          </div>
          <p class="problem-stmt">${renderMathToHtml(p.statement)}</p>
          <p class="small muted"><strong>Given:</strong> ${escapeHtml(p.givenData.join(' · '))} | <strong>Required:</strong> ${escapeHtml(p.requiredQuantity)}</p>
          <div>
            ${p.applicableEquationsLatex.map((eq) => `<div class="math-block">${renderFormulaToHtml(eq, true)}</div>`).join('')}
          </div>
          <ol>
            ${p.steps.map((st) => `<li>${renderMathToHtml(st)}</li>`).join('')}
          </ol>
          <p class="small"><strong>Final Answer:</strong> <span class="answer-highlight">${escapeHtml(p.finalAnswer)}</span> · <span class="muted">Strategy: ${escapeHtml(p.strategyExplanation)}</span></p>
        </article>`
        )
        .join('\n');

      const formulasHtml = ch.formulas
        .map(
          (f) => `
        <div class="formula-card">
          <div class="topic-head">
            <p class="formula-label">${escapeHtml(f.name)}</p>
            <span class="mono tiny">${escapeHtml(f.dimensions)}</span>
          </div>
          <div class="math-block">${renderFormulaToHtml(f.latex, true)}</div>
          <p class="tiny muted">SI Unit: <span class="mono">${escapeHtml(f.siUnit)}</span> · ${escapeHtml(f.interpretation)}</p>
        </div>`
        )
        .join('\n');

      return `
      <section class="chapter-section" id="chapter-${escapeHtml(ch.id)}" data-chapter-search="${escapeHtml(`${ch.number} ${ch.title} ${ch.unitGroup} ${ch.overview}`.toLowerCase())}">
        <header class="chapter-banner">
          <div class="chapter-meta">
            <span>Chapter ${String(ch.number).padStart(2, '0')} · ${escapeHtml(ch.unitGroup)}</span>
            <span>NCERT ${escapeHtml(ch.ncertWeightage)} · JEE ${escapeHtml(ch.jeeWeightage)} · ~${ch.estimatedHours} hrs</span>
          </div>
          <h2>${ch.number}. ${escapeHtml(ch.title)}</h2>
          <p>${escapeHtml(ch.overview)}</p>
        </header>

        ${hierarchyHtml}

        <div class="card-section">
          <h3>Textbook Subtopic Modules (Sections A–Q)</h3>
          ${subtopicsHtml}
        </div>

        <div class="card-section">
          <h3>F. Mathematical Derivation Engine (${ch.derivations.length})</h3>
          ${derivationsHtml}
        </div>

        <div class="card-section">
          <h3>N. Solved Problem Library (${ch.solvedProblems.length})</h3>
          ${problemsHtml}
        </div>

        <div class="card-section">
          <h3>Chapter Formula Sheet (${ch.formulas.length})</h3>
          <div class="formula-grid">${formulasHtml}</div>
        </div>
      </section>`;
    })
    .join('\n');

  const questionsHtml = questions
    .map((q) => {
      const dbLabel =
        q.databaseCategory === 'A_VERIFIED_PYQ'
          ? 'Database A · Verified Historical PYQ'
          : q.databaseCategory === 'B_AI_ORIGINAL'
            ? 'Database B · Original AI Practice'
            : 'Database C · PYQ-Inspired';
      const ansText =
        q.numericalAnswer !== undefined
          ? `${q.numericalAnswer}${q.unit ? ` ${q.unit}` : ''}`
          : q.options && q.correctOptionIndices
            ? q.correctOptionIndices.map((idx) => `${String.fromCharCode(65 + idx)}`).join(', ')
            : 'See solution';

      return `
      <article class="problem-card qbank-item" data-qbank-search="${escapeHtml(`${q.chapterId} ${q.exam} ${q.year} ${q.prompt}`.toLowerCase())}">
        <div class="topic-head">
          <span class="small muted">${escapeHtml(dbLabel)} · ${escapeHtml(q.exam)} (${q.year}${q.paper ? `, ${escapeHtml(q.paper)}` : ''})</span>
          <span class="tag ${q.databaseCategory === 'A_VERIFIED_PYQ' ? 'tag-navy' : 'tag-cyan'}">${escapeHtml(q.chapterId.toUpperCase())}</span>
        </div>
        <p class="problem-stmt">${renderMathToHtml(q.prompt)}</p>
        ${
          q.options && q.options.length > 0
            ? `<ol type="A" class="options-list">${q.options.map((o) => `<li>${renderMathToHtml(o)}</li>`).join('')}</ol>`
            : ''
        }
        <details class="qa-details">
          <summary>View Answer &amp; Solution (Ans: ${escapeHtml(ansText)})</summary>
          <p>${renderMathToHtml(q.solution)}</p>
          <p class="tiny muted">${escapeHtml(q.sourceCitation)} · ${escapeHtml(q.copyrightNote)}</p>
        </details>
      </article>`;
    })
    .join('\n');

  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>MASTER JEE – Class 11 Physics (Complete Standalone HTML Edition)</title>
  <meta name="description" content="Complete 14-chapter Class 11 Physics digital textbook, NCERT &amp; JEE syllabus hierarchy, mathematical derivations, solved problems, formula sheets, and verified question archive by Dr. V. Sesha Sai Kumar (GRIET, Hyderabad)." />
  <style>
    ${katexCss}
    :root {
      --navy: #0B1F3A;
      --navy-2: #132D52;
      --cyan: #0891B2;
      --bg: #F8FAFC;
      --card: #FFFFFF;
      --border: #E2E8F0;
      --text: #0F172A;
      --muted: #475569;
    }
    * { box-sizing: border-box; }
    html { scroll-behavior: smooth; }
    body {
      margin: 0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Plus Jakarta Sans", Arial, sans-serif;
      background: var(--bg);
      color: var(--text);
      line-height: 1.6;
    }
    .mono { font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; }
    .small { font-size: 0.875rem; }
    .tiny { font-size: 0.78rem; }
    .muted { color: var(--muted); }
    .topbar {
      position: sticky;
      top: 0;
      z-index: 40;
      background: var(--navy);
      color: #fff;
      border-bottom: 1px solid rgba(255,255,255,0.12);
      padding: 0.75rem 1.25rem;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 0.75rem;
    }
    .brand { font-weight: 700; font-size: 1rem; letter-spacing: -0.01em; }
    .brand small { display: block; font-weight: 400; font-size: 0.75rem; color: #A5F3FC; }
    .toolbar-actions { display: flex; flex-wrap: wrap; align-items: center; gap: 0.5rem; }
    .search-input {
      padding: 0.45rem 0.75rem;
      border-radius: 8px;
      border: 1px solid rgba(255,255,255,0.22);
      background: rgba(255,255,255,0.1);
      color: #fff;
      font-size: 0.85rem;
      min-width: 220px;
    }
    .search-input::placeholder { color: #CBD5E1; }
    .level-switcher {
      display: inline-flex;
      background: rgba(255,255,255,0.1);
      padding: 3px;
      border-radius: 8px;
      gap: 3px;
    }
    .level-btn, .print-btn {
      border: 0;
      border-radius: 6px;
      padding: 0.4rem 0.7rem;
      font-size: 0.78rem;
      font-weight: 600;
      cursor: pointer;
    }
    .level-btn { background: transparent; color: #E2E8F0; }
    .level-btn.active { background: #06B6D4; color: var(--navy); }
    .print-btn { background: #fff; color: var(--navy); }
    .shell {
      max-width: 1380px;
      margin: 0 auto;
      padding: 1.5rem 1rem 3rem;
      display: grid;
      grid-template-columns: 270px minmax(0, 1fr);
      gap: 1.5rem;
    }
    .sidebar {
      position: sticky;
      top: 4.75rem;
      align-self: start;
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 0.9rem;
      max-height: calc(100vh - 6rem);
      overflow-y: auto;
    }
    .sidebar-title {
      font-size: 0.75rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.04em;
      color: var(--muted);
      margin: 0 0 0.5rem;
    }
    .toc-link {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.42rem 0.55rem;
      border-radius: 7px;
      text-decoration: none;
      color: var(--text);
      font-size: 0.82rem;
      font-weight: 500;
    }
    .toc-link:hover { background: #F1F5F9; }
    .toc-num {
      font-family: ui-monospace, monospace;
      font-size: 0.74rem;
      font-weight: 700;
      color: var(--cyan);
      width: 1.5rem;
      flex-shrink: 0;
    }
    .hero {
      background: linear-gradient(135deg, var(--navy), #102B4F);
      color: #fff;
      border-radius: 14px;
      padding: 1.75rem;
      margin-bottom: 1.5rem;
    }
    .hero h1 { margin: 0.25rem 0 0.5rem; font-size: 1.75rem; line-height: 1.2; }
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
      gap: 0.75rem;
      margin-top: 1.25rem;
    }
    .stat-card {
      background: rgba(255,255,255,0.08);
      border: 1px solid rgba(255,255,255,0.14);
      border-radius: 10px;
      padding: 0.75rem 0.9rem;
    }
    .stat-val { font-size: 1.25rem; font-weight: 700; font-variant-numeric: tabular-nums; }
    .stat-lbl { font-size: 0.75rem; color: #CBD5E1; }
    .chapter-section {
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 14px;
      padding: 1.5rem;
      margin-bottom: 1.5rem;
    }
    .chapter-banner {
      border-bottom: 1px solid var(--border);
      padding-bottom: 1rem;
      margin-bottom: 1.25rem;
    }
    .chapter-meta {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      gap: 0.5rem;
      font-size: 0.78rem;
      font-weight: 600;
      color: var(--cyan);
    }
    .chapter-banner h2 { margin: 0.35rem 0; font-size: 1.45rem; color: var(--navy); }
    .card-section { margin-top: 1.5rem; }
    .card-section > h3 {
      font-size: 1.05rem;
      color: var(--navy);
      border-bottom: 1px solid #F1F5F9;
      padding-bottom: 0.4rem;
      margin-bottom: 0.9rem;
    }
    .topic-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 0.85rem; }
    .topic-box {
      border: 1px solid var(--border);
      border-radius: 10px;
      padding: 0.85rem;
      background: #F8FAFC;
    }
    .topic-box.is-enrichment { background: #FFFBEB; border-color: #FDE68A; }
    .topic-head {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 0.4rem;
    }
    .subtopic-list { margin: 0.5rem 0 0; padding-left: 1.1rem; font-size: 0.84rem; }
    .subtopic-list li { margin-bottom: 0.45rem; }
    .badge-row { display: inline-flex; flex-wrap: wrap; gap: 0.25rem; margin-left: 0.35rem; }
    .tag {
      display: inline-block;
      padding: 0.12rem 0.45rem;
      border-radius: 4px;
      font-size: 0.7rem;
      font-weight: 600;
      white-space: nowrap;
    }
    .tag-slate { background: #E2E8F0; color: #334155; }
    .tag-cyan { background: #ECFEFF; color: #155E75; border: 1px solid #A5F3FC; }
    .tag-navy { background: var(--navy); color: #fff; }
    .tag-amber { background: #FEF3C7; color: #92400E; border: 1px solid #FCD34D; }
    .subtopic-article {
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 1.15rem;
      margin-bottom: 1rem;
      background: #FFFFFF;
    }
    .subtopic-header h3 { margin: 0.3rem 0 0.75rem; font-size: 1.12rem; color: var(--navy); }
    .subtopic-article h4 { margin: 0.85rem 0 0.4rem; font-size: 0.9rem; color: var(--navy); }
    .two-col { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 1rem; }
    .three-col { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1rem; margin-top: 0.75rem; }
    .level-box {
      margin: 0.85rem 0;
      padding: 0.85rem 1rem;
      border-radius: 10px;
      background: #F0F9FF;
      border: 1px solid #BAE6FD;
    }
    .level-caption { font-size: 0.76rem; font-weight: 700; color: #0369A1; margin: 0 0 0.25rem; }
    .level-content { display: none; }
    .level-content.active { display: block; }
    .def-list { margin: 0; }
    .def-item { background: #F8FAFC; border: 1px solid var(--border); border-radius: 8px; padding: 0.55rem 0.75rem; margin-bottom: 0.45rem; }
    .def-item dt { font-weight: 700; font-size: 0.84rem; color: var(--navy); }
    .def-item dd { margin: 0.2rem 0 0; font-size: 0.86rem; }
    .formula-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 0.75rem; }
    .formula-card { border: 1px solid var(--border); border-radius: 10px; padding: 0.75rem; background: #F8FAFC; }
    .formula-label { margin: 0 0 0.25rem; font-size: 0.82rem; font-weight: 700; color: #155E75; }
    .math-block {
      margin: 0.35rem 0;
      padding: 0.45rem 0.65rem;
      background: #fff;
      border: 1px solid var(--border);
      border-radius: 8px;
      overflow-x: auto;
    }
    .table-wrap { overflow-x: auto; border: 1px solid var(--border); border-radius: 8px; }
    table { width: 100%; border-collapse: collapse; font-size: 0.83rem; }
    th, td { text-align: left; padding: 0.5rem 0.75rem; border-bottom: 1px solid #F1F5F9; }
    thead { background: #F8FAFC; color: var(--muted); }
    .trap-box { background: #FFFBEB; border: 1px solid #FDE68A; border-radius: 8px; padding: 0.55rem 0.7rem; font-size: 0.82rem; margin-bottom: 0.45rem; }
    .trap-box p { margin: 0.15rem 0; }
    .qa-details { border: 1px solid var(--border); border-radius: 8px; padding: 0.6rem 0.8rem; background: #F8FAFC; margin-bottom: 0.5rem; font-size: 0.86rem; }
    .qa-details summary { cursor: pointer; font-weight: 600; color: var(--navy); }
    .summary-box, .schematic-note { border: 1px solid var(--border); border-radius: 8px; padding: 0.7rem 0.85rem; background: #F8FAFC; font-size: 0.85rem; }
    .problem-card { border: 1px solid var(--border); border-radius: 10px; padding: 0.9rem 1rem; margin-bottom: 0.75rem; background: #fff; }
    .problem-stmt { font-weight: 600; color: var(--navy); margin: 0.45rem 0; }
    .answer-highlight { color: #047857; font-weight: 700; }
    .final-eq { background: var(--navy); color: #fff; border-radius: 8px; padding: 0.75rem; margin: 0.6rem 0; }
    .final-eq .math-block { background: rgba(255,255,255,0.1); border-color: rgba(255,255,255,0.2); color: #fff; }
    .worked-box { background: #ECFEFF; border: 1px solid #A5F3FC; border-radius: 8px; padding: 0.7rem; }
    .options-list { padding-left: 1.35rem; margin: 0.4rem 0 0.65rem; font-size: 0.88rem; }
    .hidden-by-filter { display: none !important; }
    footer { text-align: center; color: var(--muted); font-size: 0.8rem; padding: 1.5rem 1rem; border-top: 1px solid var(--border); background: #fff; }
    @media (max-width: 960px) {
      .shell { grid-template-columns: 1fr; }
      .sidebar { position: static; max-height: none; }
    }
    @media print {
      .topbar, .sidebar { display: none !important; }
      .shell { display: block; padding: 0; }
      .chapter-section { break-inside: avoid-page; border-color: #CBD5E1; }
    }
  </style>
</head>
<body>
  <header class="topbar">
    <div class="brand">
      MASTER JEE – CLASS 11 PHYSICS
      <small>Understand Physics. Master Concepts. Crack IIT JEE. · Dr. V. Sesha Sai Kumar (GRIET, Hyderabad)</small>
    </div>
    <div class="toolbar-actions">
      <input type="search" id="htmlSearch" class="search-input" placeholder="Search chapters, formulas, PYQs..." aria-label="Search project HTML" />
      <div class="level-switcher" role="group" aria-label="Academic level selector">
        <button type="button" class="level-btn" data-set-level="foundation">Foundation</button>
        <button type="button" class="level-btn active" data-set-level="jee_main">JEE Main</button>
        <button type="button" class="level-btn" data-set-level="jee_advanced">JEE Advanced</button>
      </div>
      <button type="button" class="print-btn" onclick="window.print()">Print / Save PDF</button>
    </div>
  </header>

  <div class="shell">
    <aside class="sidebar" aria-label="Chapter Table of Contents">
      <p class="sidebar-title">14-Chapter Syllabus</p>
      ${sidebarLinksHtml}
      <hr style="border:0;border-top:1px solid var(--border);margin:0.65rem 0;" />
      <a class="toc-link" href="#question-bank">
        <span class="toc-num">QB</span>
        <span class="toc-title">PYQ &amp; Practice Archive (${questions.length})</span>
      </a>
    </aside>

    <main>
      <section class="hero">
        <p class="tiny" style="margin:0;color:#67E8F9;font-weight:600;">COMPLETE STANDALONE PROJECT HTML EXPORT</p>
        <h1>MASTER JEE – Class 11 Physics</h1>
        <p style="margin:0;max-width:760px;color:#E2E8F0;">
          Academically Directed by <strong>Dr. V. Sesha Sai Kumar</strong>, Gokaraju Rangaraju Institute of Engineering and Technology (GRIET), Hyderabad, India.
          Self-contained digital textbook covering the complete 14-chapter NCERT &amp; IIT-JEE curriculum, mathematical derivations, solved numerical problems, formula sheets, and verified question archive.
        </p>
        <div class="stats-grid">
          <div class="stat-card"><div class="stat-val">${stats.chapterCount}</div><div class="stat-lbl">NCERT &amp; JEE Chapters</div></div>
          <div class="stat-card"><div class="stat-val">${stats.topicCount} / ${stats.subtopicCount}</div><div class="stat-lbl">Topics / Subtopics</div></div>
          <div class="stat-card"><div class="stat-val">${totalDerivations}</div><div class="stat-lbl">Step-by-Step Derivations</div></div>
          <div class="stat-card"><div class="stat-val">${totalSolved}</div><div class="stat-lbl">Solved Numericals</div></div>
          <div class="stat-card"><div class="stat-val">${totalFormulas}</div><div class="stat-lbl">Formula Reference Cards</div></div>
          <div class="stat-card"><div class="stat-val">${questions.length}</div><div class="stat-lbl">Question Bank Items</div></div>
        </div>
      </section>

      ${chaptersHtml}

      <section class="chapter-section" id="question-bank">
        <header class="chapter-banner">
          <div class="chapter-meta">
            <span>3-Database Separated Question Archive</span>
            <span>Database A: Verified Historical PYQs · Database B: Original AI Practice · Database C: PYQ-Inspired</span>
          </div>
          <h2>Question Bank &amp; Historical PYQ Archive (${questions.length} Questions)</h2>
          <p>Official examination citations are preserved strictly for Database A; original practice modules are labeled separately.</p>
        </header>
        ${questionsHtml}
      </section>
    </main>
  </div>

  <footer>
    MASTER JEE – Class 11 Physics · Academically Directed by Dr. V. Sesha Sai Kumar (GRIET, Hyderabad) · Generated ${escapeHtml(generatedAtIso.slice(0, 10))}
  </footer>

  <script>
    (function () {
      var activeLevel = 'jee_main';
      function applyLevel(lvl) {
        activeLevel = lvl;
        document.querySelectorAll('[data-set-level]').forEach(function (btn) {
          btn.classList.toggle('active', btn.getAttribute('data-set-level') === lvl);
        });
        document.querySelectorAll('.level-content').forEach(function (el) {
          el.classList.toggle('active', el.getAttribute('data-level') === lvl);
        });
      }
      document.querySelectorAll('[data-set-level]').forEach(function (btn) {
        btn.addEventListener('click', function () {
          applyLevel(btn.getAttribute('data-set-level') || 'jee_main');
        });
      });
      applyLevel(activeLevel);

      var searchEl = document.getElementById('htmlSearch');
      if (searchEl) {
        searchEl.addEventListener('input', function () {
          var q = (searchEl.value || '').trim().toLowerCase();
          document.querySelectorAll('.chapter-section[data-chapter-search]').forEach(function (sec) {
            var text = (sec.textContent || '').toLowerCase();
            sec.classList.toggle('hidden-by-filter', Boolean(q) && text.indexOf(q) === -1);
          });
          document.querySelectorAll('.qbank-item').forEach(function (item) {
            var text = (item.textContent || '').toLowerCase();
            item.classList.toggle('hidden-by-filter', Boolean(q) && text.indexOf(q) === -1);
          });
        });
      }
    })();
  </script>
</body>
</html>`;
}
