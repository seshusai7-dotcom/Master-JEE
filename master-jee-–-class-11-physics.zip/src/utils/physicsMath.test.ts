import test from 'node:test';
import assert from 'node:assert/strict';
import {
  addDimensions,
  subtractDimensions,
  areDimensionsEqual,
  formatDimensions,
  verifyNumericalAnswer,
  evaluateQuizSubmission,
  computeNextFlashcardReview,
  computeVectorResultant,
  computeProjectileMetrics,
  computeInclinedFriction,
  computePendulumMetrics,
  computeSpringMassMetrics,
  computeElasticCollision1D,
  computeBernoulliPipe,
} from './physicsMath';
import type { QuestionEntry } from '../types/physics';

test('dimensional consistency verifies kinetic energy and work equivalence', () => {
  const force = { M: 1, L: 1, T: -2, I: 0, Theta: 0, N: 0, J: 0 };
  const displacement = { M: 0, L: 1, T: 0, I: 0, Theta: 0, N: 0, J: 0 };
  const work = addDimensions(force, displacement);
  const mass = { M: 1, L: 0, T: 0, I: 0, Theta: 0, N: 0, J: 0 };
  const velocitySq = { M: 0, L: 2, T: -2, I: 0, Theta: 0, N: 0, J: 0 };
  const ke = addDimensions(mass, velocitySq);
  assert.equal(areDimensionsEqual(work, ke), true);
  assert.equal(formatDimensions(work), '[M^{1} L^{2} T^{-2}]');

  const power = subtractDimensions(work, { M: 0, L: 0, T: 1, I: 0, Theta: 0, N: 0, J: 0 });
  assert.equal(power.T, -3);
});

test('numerical answer verification respects tolerance', () => {
  assert.equal(verifyNumericalAnswer(9.81, 9.8, 0.02), true);
  assert.equal(verifyNumericalAnswer(10.5, 9.8, 0.02), false);
});

test('JEE quiz evaluation computes positive, negative, accuracy, and weak topics', () => {
  const questions: QuestionEntry[] = [
    {
      id: 'q1',
      databaseCategory: 'B_AI_ORIGINAL',
      chapterId: 'ch1',
      topicId: 'errors',
      exam: 'Practice',
      year: 2026,
      format: 'single_mcq',
      difficulty: 'jee_main',
      prompt: 'Test 1',
      options: ['A', 'B', 'C', 'D'],
      correctOptionIndices: [1],
      solution: 'B',
      sourceCitation: 'Original AI-Generated',
      verified: true,
      copyrightNote: 'Original',
    },
    {
      id: 'q2',
      databaseCategory: 'B_AI_ORIGINAL',
      chapterId: 'ch1',
      topicId: 'dimensions',
      exam: 'Practice',
      year: 2026,
      format: 'single_mcq',
      difficulty: 'jee_main',
      prompt: 'Test 2',
      options: ['A', 'B', 'C', 'D'],
      correctOptionIndices: [0],
      solution: 'A',
      sourceCitation: 'Original AI-Generated',
      verified: true,
      copyrightNote: 'Original',
    },
    {
      id: 'q3',
      databaseCategory: 'B_AI_ORIGINAL',
      chapterId: 'ch1',
      topicId: 'vernier',
      exam: 'Practice',
      year: 2026,
      format: 'numerical',
      difficulty: 'jee_main',
      prompt: 'Test 3',
      numericalAnswer: 12.4,
      numericalTolerance: 0.05,
      solution: '12.4',
      sourceCitation: 'Original AI-Generated',
      verified: true,
      copyrightNote: 'Original',
    },
  ];

  const result = evaluateQuizSubmission(
    questions,
    {
      q1: { selectedOptionIndices: [1] }, // +4
      q2: { selectedOptionIndices: [2] }, // -1
      q3: { numericalInput: '' }, // unattempted 0
    },
    { positiveMarks: 4, negativeMarks: 1 }
  );

  assert.equal(result.score, 3);
  assert.equal(result.maxScore, 12);
  assert.equal(result.correctCount, 1);
  assert.equal(result.wrongCount, 1);
  assert.equal(result.unattemptedCount, 1);
  assert.equal(result.accuracyPct, 50);
  assert.deepEqual(result.weakTopics, ['dimensions']);
});

test('spaced repetition advances and resets boxes accurately', () => {
  const now = 1_700_000_000_000;
  const good = computeNextFlashcardReview(2, 'good', now);
  assert.equal(good.box, 3);
  assert.ok(good.nextReviewEpochMs > now);

  const reset = computeNextFlashcardReview(4, 'again', now);
  assert.equal(reset.box, 1);
});

test('physics lab solvers produce exact textbook results', () => {
  // 3-4-5 vector triangle at 0 and 90 deg
  const vec = computeVectorResultant(3, 0, 4, 90);
  assert.ok(Math.abs(vec.resultantMag - 5) < 1e-9);
  assert.ok(Math.abs(vec.dotProduct - 0) < 1e-9);
  assert.ok(Math.abs(vec.crossZ - 12) < 1e-9);

  // Projectile at 45 deg, v0 = 9.8 m/s -> Range = v0^2 / g = 9.8 m
  const proj = computeProjectileMetrics(9.8, 45, 9.8, 0);
  assert.ok(Math.abs(proj.range - 9.8) < 1e-6);
  assert.ok(Math.abs(proj.maxHeight - 2.45) < 1e-6);

  // Inclined plane: angle 30 deg, mu_s = 0.7 -> tan(30)=0.577 < 0.7 -> static
  const inclineStatic = computeInclinedFriction(10, 30, 0.7, 0.5, 9.8);
  assert.equal(inclineStatic.isSliding, false);
  assert.equal(inclineStatic.acceleration, 0);

  // Inclined plane: angle 45 deg, mu_s = 0.5 -> slides
  const inclineSlide = computeInclinedFriction(10, 45, 0.5, 0.4, 9.8);
  assert.equal(inclineSlide.isSliding, true);
  assert.ok(inclineSlide.acceleration > 0);

  // Pendulum L = g / (4 pi^2) => T = 1s
  const pend = computePendulumMetrics(9.81 / (4 * Math.PI * Math.PI), 9.81, 5);
  assert.ok(Math.abs(pend.periodSec - 1) < 1e-6);

  // Spring-mass: m = 1 kg, k = 4 pi^2 N/m => T = 1s
  const spring = computeSpringMassMetrics(1, 4 * Math.PI * Math.PI, 0.1);
  assert.ok(Math.abs(spring.periodSec - 1) < 1e-6);

  // Equal mass elastic head-on collision swaps velocities
  const col = computeElasticCollision1D(2, 5, 2, 0, 1);
  assert.ok(Math.abs(col.v1 - 0) < 1e-9);
  assert.ok(Math.abs(col.v2 - 5) < 1e-9);
  assert.ok(Math.abs(col.keLoss) < 1e-9);

  // Bernoulli continuity: halving diameter quadruples velocity
  const bern = computeBernoulliPipe(200000, 2, 0.2, 0.1, 0, 0, 1000, 9.81);
  assert.ok(Math.abs(bern.v2 - 8) < 1e-6);
  assert.ok(bern.p2Pa < 200000);
});
