import type { QuestionEntry } from '../types/physics';

export interface DimensionVector {
  M: number;
  L: number;
  T: number;
  I: number;
  Theta: number;
  N: number;
  J: number;
}

export function createZeroDimensions(): DimensionVector {
  return { M: 0, L: 0, T: 0, I: 0, Theta: 0, N: 0, J: 0 };
}

export function addDimensions(a: DimensionVector, b: DimensionVector): DimensionVector {
  return {
    M: a.M + b.M,
    L: a.L + b.L,
    T: a.T + b.T,
    I: a.I + b.I,
    Theta: a.Theta + b.Theta,
    N: a.N + b.N,
    J: a.J + b.J,
  };
}

export function subtractDimensions(a: DimensionVector, b: DimensionVector): DimensionVector {
  return {
    M: a.M - b.M,
    L: a.L - b.L,
    T: a.T - b.T,
    I: a.I - b.I,
    Theta: a.Theta - b.Theta,
    N: a.N - b.N,
    J: a.J - b.J,
  };
}

export function areDimensionsEqual(a: DimensionVector, b: DimensionVector): boolean {
  return (
    a.M === b.M &&
    a.L === b.L &&
    a.T === b.T &&
    a.I === b.I &&
    a.Theta === b.Theta &&
    a.N === b.N &&
    a.J === b.J
  );
}

export function formatDimensions(d: DimensionVector): string {
  const parts: string[] = [];
  if (d.M !== 0) parts.push(`M^{${d.M}}`);
  if (d.L !== 0) parts.push(`L^{${d.L}}`);
  if (d.T !== 0) parts.push(`T^{${d.T}}`);
  if (d.I !== 0) parts.push(`A^{${d.I}}`);
  if (d.Theta !== 0) parts.push(`K^{${d.Theta}}`);
  if (d.N !== 0) parts.push(`mol^{${d.N}}`);
  if (d.J !== 0) parts.push(`cd^{${d.J}}`);
  if (parts.length === 0) return '[M^0 L^0 T^0]';
  return `[${parts.join(' ')}]`;
}

export function verifyNumericalAnswer(
  studentValue: number,
  expectedValue: number,
  tolerance = 0.02
): boolean {
  if (!Number.isFinite(studentValue) || !Number.isFinite(expectedValue)) return false;
  return Math.abs(studentValue - expectedValue) <= Math.max(tolerance, Math.abs(expectedValue) * 0.01);
}

export interface AnswerSubmission {
  selectedOptionIndices?: number[];
  numericalInput?: string;
}

export interface QuizEvaluationResult {
  score: number;
  maxScore: number;
  correctCount: number;
  wrongCount: number;
  unattemptedCount: number;
  accuracyPct: number;
  weakTopics: string[];
  perQuestionCorrect: Record<string, boolean | null>;
}

export function evaluateQuizSubmission(
  questions: QuestionEntry[],
  answers: Record<string, AnswerSubmission>,
  options: { positiveMarks: number; negativeMarks: number }
): QuizEvaluationResult {
  let score = 0;
  let correctCount = 0;
  let wrongCount = 0;
  let unattemptedCount = 0;
  const weakTopicCounts: Record<string, number> = {};
  const perQuestionCorrect: Record<string, boolean | null> = {};

  for (const q of questions) {
    const sub = answers[q.id];
    const isNumerical = q.format === 'numerical' || q.format === 'integer';

    if (isNumerical) {
      const raw = sub?.numericalInput?.trim() ?? '';
      if (raw === '') {
        unattemptedCount += 1;
        perQuestionCorrect[q.id] = null;
        continue;
      }
      const parsed = Number(raw);
      const expected = q.numericalAnswer ?? 0;
      const tol = q.numericalTolerance ?? (q.format === 'integer' ? 0.001 : 0.05);
      const isRight = verifyNumericalAnswer(parsed, expected, tol);
      if (isRight) {
        score += options.positiveMarks;
        correctCount += 1;
        perQuestionCorrect[q.id] = true;
      } else {
        // Standard JEE numericals often have 0 negative, but respect configured negativeMarks if set
        score -= options.negativeMarks;
        wrongCount += 1;
        perQuestionCorrect[q.id] = false;
        weakTopicCounts[q.topicId] = (weakTopicCounts[q.topicId] || 0) + 1;
      }
    } else {
      const selected = [...(sub?.selectedOptionIndices ?? [])].sort((a, b) => a - b);
      if (selected.length === 0) {
        unattemptedCount += 1;
        perQuestionCorrect[q.id] = null;
        continue;
      }
      const expected = [...(q.correctOptionIndices ?? [0])].sort((a, b) => a - b);
      const exactMatch =
        selected.length === expected.length &&
        selected.every((v, idx) => v === expected[idx]);

      if (exactMatch) {
        score += options.positiveMarks;
        correctCount += 1;
        perQuestionCorrect[q.id] = true;
      } else {
        score -= options.negativeMarks;
        wrongCount += 1;
        perQuestionCorrect[q.id] = false;
        weakTopicCounts[q.topicId] = (weakTopicCounts[q.topicId] || 0) + 1;
      }
    }
  }

  const maxScore = questions.length * options.positiveMarks;
  const attempted = correctCount + wrongCount;
  const accuracyPct = attempted > 0 ? Math.round((correctCount / attempted) * 1000) / 10 : 0;
  const weakTopics = Object.entries(weakTopicCounts)
    .sort((a, b) => b[1] - a[1])
    .map(([topic]) => topic);

  return {
    score,
    maxScore,
    correctCount,
    wrongCount,
    unattemptedCount,
    accuracyPct,
    weakTopics,
    perQuestionCorrect,
  };
}

export type SpacedRating = 'again' | 'hard' | 'good' | 'easy';

export function computeNextFlashcardReview(
  currentBox: number,
  rating: SpacedRating,
  nowEpochMs = Date.now()
): { box: number; nextReviewEpochMs: number; intervalLabel: string } {
  let nextBox = currentBox;
  let hours = 1;

  if (rating === 'again') {
    nextBox = 1;
    hours = 0.25; // 15 minutes
  } else if (rating === 'hard') {
    nextBox = Math.max(1, currentBox);
    hours = 12;
  } else if (rating === 'good') {
    nextBox = Math.min(6, currentBox + 1);
    const boxHours = [0, 12, 24, 72, 168, 336, 720];
    hours = boxHours[nextBox] ?? 72;
  } else {
    nextBox = Math.min(6, currentBox + 2);
    const boxHours = [0, 24, 72, 168, 336, 720, 1440];
    hours = boxHours[nextBox] ?? 168;
  }

  const intervalLabel =
    hours < 1
      ? `${Math.round(hours * 60)} min`
      : hours < 24
        ? `${hours} hrs`
        : `${Math.round(hours / 24)} days`;

  return {
    box: nextBox,
    nextReviewEpochMs: nowEpochMs + Math.round(hours * 3600 * 1000),
    intervalLabel,
  };
}

// ==========================================
// Scientific Physics Virtual Lab Solvers
// ==========================================

export function computeVectorResultant(
  magA: number,
  angleADeg: number,
  magB: number,
  angleBDeg: number
) {
  const radA = (angleADeg * Math.PI) / 180;
  const radB = (angleBDeg * Math.PI) / 180;
  const ax = magA * Math.cos(radA);
  const ay = magA * Math.sin(radA);
  const bx = magB * Math.cos(radB);
  const by = magB * Math.sin(radB);
  const rx = ax + bx;
  const ry = ay + by;
  const resultantMag = Math.hypot(rx, ry);
  const resultantAngleDeg = (Math.atan2(ry, rx) * 180) / Math.PI;
  const dotProduct = ax * bx + ay * by;
  const crossZ = ax * by - ay * bx;
  return { ax, ay, bx, by, rx, ry, resultantMag, resultantAngleDeg, dotProduct, crossZ };
}

export function computeProjectileMetrics(v0: number, angleDeg: number, g = 9.8, h0 = 0) {
  const theta = (angleDeg * Math.PI) / 180;
  const vx = v0 * Math.cos(theta);
  const vy0 = v0 * Math.sin(theta);
  const timeToApex = vy0 / g;
  const maxHeight = h0 + (vy0 * vy0) / (2 * g);
  const totalTime = (vy0 + Math.sqrt(vy0 * vy0 + 2 * g * h0)) / g;
  const range = vx * totalTime;
  return { vx, vy0, timeToApex, maxHeight, totalTime, range };
}

export function computeInclinedFriction(
  massKg: number,
  angleDeg: number,
  muStatic: number,
  muKinetic: number,
  g = 9.8
) {
  const rad = (angleDeg * Math.PI) / 180;
  const normal = massKg * g * Math.cos(rad);
  const drivingForce = massKg * g * Math.sin(rad);
  const maxStaticFriction = muStatic * normal;
  const isSliding = drivingForce > maxStaticFriction;
  const frictionForce = isSliding ? muKinetic * normal : drivingForce;
  const netForce = isSliding ? drivingForce - frictionForce : 0;
  const acceleration = netForce / massKg;
  const angleOfReposeDeg = (Math.atan(muStatic) * 180) / Math.PI;
  return { normal, drivingForce, maxStaticFriction, frictionForce, isSliding, acceleration, angleOfReposeDeg };
}

export function computePendulumMetrics(lengthM: number, g = 9.81, thetaMaxDeg = 10) {
  const periodSec = 2 * Math.PI * Math.sqrt(lengthM / g);
  const frequencyHz = 1 / periodSec;
  const omega = Math.sqrt(g / lengthM);
  const thetaMaxRad = (thetaMaxDeg * Math.PI) / 180;
  const maxSpeed = omega * lengthM * thetaMaxRad;
  return { periodSec, frequencyHz, omega, maxSpeed };
}

export function computeSpringMassMetrics(massKg: number, kNPerM: number, amplitudeM: number) {
  const omega = Math.sqrt(kNPerM / massKg);
  const periodSec = (2 * Math.PI) / omega;
  const frequencyHz = 1 / periodSec;
  const maxVelocity = omega * amplitudeM;
  const maxAcceleration = omega * omega * amplitudeM;
  const totalEnergyJ = 0.5 * kNPerM * amplitudeM * amplitudeM;
  return { omega, periodSec, frequencyHz, maxVelocity, maxAcceleration, totalEnergyJ };
}

export function computeElasticCollision1D(m1: number, u1: number, m2: number, u2: number, e = 1) {
  const v1 = ((m1 - e * m2) * u1 + (1 + e) * m2 * u2) / (m1 + m2);
  const v2 = ((m2 - e * m1) * u2 + (1 + e) * m1 * u1) / (m1 + m2);
  const keBefore = 0.5 * m1 * u1 * u1 + 0.5 * m2 * u2 * u2;
  const keAfter = 0.5 * m1 * v1 * v1 + 0.5 * m2 * v2 * v2;
  return { v1, v2, keBefore, keAfter, keLoss: keBefore - keAfter };
}

export function computeBernoulliPipe(
  p1Pa: number,
  v1: number,
  d1M: number,
  d2M: number,
  h1M: number,
  h2M: number,
  rho = 1000,
  g = 9.81
) {
  const area1 = Math.PI * (d1M / 2) ** 2;
  const area2 = Math.PI * (d2M / 2) ** 2;
  const flowRate = area1 * v1;
  const v2 = flowRate / area2;
  const p2Pa = p1Pa + 0.5 * rho * (v1 * v1 - v2 * v2) + rho * g * (h1M - h2M);
  return { area1, area2, flowRate, v2, p2Pa };
}
