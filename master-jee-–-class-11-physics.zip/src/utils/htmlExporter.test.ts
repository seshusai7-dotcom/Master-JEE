import test from 'node:test';
import assert from 'node:assert/strict';
import { buildProjectHtmlDocument, renderMathToHtml } from './htmlExporter';
import { ALL_CHAPTERS } from '../data/curriculumIndex';
import { SYLLABUS_HIERARCHY } from '../data/syllabusHierarchy';
import { QUESTION_BANK } from '../data/questionBank';

test('renderMathToHtml escapes raw HTML while rendering KaTeX math expressions', () => {
  const rendered = renderMathToHtml('Force <script>alert(1)</script> satisfies $F = ma$ and $$E = mc^2$$');
  assert.ok(!rendered.includes('<script>'));
  assert.ok(rendered.includes('&lt;script&gt;'));
  assert.ok(rendered.includes('katex'));
});

test('buildProjectHtmlDocument emits valid standalone HTML with all 14 chapters and controls', () => {
  const html = buildProjectHtmlDocument({
    chapters: ALL_CHAPTERS,
    syllabus: SYLLABUS_HIERARCHY,
    questions: QUESTION_BANK,
    generatedAtIso: '2026-11-16T00:00:00.000Z',
  });

  assert.ok(html.startsWith('<!doctype html>'));
  assert.ok(html.includes('MASTER JEE – Class 11 Physics'));
  assert.ok(html.includes('Dr. V. Sesha Sai Kumar'));
  assert.ok(html.includes('id="htmlSearch"'));
  assert.ok(html.includes('data-set-level="jee_advanced"'));

  for (const ch of ALL_CHAPTERS) {
    assert.ok(
      html.includes(`id="chapter-${ch.id}"`),
      `Expected chapter anchor chapter-${ch.id} in generated HTML`
    );
  }
});
