import { useState } from 'react';
import {
  LayoutDashboard,
  BookOpen,
  Network,
  Calculator,
  Archive,
  Brain,
  Sparkles,
  ClipboardCheck,
  FlaskConical,
  Layers,
  BarChart3,
  User,
  ShieldCheck,
  Menu,
  X,
} from 'lucide-react';
import { AppProvider, useApp } from './context/AppContext';
import { SplashAuthGate } from './components/SplashAuthGate';
import { StudentDashboard } from './components/StudentDashboard';
import { ChapterExplorer } from './components/ChapterExplorer';
import { ChapterReader } from './components/ChapterReader';
import { MindMapView } from './components/MindMapView';
import { FormulaLibrary } from './components/FormulaLibrary';
import { PyqArchive } from './components/PyqArchive';
import { AiTutorView } from './components/AiTutorView';
import { AiPracticeGenerator } from './components/AiPracticeGenerator';
import { QuizMockEngine } from './components/QuizMockEngine';
import { VirtualLab } from './components/VirtualLab';
import { FlashcardsRevision } from './components/FlashcardsRevision';
import { AnalyticsView } from './components/AnalyticsView';
import { ProfileView } from './components/ProfileView';
import { AdminDashboard } from './components/AdminDashboard';
import type { AppScreen } from './types/physics';

const NAV_ITEMS: { id: AppScreen; label: string; icon: typeof LayoutDashboard }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'chapters', label: 'Syllabus (14 Ch)', icon: BookOpen },
  { id: 'reader', label: 'Textbook', icon: BookOpen },
  { id: 'mindmap', label: 'Mind Maps', icon: Network },
  { id: 'formulas', label: 'Formulas', icon: Calculator },
  { id: 'pyqs', label: '40-Yr PYQs', icon: Archive },
  { id: 'tutor', label: 'AI Tutor', icon: Brain },
  { id: 'ai_generator', label: 'AI Practice', icon: Sparkles },
  { id: 'quiz', label: 'Mock Tests', icon: ClipboardCheck },
  { id: 'lab', label: 'Virtual Lab', icon: FlaskConical },
  { id: 'flashcards', label: 'Revision', icon: Layers },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  { id: 'profile', label: 'Profile', icon: User },
];

function MainShell() {
  const { authMode, activeScreen, setActiveScreen, profile } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  if (authMode === 'unauthenticated') {
    return <SplashAuthGate />;
  }

  const navigateTo = (screen: AppScreen) => {
    setActiveScreen(screen);
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#0F172A] flex flex-col">
      {/* Clean 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-30 bg-[#0B1F3A] text-white border-b border-white/10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 h-14 flex items-center justify-between gap-8">
          {/* Zone 1: Single-line Brand */}
          <button
            type="button"
            onClick={() => navigateTo('dashboard')}
            className="text-base font-bold tracking-tight text-white whitespace-nowrap shrink-0 text-left"
          >
            MASTER JEE · Physics 11
          </button>

          {/* Zone 2: 5 concise single-line primary nav links */}
          <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-200">
            {(
              [
                { id: 'dashboard', label: 'Dashboard' },
                { id: 'chapters', label: 'Chapters' },
                { id: 'lab', label: 'Virtual Lab' },
                { id: 'pyqs', label: 'PYQ Bank' },
                { id: 'quiz', label: 'Mock Tests' },
              ] as const
            ).map((link) => (
              <button
                key={link.id}
                type="button"
                onClick={() => navigateTo(link.id)}
                className={`whitespace-nowrap shrink-0 transition-colors hover:text-white ${
                  activeScreen === link.id ? 'text-cyan-300 underline underline-offset-4' : ''
                }`}
              >
                {link.label}
              </button>
            ))}
          </nav>

          {/* Zone 3: 1 Primary Action + Mobile Drawer Toggle */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => navigateTo('tutor')}
              className="px-3.5 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-[#0B1F3A] text-xs font-bold whitespace-nowrap shrink-0"
            >
              Ask AI Tutor
            </button>
            <button
              type="button"
              aria-label="Toggle navigation menu"
              onClick={() => setMobileMenuOpen((v) => !v)}
              className="lg:hidden p-2 rounded-lg hover:bg-white/10"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-x-0 top-14 z-20 bg-white border-b border-slate-200 shadow-lg p-4 grid grid-cols-2 gap-2 max-h-[75vh] overflow-y-auto">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => navigateTo(item.id)}
                className={`flex items-center gap-2 px-3 py-2.5 rounded-lg text-xs font-semibold text-left ${
                  activeScreen === item.id
                    ? 'bg-[#0B1F3A] text-white'
                    : 'bg-slate-50 text-slate-700'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
          {profile.role === 'admin' && (
            <button
              type="button"
              onClick={() => navigateTo('admin')}
              className="col-span-2 flex items-center gap-2 px-3 py-2.5 rounded-lg text-xs font-semibold bg-cyan-50 text-cyan-900 border border-cyan-200"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Teacher / Admin Console</span>
            </button>
          )}
        </div>
      )}

      {/* Workspace Body: Desktop Sidebar + Main Content */}
      <div className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 py-6 pb-24 lg:pb-8 flex gap-6">
        <aside className="hidden lg:flex w-56 shrink-0 flex-col justify-between">
          <nav aria-label="Full curriculum navigation" className="space-y-1 sticky top-20">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const active = activeScreen === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => navigateTo(item.id)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                    active
                      ? 'bg-[#0B1F3A] text-white'
                      : 'text-slate-700 hover:bg-slate-200/70'
                  }`}
                >
                  <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-cyan-300' : 'text-slate-500'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}

            {profile.role === 'admin' && (
              <button
                type="button"
                onClick={() => navigateTo('admin')}
                className={`w-full mt-3 flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap border ${
                  activeScreen === 'admin'
                    ? 'bg-cyan-700 text-white border-cyan-700'
                    : 'bg-white text-cyan-900 border-cyan-200 hover:bg-cyan-50'
                }`}
              >
                <ShieldCheck className="w-4 h-4 shrink-0" />
                <span>Admin Console</span>
              </button>
            )}
          </nav>
        </aside>

        <main className="flex-1 min-w-0">
          {activeScreen === 'dashboard' && <StudentDashboard />}
          {activeScreen === 'chapters' && <ChapterExplorer />}
          {activeScreen === 'reader' && <ChapterReader />}
          {activeScreen === 'mindmap' && <MindMapView />}
          {activeScreen === 'formulas' && <FormulaLibrary />}
          {activeScreen === 'pyqs' && <PyqArchive />}
          {activeScreen === 'tutor' && <AiTutorView />}
          {activeScreen === 'ai_generator' && <AiPracticeGenerator />}
          {activeScreen === 'quiz' && <QuizMockEngine />}
          {activeScreen === 'lab' && <VirtualLab />}
          {activeScreen === 'flashcards' && <FlashcardsRevision />}
          {activeScreen === 'analytics' && <AnalyticsView />}
          {activeScreen === 'profile' && <ProfileView />}
          {activeScreen === 'admin' && <AdminDashboard />}
        </main>
      </div>

      {/* Android-First Bottom Thumb Navigation (<= 56px height) */}
      <nav
        aria-label="Mobile thumb navigation"
        className="lg:hidden fixed bottom-0 inset-x-0 z-30 h-14 bg-white border-t border-slate-200 grid grid-cols-5"
      >
        {(
          [
            { id: 'dashboard', label: 'Home', icon: LayoutDashboard },
            { id: 'reader', label: 'Textbook', icon: BookOpen },
            { id: 'lab', label: 'Lab', icon: FlaskConical },
            { id: 'quiz', label: 'Quiz', icon: ClipboardCheck },
            { id: 'tutor', label: 'AI Tutor', icon: Brain },
          ] as const
        ).map((item) => {
          const Icon = item.icon;
          const active = activeScreen === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => navigateTo(item.id)}
              className={`flex flex-col items-center justify-center gap-0.5 text-[11px] font-semibold ${
                active ? 'text-cyan-700' : 'text-slate-500'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Quiet Academic Footer */}
      <footer className="hidden lg:block border-t border-slate-200 bg-white py-4 px-6 text-xs text-slate-500">
        <div className="mx-auto max-w-7xl flex items-center justify-between">
          <span>
            MASTER JEE – Class 11 Physics · Academically Directed by Dr. V. Sesha Sai Kumar (GRIET,
            Hyderabad)
          </span>
          <span>Supplementary learning modules clearly distinguished from official NCERT/NTA papers</span>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainShell />
    </AppProvider>
  );
}
