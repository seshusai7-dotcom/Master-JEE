export type AcademicLevel = 'foundation' | 'jee_main' | 'jee_advanced';

export type WorkflowStatus =
  | 'GENERATE'
  | 'VALIDATE'
  | 'TEACHER_REVIEW'
  | 'APPROVE'
  | 'PUBLISH';

export type QuestionDatabaseCategory =
  | 'A_VERIFIED_PYQ'
  | 'B_AI_ORIGINAL'
  | 'C_PYQ_INSPIRED';

export type QuestionFormat =
  | 'single_mcq'
  | 'multiple_mcq'
  | 'numerical'
  | 'integer'
  | 'assertion_reason'
  | 'match'
  | 'paragraph';

export interface SubtopicContent {
  id: string;
  title: string;
  syllabusTag: 'NCERT + JEE' | 'JEE Main & Adv' | 'Enrichment';
  // A-Q Complete Textbook Structure
  introductionAndObjectives: string[]; // A
  theoreticalExplanation: {
    foundation: string;
    jee_main: string;
    jee_advanced: string;
  }; // B
  definitionsAndPrinciples: { term: string; definition: string }[]; // C
  physicalInterpretation: string; // D
  mathematicalFormulation: { label: string; latex: string; notes: string }[]; // E
  derivationIds: string[]; // F (links to full step-by-step derivations)
  assumptionsAndLimitations: string[]; // G
  unitsAndDimensions: { quantity: string; siUnit: string; dimensions: string }[]; // H
  diagramSpec: {
    title: string;
    caption: string;
    svgType:
      | 'vernier'
      | 'error_bars'
      | 'kinematics_vt'
      | 'projectile'
      | 'fbd_incline'
      | 'work_area'
      | 'torque_wheel'
      | 'orbit_kepler'
      | 'stress_strain'
      | 'bernoulli_pipe'
      | 'thermal_expansion'
      | 'pv_carnot'
      | 'maxwell_speed'
      | 'shm_phasor'
      | 'standing_wave';
  }; // I
  realLifeApplications: string[]; // J
  importantExamConcepts: string[]; // K
  commonMistakes: { misconception: string; correction: string }[]; // L
  conceptualQuestions: { question: string; answer: string }[]; // M
  solvedProblemIds: string[]; // N
  advancedTechniques: string[]; // O
  summaryPoints: string[]; // P
  revisionNotes: string[]; // Q
}

export interface DerivationStep {
  stepNumber: number;
  equationLatex: string;
  transformationNote: string;
}

export interface Derivation {
  id: string;
  chapterId: string;
  title: string;
  physicalPrinciple: string;
  assumptions: string[];
  symbols: { symbol: string; meaning: string; unit: string }[];
  steps: DerivationStep[];
  finalResultLatex: string;
  physicalSignificance: string;
  validityConditions: string[];
  workedExample: {
    statement: string;
    solution: string;
    answer: string;
  };
}

export interface SolvedProblem {
  id: string;
  chapterId: string;
  subtopicId: string;
  category:
    | 'Basic Conceptual'
    | 'Foundation Numerical'
    | 'JEE Main'
    | 'JEE Advanced'
    | 'Multi-Concept'
    | 'Challenging Mathematical';
  level: AcademicLevel;
  statement: string;
  givenData: string[];
  requiredQuantity: string;
  physicsConcept: string;
  applicableEquationsLatex: string[];
  steps: string[];
  finalAnswer: string;
  strategyExplanation: string;
}

export interface FormulaEntry {
  id: string;
  chapterId: string;
  name: string;
  latex: string;
  symbols: { symbol: string; meaning: string }[];
  siUnit: string;
  dimensions: string;
  interpretation: string;
  validity: string;
  relatedDerivationId?: string;
  isImportant: boolean;
}

export interface QuestionEntry {
  id: string;
  databaseCategory: QuestionDatabaseCategory;
  chapterId: string;
  topicId: string;
  exam: string;
  year: number;
  paper?: string;
  shift?: string;
  format: QuestionFormat;
  difficulty: AcademicLevel;
  prompt: string;
  options?: string[];
  correctOptionIndices?: number[];
  numericalAnswer?: number;
  numericalTolerance?: number;
  unit?: string;
  solution: string;
  sourceCitation: string;
  verified: boolean;
  copyrightNote: string;
}

export interface FlashcardEntry {
  id: string;
  chapterId: string;
  category:
    | 'Definition'
    | 'Law'
    | 'Equation'
    | 'Constant'
    | 'Dimensional Formula'
    | 'Common Mistake'
    | 'JEE Concept';
  front: string;
  back: string;
  latex?: string;
}

export interface MindMapBranch {
  id: string;
  title: string;
  category: 'Subtopic' | 'Equation' | 'Quantity' | 'Application' | 'Exam Concept';
  summary: string;
  equations: string[];
  children: {
    id: string;
    title: string;
    detail: string;
    latex?: string;
  }[];
}

export type LabSimulationId =
  | 'vector_addition'
  | 'projectile_motion'
  | 'relative_velocity'
  | 'inclined_friction'
  | 'circular_motion'
  | 'work_energy_collision'
  | 'rotational_dynamics'
  | 'gravitation_orbit'
  | 'elasticity_stress_strain'
  | 'fluid_buoyancy_bernoulli'
  | 'thermal_pv_gas'
  | 'shm_spring_pendulum'
  | 'standing_waves';

export interface ChapterData {
  id: string;
  number: number;
  title: string;
  unitGroup: 'Mechanics' | 'Properties of Matter' | 'Thermal Physics' | 'Oscillations & Waves';
  ncertWeightage: string;
  jeeWeightage: string;
  estimatedHours: number;
  overview: string;
  labId: LabSimulationId;
  workflowStatus: WorkflowStatus;
  subtopics: SubtopicContent[];
  derivations: Derivation[];
  solvedProblems: SolvedProblem[];
  formulas: FormulaEntry[];
  flashcards: FlashcardEntry[];
  mindMapBranches: MindMapBranch[];
}

export interface QuizAttempt {
  attemptId: string;
  chapterId: string;
  chapterTitle: string;
  mode: 'topic_quiz' | 'chapter_test' | 'mock_main' | 'mock_advanced' | 'ai_practice';
  score: number;
  maxScore: number;
  accuracyPct: number;
  timeSpentSec: number;
  totalQuestions: number;
  correctCount: number;
  wrongCount: number;
  unattemptedCount: number;
  weakTopics: string[];
  createdAtIso: string;
}

export interface StudyNote {
  noteId: string;
  chapterId: string;
  category: 'note' | 'bookmark' | 'mistake';
  title: string;
  body: string;
  createdAtIso: string;
  updatedAtIso: string;
}

export interface FlashcardProgressRecord {
  cardId: string;
  chapterId: string;
  box: number;
  nextReviewEpochMs: number;
}

export interface ManagedContentItem {
  contentId: string;
  chapterId: string;
  subtopicId: string;
  title: string;
  summary: string;
  workflowStatus: WorkflowStatus;
  sourceLabel: 'Original AI-Generated' | 'Academic Director Curated';
  updatedAtIso: string;
}

export type AppScreen =
  | 'dashboard'
  | 'chapters'
  | 'reader'
  | 'mindmap'
  | 'formulas'
  | 'pyqs'
  | 'tutor'
  | 'ai_generator'
  | 'quiz'
  | 'lab'
  | 'flashcards'
  | 'analytics'
  | 'profile'
  | 'admin';

export type CurriculumScope =
  | 'NCERT Core'
  | 'NCERT + JEE Main'
  | 'JEE Main & Adv'
  | 'Enrichment';

export interface SyllabusSubtopicNode {
  subtopicId: string;
  topicId: string;
  chapterId: string;
  order: number;
  code: string;
  title: string;
  ncertAligned: boolean;
  jeeMainAligned: boolean;
  jeeAdvancedAligned: boolean;
  enrichmentOnly: boolean;
  keyConcepts: string[];
  linkedContentSubtopicId: string;
}

export interface SyllabusTopicNode {
  topicId: string;
  chapterId: string;
  order: number;
  code: string;
  title: string;
  ncertSectionRef: string;
  curriculumScope: CurriculumScope;
  isEnrichment: boolean;
  targetLevels: AcademicLevel[];
  linkedContentSubtopicId: string;
  subtopics: SyllabusSubtopicNode[];
}

export interface SyllabusChapterNode {
  chapterId: string;
  chapterNumber: number;
  title: string;
  ncertBookPart: 'Part I' | 'Part II';
  ncertChapterNumber: number;
  unitGroup: 'Mechanics' | 'Properties of Matter' | 'Thermal Physics' | 'Oscillations & Waves';
  ncertWeightage: string;
  jeeWeightage: string;
  estimatedHours: number;
  overview: string;
  labId: LabSimulationId;
  topics: SyllabusTopicNode[];
}

