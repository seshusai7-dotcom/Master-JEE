import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { ALL_CHAPTERS } from '../src/data/curriculumIndex';
import { SYLLABUS_HIERARCHY, getSyllabusStats } from '../src/data/syllabusHierarchy';
import { QUESTION_BANK } from '../src/data/questionBank';
import { buildProjectHtmlDocument } from '../src/utils/htmlExporter';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');

function loadKatexCssWithCdnFonts(): string {
  const katexCssPath = path.join(ROOT_DIR, 'node_modules', 'katex', 'dist', 'katex.min.css');
  if (!fs.existsSync(katexCssPath)) return '';
  const raw = fs.readFileSync(katexCssPath, 'utf8');
  return raw.replace(
    /url\(fonts\//g,
    'url(https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/fonts/'
  );
}

function main() {
  const katexCss = loadKatexCssWithCdnFonts();
  const html = buildProjectHtmlDocument({
    chapters: ALL_CHAPTERS,
    syllabus: SYLLABUS_HIERARCHY,
    questions: QUESTION_BANK,
    katexCss,
  });

  const rootOut = path.join(ROOT_DIR, 'MASTER-JEE-Class-11-Physics.html');
  const publicDir = path.join(ROOT_DIR, 'public');
  const publicOut = path.join(publicDir, 'MASTER-JEE-Class-11-Physics.html');

  fs.mkdirSync(publicDir, { recursive: true });
  fs.writeFileSync(rootOut, html, 'utf8');
  fs.writeFileSync(publicOut, html, 'utf8');

  const stats = getSyllabusStats(SYLLABUS_HIERARCHY);
  const sizeKb = Math.round(Buffer.byteLength(html, 'utf8') / 1024);
  console.log(
    `Generated MASTER-JEE-Class-11-Physics.html (${sizeKb} KB): ${stats.chapterCount} chapters, ${stats.topicCount} topics, ${stats.subtopicCount} subtopics, ${QUESTION_BANK.length} questions.`
  );
}

main();
